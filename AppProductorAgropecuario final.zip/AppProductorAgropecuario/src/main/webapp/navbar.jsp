<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");
    if (rol == null) {
        rol = "";
    }
    if (rol != null) {
        response.sendRedirect("login.jsp");
    }
%>

<head>
    <link href="Css/navbar.css" rel="stylesheet"/>
</head>

<nav class="navbar-custom">

    <div class="nav-left">
        

        <div class="nav-links">
            <%
                if ("Administrador".equals(rol)) {
            %>
            <a href="inicio.jsp"><img src="Images/umata-logo-nav.webp" alt="Logo" class="logo"></a>
            <a href="ProductorServlet">Productores</a>
            <a href="UsuarioServlet">Usuarios</a>
            <%
            } else if ("Cliente".equals(rol)) {
            %>
            <a href="inicioCliente.jsp"><img src="Images/umata-logo-nav.webp" alt="Logo" class="logo"></a>
            <a href="ProductorServlet">Productores</a>
            <%
                }
            %>
        </div>
    </div>

    <form action="logout.jsp" method="post">
        <button type="submit" class="logout">Salir</button>
    </form>

</nav>