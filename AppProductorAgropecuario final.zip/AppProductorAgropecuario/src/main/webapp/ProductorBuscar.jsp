<%@page import="co.umata.duitama.model.Productor"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null && !"Administrador".equals(rol) && !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Buscar Productor</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>

        <link href="Css/AdminStyles.css" rel="stylesheet">

        <style>
            #tblProductor {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 30px;
            }

            #tblProductor th, #tblProductor td {
                padding: 12px 20px;
                text-align: left;
                font-size: 1rem;
            }

            #tblProductor th {
                background-color: #f1f1f1;
                color: #333;
                font-weight: bold;
                border-top: 2px solid #ddd;
            }

            #tblProductor tr:nth-child(even) {
                background-color: #f9f9f9;
            }

            #tblProductor tr:hover {
                background-color: #f1f1f1;
            }

            #tblProductor td {
                border-bottom: 1px solid #ddd;
            }

            .btn-volver {
                background-color: #28a745;
                color: white;
                padding: 12px 24px;
                text-align: center;
                border-radius: 5px;
                text-decoration: none;
                font-size: 1rem;
                transition: background-color 0.3s;
            }

            .btn-volver:hover {
                background-color: #218838;
                text-decoration: none;
            }

            .modal-footer {
                display: flex;
                justify-content: center;
                margin-top: 30px;
            }
        </style>
    </head>
    <body>

        <div class="container mt-4">
            <div class="card shadow">
                <div class="card-body">

                    <div class="table-responsive">
                        <% Productor productorB = (Productor) request.getAttribute("productorB");%>
                        <table id="tblProductor" class="table table-striped table-bordered text-center">
                            <thead>
                                <tr>
                                    <th>Productor</th>
                                    <th><%=productorB.getNombres()%></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Referencia:</strong></td>
                                    <td>${productorB.idProductor}</td>
                                </tr>
                                <tr>
                                    <td><strong>Nombres:</strong></td>
                                    <td>${productorB.nombres}</td>
                                </tr>
                                <tr>
                                    <td><strong>Apellidos:</strong></td>
                                    <td>${productorB.apellidos}</td>
                                </tr>
                                <tr>
                                    <td><strong>Cédula:</strong></td>
                                    <td>${productorB.cedula}</td>
                                </tr>
                                <tr>
                                    <td><strong>Vereda:</strong></td>
                                    <td>${productorB.vereda}</td>
                                </tr>
                                <tr>
                                    <td><strong>Teléfono:</strong></td>
                                    <td>${productorB.telefono}</td>
                                </tr>
                                <tr>
                                    <td><strong>Correo:</strong></td>
                                    <td>${productorB.correo}</td>
                                </tr>
                                <tr>
                                    <td><strong>Producto:</strong></td>
                                    <td>${productorB.productoPrincipal}</td>
                                </tr>
                                <tr>
                                    <td><strong>Hectáreas:</strong></td>
                                    <td>${productorB.hectarea}</td>
                                </tr>
                                <tr>
                                    <td><strong>Riego:</strong></td>
                                    <td>${productorB.tieneRiego ? "Sí" : "No"}</td>
                                </tr>
                                <tr>
                                    <td><strong>Observación:</strong></td>
                                    <td>${productorB.observacion}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="modal-footer">
                        <a href="ProductorServlet" class="btn-volver">Volver</a>
                    </div>

                </div>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

        <script>
            $(document).ready(function () {
                $('#tblProductor').DataTable({
                    paging: false,
                    info: false,
                    searching: false,
                    ordering: false,
                });
            });
        </script>

    </body>
</html>