<%-- 
    Document   : index
    Created on : 26/03/2026, 6:28:42 a. m.
    Author     : PC_18
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <script src="https://cdn.botpress.cloud/webchat/v3.6/shareable.html?configUrl=https://files.bpcontent.cloud/2026/03/26/03/20260326031103-9AYQJQ5M.json"></script>
        <script>
  window.botpressWebChat.init({
    configUrl: "https://files.bpcontent.cloud/2026/03/26/03/20260326031103-9AYQJQ5M.json",
    // Opcional: personalizar apariencia
    theme: "light",
    botName: "Asistente Agropecuario",
    // Esto activa el ícono flotante
    showBotpressButton: true
  })
</script>

    </body>
</html>
