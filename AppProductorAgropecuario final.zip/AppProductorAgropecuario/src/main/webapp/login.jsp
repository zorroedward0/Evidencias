<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="Css/login.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    </head>

    <body>

        <div class="container-fluid login-container">
            <div class="row h-100">

                <div class="col-md-6 d-none d-md-flex left-panel">
                    <div class="left-content">
                        <h1>Bienvenido</h1>
                        <p>Gestionando el campo para un futuro mas Agro.</p>
                        <img src="Images/UMATA-LOGO.png"
                             class="img-fluid mt-4 img-login"
                             alt="Agro">
                    </div>
                </div>

                <div class="col-md-6 d-flex align-items-center justify-content-center right-panel">

                    <div class="login-box">

                        <h2 class="mb-4 text-center">Iniciar Sesión</h2>

                        <form action="LoginServlet" method="POST">

                            <div class="input-group mb-3">
                                <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                                <input type="email" name="email" class="form-control" placeholder="Correo electrónico">
                            </div>

                            <div class="input-group mb-4">
                                <span class="input-group-text"><i class="bi bi-lock"></i></span>
                                <input type="password" name="password" class="form-control" placeholder="Contraseña">
                            </div>

                            <button type="submit" class="btn btn-login w-100">Ingresar</button>

                        </form>

                    </div>

                </div>

            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <%
            String resultado = (String) request.getAttribute("error");
            if (resultado != null && !resultado.isEmpty()) {
        %>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: '<%=resultado%>',
                confirmButtonText: 'Aceptar'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = '/AppProductorAgropecuario/login.jsp';
                }
            });
        </script>
        <%
            }
        %>

    </body>
</html>