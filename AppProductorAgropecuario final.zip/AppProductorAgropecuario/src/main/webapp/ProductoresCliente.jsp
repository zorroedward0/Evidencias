<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="co.umata.duitama.model.Productor"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/ClienteStyles.css" rel="stylesheet"/>
        <title>Listado de Productores</title>

    </head>

    <body>

        <jsp:include page="navbar.jsp"/>

        <div class="container mt-4">
            <h1 style="font-family: Popins;">Productores Registrados</h1>


            <div class="card mb-4 shadow" style="max-width: 700px;">
                <div class="card-body">
                    <form action="ProductorServlet" method="POST" class="row g-2 align-items-center">
                        <input type="hidden" name="accion" value="buscarIndividual">

                        <div class="col-12">
                            <h6 class="text-start mb-2">Busca con cédula o nombre</h6>
                        </div>

                        <div class="col-auto flex-grow-1">
                            <input type="text" name="parametro" class="form-control" placeholder="Ingrese cédula o nombre">
                        </div>
                        <div class="col-auto">
                            <button class="btn btn-success">Buscar</button>
                        </div>
                    </form>
                </div>

            </div>
            <div class="card shadow">
                <div class="card-body">

                    <table id="tblProductores" class="table table-striped table-hover table-bordered align-middle">

                        <thead class="table-success text-center">
                            <tr>
                                <th>ID</th>
                                <th>Nombres</th>
                                <th>Apellidos</th>
                                <th>Cédula</th>
                                <th>Vereda</th>
                                <th>Teléfono</th>
                                <th>Producto</th>
                                <th>Hectáreas</th>
                                <th>Riego</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <c:forEach var="p" items="${listaProductores}">
                                <tr>
                                    <td>${p.idProductor}</td>
                                    <td>${p.nombres}</td>
                                    <td>${p.apellidos}</td>
                                    <td>${p.cedula}</td>
                                    <td>${p.vereda}</td>
                                    <td>${p.telefono}</td>
                                    <td>${p.productoPrincipal}</td>
                                    <td>${p.hectarea}</td>
                                    <td>${p.tieneRiego ? "Sí" : "No"}</td>
                                </tr>
                            </c:forEach>
                        </tbody>

                    </table>

                </div>
            </div>

        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

        <script>
            $(document).ready(function () {
                $('#tblProductores').DataTable({
                    pageLength: 10,
                    lengthChange: false
                });
            });
        </script>
        
        <% String accionSwal = (String) request.getAttribute("accion");%>
        <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>
        <% if (hecho != null) { %>

        <script>
            <% if (hecho) {%>
        Swal.fire({
            icon: 'success',
            title: 'Productor <%=accionSwal%>',
            text: 'El productor se ha <%=accionSwal%> correctamente',
            confirmButtonText: 'Aceptar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '/AppProductorAgropecuario/ProductorServlet';
            }
        });
            <% } else {%>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'No se ha podido <%=accionSwal%> el productor',
            confirmButtonText: 'Aceptar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '/AppProductorAgropecuario/ProductorServlet';
            }
        });
            <% } %>
        </script>
        <% }%>
        
    </body>
</html>