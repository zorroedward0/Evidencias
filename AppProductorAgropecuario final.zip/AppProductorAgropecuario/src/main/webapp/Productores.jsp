<%@page import="co.umata.duitama.model.Productor"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<head>
    <meta charset="UTF-8">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
    <link href="Css/AdminStyles.css" rel="stylesheet">
    <title>Manejo de Productores</title>
</head>

<body>

    <jsp:include page="navbar.jsp"/>

    <div class="container-fluid px-5">

        <div class="text-end mb-3">

            <div class="card mb-4 shadow" style="max-width: 700px;">
                <div class="card-body">
                    <form action="ProductorServlet" method="POST" class="row g-2 align-items-center">
                        <input type="hidden" name="accion" value="buscarIndividual">

                        <div class="col-12">
                            <h6 class="text-start mb-2">Busca con cédula o nombre</h6>
                        </div>

                        <div class="col-auto flex-grow-1">
                            <input type="text" name="parametro" class="form-control" placeholder="Ingrese cédula o nombre">
                        </div>
                        <div class="col-auto">
                            <button class="btn btn-success">Buscar</button>
                        </div>
                    </form>
                </div>
            </div>


            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCrear">
                <i class="bi bi-plus-circle"></i> Nuevo Productor
            </button>
        </div>

        <div class="card shadow">
            <div class="card-body">

                <table id="tblProductores" class="table table-striped table-hover table-bordered align-middle">

                    <thead class="table-success text-center">
                        <tr>
                            <th>Referencia</th>
                            <th>Nombres</th>
                            <th>Apellidos</th>
                            <th>Cédula</th>
                            <th>Vereda</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Producto</th>
                            <th>Hectáreas</th>
                            <th>Riego</th>
                            <th>Observación</th>
                            <th>Funciones</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">
                        <c:forEach var="p" items="${listaProductores}">
                            <tr>
                                <td>${p.idProductor}</td>
                                <td>${p.nombres}</td>
                                <td>${p.apellidos}</td>
                                <td>${p.cedula}</td>
                                <td>${p.vereda}</td>
                                <td>${p.telefono}</td>
                                <td>${p.correo}</td>
                                <td>${p.productoPrincipal}</td>
                                <td>${p.hectarea}</td>
                                <td>${p.tieneRiego ? "Sí" : "No"}</td>
                                <td>${p.observacion}</td>

                                <td>
                                    <button class="btn btn-warning"
                                            data-id="${p.idProductor}"
                                            data-nombres="${p.nombres}"
                                            data-apellidos="${p.apellidos}"
                                            data-cedula="${p.cedula}"
                                            data-vereda="${p.vereda}"
                                            data-telefono="${p.telefono}"
                                            data-correo="${p.correo}"
                                            data-producto="${p.productoPrincipal}"
                                            data-hectarea="${p.hectarea}"
                                            data-riego="${p.tieneRiego}"
                                            data-observacion="${p.observacion}"
                                            onclick="abrirModalEditar(this)">
                                        <i class="bi bi-pencil"></i>
                                    </button>

                                    <button class="btn btn-danger"
                                            data-id="${p.idProductor}"
                                            data-nombre="${p.nombres} ${p.apellidos}"
                                            onclick="abrirModalEliminar(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>

                </table>

            </div>
        </div>

    </div>

    <div class="modal fade" id="modalEditar">
        <div class="modal-dialog">
            <div class="modal-content">

                <form action="ProductorServlet" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Editar Productor</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">

                        <input type="hidden" name="accion" value="editar">

                        <h6>Referencia</h6>
                        <input type="text" id="id" name="id" class="form-control mb-2" readonly>
                        <h6>Nombres</h6>
                        <input type="text" id="nombres" name="nombres" class="form-control mb-2">
                        <h6>Apellidos</h6>
                        <input type="text" id="apellidos" name="apellidos" class="form-control mb-2">
                        <h6>Cedula</h6>
                        <input type="text" id="cedula" name="cedula" class="form-control mb-2">
                        <h6>Vereda</h6>
                        <input type="text" id="vereda" name="vereda" class="form-control mb-2">
                        <h6>Telefono</h6>
                        <input type="text" id="telefono" name="telefono" class="form-control mb-2">
                        <h6>Correo</h6>
                        <input type="email" id="correo" name="correo" class="form-control mb-2">
                        <h6>Producto Principal</h6>
                        <input type="text" id="producto" name="productoPrincipal" class="form-control mb-2">
                        <h6>Numero de Hectareas</h6>
                        <input type="number" step="0.01" id="hectarea" name="hectarea" class="form-control mb-2">

                        <label>Riego</label>
                        <select id="riego"  name="tieneRiego" class="form-select mb-2">
                            <option value="true">Si</option>
                            <option value="false">No</option>
                        </select>

                        <h6>Observacion</h6>
                        <textarea id="observacion" name="observacion" class="form-control mt-2"></textarea>

                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-primary">Guardar</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modalEliminar">
        <div class="modal-dialog">
            <div class="modal-content">

                <form action="ProductorServlet" method="POST">
                    <div class="modal-body text-center">

                        <input type="hidden" name="accion" value="eliminar">
                        <input type="hidden" id="idEliminar" name="idEliminar">

                        <h5>¿Eliminar productor?</h5>
                        <input type="text" id="nombreEliminar" class="form-control text-center mb-2" readonly style="border:none;">
                        <small class="text-muted">Esta acción es irreversible</small>
                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-danger">Eliminar</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modalCrear">
        <div class="modal-dialog">
            <div class="modal-content">

                <form action="ProductorServlet" method="POST">
                    <div class="modal-header">
                        <h5 class="modal-title">Nuevo Productor</h5>
                    </div>

                    <div class="modal-body">

                        <input type="hidden" name="accion" value="crear">

                        <h6>Nombres</h6>
                        <input type="text" name="nombres" class="form-control mb-2">
                        <h6>Apellidos</h6>
                        <input type="text" name="apellidos" class="form-control mb-2">
                        <h6>Cedula</h6>
                        <input type="text" name="cedula" class="form-control mb-2">
                        <h6>Vereda</h6>
                        <input type="text"  name="vereda" class="form-control mb-2">
                        <h6>Telefono</h6>
                        <input type="text"  name="telefono" class="form-control mb-2">
                        <h6>Correo</h6>
                        <input type="email"  name="correo" class="form-control mb-2">
                        <h6>Producto Principal</h6>
                        <input type="text"  name="productoPrincipal" class="form-control mb-2">
                        <h6>Numero de Hectareas</h6>
                        <input type="number" step="0.01" name="hectarea" class="form-control mb-2">

                        <label>Riego</label>
                        <select  name="tieneRiego" class="form-select mb-2">
                            <option value="true">Si</option>
                            <option value="false">No</option>
                        </select>

                        <h6>Observacion</h6>
                        <textarea  name="observacion" class="form-control mt-2"></textarea>

                    </div>

                    <div class="modal-footer">
                        <button class="btn btn-success">Crear</button>
                    </div>
                </form>

            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <% String accionSwal = (String) request.getAttribute("accion");%>
    <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>
    <% if (hecho != null) { %>

    <script>
        <% if (hecho) {%>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Productor <%=accionSwal%>',
                                                    text: 'El productor se ha <%=accionSwal%> correctamente',
                                                    confirmButtonText: 'Aceptar'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = '/AppProductorAgropecuario/ProductorServlet';
                                                    }
                                                });
        <% } else {%>
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Error',
                                                    text: 'No se ha podido <%=accionSwal%> el productor',
                                                    confirmButtonText: 'Aceptar'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = '/AppProductorAgropecuario/ProductorServlet';
                                                    }
                                                });
        <% } %>
    </script>
    <% }%>

    <script>
        function abrirModalEditar(btn) {
            const modal = document.getElementById("modalEditar");

            modal.querySelector("#id").value = btn.dataset.id;
            modal.querySelector("#nombres").value = btn.dataset.nombres;
            modal.querySelector("#apellidos").value = btn.dataset.apellidos;
            modal.querySelector("#cedula").value = btn.dataset.cedula;
            modal.querySelector("#vereda").value = btn.dataset.vereda;
            modal.querySelector("#telefono").value = btn.dataset.telefono;
            modal.querySelector("#correo").value = btn.dataset.correo;
            modal.querySelector("#producto").value = btn.dataset.producto;
            modal.querySelector("#hectarea").value = btn.dataset.hectarea;
            modal.querySelector("#observacion").value = btn.dataset.observacion;

            modal.querySelector("#riego").checked = (btn.dataset.riego === "true");

            new bootstrap.Modal(modal).show();
        }

        function abrirModalEliminar(btn) {
            document.getElementById("idEliminar").value = btn.dataset.id;
            document.getElementById("nombreEliminar").value = btn.dataset.nombre;
            new bootstrap.Modal(document.getElementById("modalEliminar")).show();
        }

        $(document).ready(function () {
            $('#tblProductores').DataTable({
                pageLength: 15,
                lengthChange: false
            });
        });

    </script>

    <script>
        $(document).ready(function () {
            $('#tblProductor').DataTable({
                pageLength: 5,
                lengthChange: false,
                language: {
                    url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json"
                }
            });
        });
    </script>

</body>