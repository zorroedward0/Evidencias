
package co.umata.duitama.controller;

import java.util.List;
import co.umata.duitama.model.TipoUsuario;
import co.umata.duitama.dao.TipoUsuarioDao;
import co.umata.duitama.dao.TipoUsuarioDaoI;

public class TipoUsuarioController {
private final TipoUsuarioDaoI tipoDao = new TipoUsuarioDao();
public List<TipoUsuario> listarTiposUsuario(){
    return tipoDao.listarTiposUsuario();
}
    public boolean insertarTiposUsuario(List<TipoUsuario> tiposUsuario){
        boolean insertado = tipoDao.insertarTiposUsuario(tiposUsuario)!=null;
        return insertado;
    }
    public boolean actualizarTipoUsuario(TipoUsuario tipoUsuario, Integer idTipoUsuarioI){
        boolean actualizado = tipoDao.actualizarTipoUsuario(tipoUsuario, idTipoUsuarioI)!=null;
        return actualizado;
    }
    public boolean eliminarTipoUsuario(Integer idTipoUsuarioI){
        boolean eliminado = tipoDao.eliminarTipoUsuario(idTipoUsuarioI)!= null;
        return eliminado;
    }
}
