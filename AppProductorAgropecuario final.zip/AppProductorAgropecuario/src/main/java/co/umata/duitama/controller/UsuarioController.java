package co.umata.duitama.controller;

import java.util.List;
import co.umata.duitama.model.Usuario;
import co.umata.duitama.dao.UsuarioDao;
import co.umata.duitama.dao.UsuarioDaoI;


public class UsuarioController {

    private final UsuarioDaoI UsuarioDao = new UsuarioDao();

    public List<Usuario> listarUsuarios() {
        return UsuarioDao.listarUsuarios();
    }

    public boolean insertarUsuarios(List<Usuario> usuarios) {
        boolean inserto = UsuarioDao.insertarUsuarios(usuarios)!= null;
        return inserto;
    }
    
    public boolean actualizarUsuario(Usuario autor, Integer idAutorI) {
        boolean actualizo = UsuarioDao.actualizarUsuario(autor, idAutorI)!= null;
        return actualizo;
    }

    public boolean eliminarUsuario(Integer idAutorI) {
        boolean elimino = UsuarioDao.eliminarUsuario(idAutorI)!=null;
        return elimino;
    }
    
    public Usuario login(String email,String password){
        List<Usuario> listaUsuarios = listarUsuarios();
        for(Usuario usu : listaUsuarios){
            if((email).equals(usu.getEmail()) && (password).equals(usu.getPassword())){
                return usu;
            }
        }
        return null;
    }
    
 

}
