package co.umata.duitama.model;

import java.time.LocalDateTime;

public class Productor {
    private Integer idProdcutor;
    private String nombres;
    private String apellidos;
    private String cedula;
    private String vereda;
    private String telefono;
    private String correo;
    private String productoPrincipal;
    private double hectarea;
    private boolean tieneRiego;
    private String observacion;
    private LocalDateTime fechaRegistro;

    public Productor() {
    }

    public Productor(Integer idProdcutor, String nombres, String apellidos, String cedula, String vereda, String telefono, String correo, String productoPrincipal, double hectarea, boolean tieneRiego, String observacion, LocalDateTime fechaRegistro) {
        this.idProdcutor = idProdcutor;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.cedula = cedula;
        this.vereda = vereda;
        this.telefono = telefono;
        this.correo = correo;
        this.productoPrincipal = productoPrincipal;
        this.hectarea = hectarea;
        this.tieneRiego = tieneRiego;
        this.observacion = observacion;
        this.fechaRegistro = fechaRegistro;
    }

    public Integer getIdProductor() {
        return idProdcutor;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCedula() {
        return cedula;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public String getVereda() {
        return vereda;
    }

    public void setVereda(String vereda) {
        this.vereda = vereda;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getProductoPrincipal() {
        return productoPrincipal;
    }

    public void setProductoPrincipal(String productoPrincipal) {
        this.productoPrincipal = productoPrincipal;
    }

    public double getHectarea() {
        return hectarea;
    }

    public void setHectarea(double hectarea) {
        this.hectarea = hectarea;
    }

    public boolean getTieneRiego() {
        return tieneRiego;
    }

    public void setTieneRiego(boolean tieneRiego) {
        this.tieneRiego = tieneRiego;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }
    
    
    
}
