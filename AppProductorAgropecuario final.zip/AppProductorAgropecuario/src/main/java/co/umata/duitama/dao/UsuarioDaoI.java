package co.umata.duitama.dao;

    import co.umata.duitama.model.Usuario;

import java.util.List;

public interface UsuarioDaoI {
    public List<Usuario> listarUsuarios();
    public String insertarUsuarios(List<Usuario> usuarios);
    public String actualizarUsuario(Usuario usuario, Integer idUsuarioI);
    public String eliminarUsuario(Integer idUsuarioI);

}
