package co.umata.duitama.servlets;

import co.umata.duitama.controller.ProductorController;
import co.umata.duitama.model.Productor;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ProductorServlet", urlPatterns = {"/ProductorServlet"})
public class ProductorServlet extends HttpServlet {

    private final ProductorController controlP = new ProductorController();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null) {
            response.sendRedirect("inicio.jsp");
            return;
        } else if ("Administrador".equals(rol)) {

            List<Productor> listaProductores = controlP.listarProductores();
            request.setAttribute("listaProductores", listaProductores);

            RequestDispatcher rd = request.getRequestDispatcher("Productores.jsp");
            rd.forward(request, response);
        } else if ("Cliente".equals(rol)) {
            List<Productor> listaProductores = controlP.listarProductores();
            request.setAttribute("listaProductores", listaProductores);

            RequestDispatcher rd = request.getRequestDispatcher("ProductoresCliente.jsp");
            rd.forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null) {
            response.sendRedirect("inicio.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        switch (accion) {
            case "crear":
                crearProductor(request, response);
                break;
            case "editar":
                editarProductor(request, response);
                break;
            case "eliminar":
                eliminarProductor(request, response);
                break;
            case "buscarIndividual":
                buscarIndividual(request, response);
                break;
            default:
                response.sendRedirect("ProductorServlet");
                break;
        }
    }

    private void buscarIndividual(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        String cedula = request.getParameter("parametro");

        Productor productorB = controlP.BuscarProductorPorCedulaNombre(cedula);

        if (productorB != null) {
            request.setAttribute("productorB", productorB);
            request.getRequestDispatcher("ProductorBuscar.jsp").forward(request, response);
        } else {
            request.setAttribute("hecho", false);
            request.setAttribute("accion", "encontrar");
            request.getRequestDispatcher("Productores.jsp").forward(request, response);
        }
    }

    private void crearProductor(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Productor p = new Productor();

        p.setNombres(request.getParameter("nombres"));
        p.setApellidos(request.getParameter("apellidos"));
        p.setCedula(request.getParameter("cedula"));
        p.setVereda(request.getParameter("vereda"));
        p.setTelefono(request.getParameter("telefono"));
        p.setCorreo(request.getParameter("correo"));
        p.setProductoPrincipal(request.getParameter("productoPrincipal"));
        p.setHectarea(Double.parseDouble(request.getParameter("hectarea")));
        p.setTieneRiego(request.getParameter("tieneRiego") != null);
        p.setObservacion(request.getParameter("observacion"));

        boolean creado = controlP.registrarProductor(p);

        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creado");
        request.getRequestDispatcher("Productores.jsp").forward(request, response);
    }

    private void editarProductor(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer id = Integer.valueOf(request.getParameter("id"));

        Productor p = new Productor(
                id,
                request.getParameter("nombres"),
                request.getParameter("apellidos"),
                request.getParameter("cedula"),
                request.getParameter("vereda"),
                request.getParameter("telefono"),
                request.getParameter("correo"),
                request.getParameter("productoPrincipal"),
                Double.parseDouble(request.getParameter("hectarea")),
                request.getParameter("tieneRiego") != null,
                request.getParameter("observacion"),
                null
        );

        boolean actualizado = controlP.editarProductor(p);

        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");
        request.getRequestDispatcher("Productores.jsp").forward(request, response);
    }

    private void eliminarProductor(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer id = Integer.valueOf(request.getParameter("idEliminar"));

        boolean eliminado = controlP.eliminarProductor(id);

        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");
        request.getRequestDispatcher("Productores.jsp").forward(request, response);
    }
}
