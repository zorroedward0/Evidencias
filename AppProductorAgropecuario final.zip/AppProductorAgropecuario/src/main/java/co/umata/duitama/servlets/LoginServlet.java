package co.umata.duitama.servlets;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import co.umata.duitama.controller.TipoUsuarioController;
import co.umata.duitama.controller.UsuarioController;
import co.umata.duitama.model.TipoUsuario;
import co.umata.duitama.model.Usuario;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    private final UsuarioController controlL = new UsuarioController();
    private final TipoUsuarioController controlTu = new TipoUsuarioController();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        Usuario usuario = controlL.login(email, password);
        if (usuario != null) {

            HttpSession sesion = request.getSession();
            sesion.setAttribute("usuarioLogueado", usuario);

            String tipoUsuario = null;
            Integer idTipoUsuario = usuario.getIdTipoUsuario();

            List<TipoUsuario> tiposU = controlTu.listarTiposUsuario();

            for (TipoUsuario tu : tiposU) {
                if (Objects.equals(tu.getIdTipoUsuario(), idTipoUsuario)) {
                    tipoUsuario = tu.getNombre();
                    break;
                }
            }

            if ("Administrador".equalsIgnoreCase(tipoUsuario)) {
                sesion.setAttribute("rol", tipoUsuario);
                response.sendRedirect("inicio.jsp");
            } else if ("Cliente".equalsIgnoreCase(tipoUsuario)) {
                sesion.setAttribute("rol", tipoUsuario);
                response.sendRedirect("inicioCliente.jsp");
            } else {
                request.setAttribute("error", "Tipo de usuario no identificado");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }

        } else {
            request.setAttribute("error", "Usuario o contraseña incorrectos");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
