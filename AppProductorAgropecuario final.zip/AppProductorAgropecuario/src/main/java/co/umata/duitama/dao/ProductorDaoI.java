package co.umata.duitama.dao;

import co.umata.duitama.model.Productor;
import java.util.List;

public interface ProductorDaoI {
    public boolean registrarProductor(Productor productor);
    public List<Productor> listarProductores();
    public Productor BuscarProductorPorCedulaNombre(String parametro);
    public boolean editarProductor(Productor productor);
    public boolean eliminarProductor(Integer id);
    
}
