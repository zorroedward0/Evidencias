package co.umata.duitama.dao;

import co.umata.duitama.config.ConexionDb;
import co.umata.duitama.model.Productor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ProductorDao implements ProductorDaoI {

    String sqlGeneral = "Select * from productores";

    @Override
    public List<Productor> listarProductores() {
        String sql = sqlGeneral + " ORDER BY id_productores";
        try (Connection conn = ConexionDb.getConexion(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            List<Productor> listaProductores = new ArrayList<>();
            while (rs.next()) {
                Productor productor = mapearProductor(rs);
                if (productor != null) {
                    listaProductores.add(productor);
                }
            }
            return listaProductores;

        } catch (SQLException e) {
            throw new RuntimeException("Error al listar Productores ", e);
        }
    }

    @Override
    public Productor BuscarProductorPorCedulaNombre(String parametro) {
        if (parametro == null || parametro.trim().isEmpty()) {
            return null;
        }

        String sql = sqlGeneral + " WHERE nombres LIKE ? OR cedula = ?";

        try (Connection conn = ConexionDb.getConexion(); PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, "%" + parametro + "%");
            ps.setString(2, parametro);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapearProductor(rs);
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar Productor ", e);
        }

        return null;
    }

    @Override
    public boolean registrarProductor(Productor productor) {

        List<Productor> lista = listarProductores();
        for (Productor p : lista) {
            if (productor.getCedula().equalsIgnoreCase(p.getCedula())) {
                return false;
            }
        }

        String sql = "INSERT INTO productores (nombres, apellidos, cedula, vereda,telefono, correo, producto_principal, hectarea, tiene_riego, observacion)"
                + " VALUES (?,?,?,?,?,?,?,?,?,?)";

        try (Connection cn = ConexionDb.getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, productor.getNombres());
            ps.setString(2, productor.getApellidos());
            ps.setString(3, productor.getCedula());
            ps.setString(4, productor.getVereda());
            ps.setString(5, productor.getTelefono());
            ps.setString(6, productor.getCorreo());
            ps.setString(7, productor.getProductoPrincipal());
            ps.setDouble(8, productor.getHectarea());
            ps.setBoolean(9, productor.getTieneRiego());
            ps.setString(10, productor.getObservacion());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar Productor ", e);
        }

    }

    @Override
    public boolean editarProductor(Productor productor) {
        List<Productor> lista = listarProductores();
        for (Productor p : lista) {
            if (productor.getCedula().equalsIgnoreCase(p.getCedula())) {
                return false;
            }
        }
        String sql = "UPDATE productores SET nombres=?, apellidos=?, cedula=?, vereda=?, telefono=?, correo=?, producto_principal=?, hectarea=?, tiene_riego=?, observacion=? WHERE id_productores=?";

        try (Connection cn = ConexionDb.getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setString(1, productor.getNombres());
            ps.setString(2, productor.getApellidos());
            ps.setString(3, productor.getCedula());
            ps.setString(4, productor.getVereda());
            ps.setString(5, productor.getTelefono());
            ps.setString(6, productor.getCorreo());
            ps.setString(7, productor.getProductoPrincipal());
            ps.setDouble(8, productor.getHectarea());
            ps.setBoolean(9, productor.getTieneRiego());
            ps.setString(10, productor.getObservacion());
            ps.setInt(11, productor.getIdProductor());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al actuaizar Productor ", e);
        }
    }

    @Override
    public boolean eliminarProductor(Integer id) {
        String sql = " DELETE FROM productores WHERE id_productores = ?";
        try (Connection cn = ConexionDb.getConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar Productor ", e);
        }
    }

    private Productor mapearProductor(ResultSet rs) throws SQLException {
        return new Productor(
                rs.getInt("id_productores"),
                rs.getString("nombres"),
                rs.getString("apellidos"),
                rs.getString("cedula"),
                rs.getString("vereda"),
                rs.getString("telefono"),
                rs.getString("correo"),
                rs.getString("producto_principal"),
                rs.getDouble("hectarea"),
                rs.getBoolean("tiene_riego"),
                rs.getString("observacion"),
                rs.getObject("fecha_registro", LocalDateTime.class)
        );
    }

}
