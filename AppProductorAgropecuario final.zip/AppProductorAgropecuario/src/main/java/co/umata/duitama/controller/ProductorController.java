package co.umata.duitama.controller;

import co.umata.duitama.dao.ProductorDao;
import co.umata.duitama.dao.ProductorDaoI;
import co.umata.duitama.model.Productor;
import java.util.List;

public class ProductorController {

    private final ProductorDaoI productorDao = new ProductorDao();
    
    public boolean registrarProductor(Productor productor){
        return productorDao.registrarProductor(productor);
    }

    public List<Productor> listarProductores(){
        return productorDao.listarProductores();
    }

    public Productor BuscarProductorPorCedulaNombre(String parametro){
        return productorDao.BuscarProductorPorCedulaNombre(parametro);
    }

    public boolean editarProductor(Productor productor){
        return productorDao.editarProductor(productor);
    }

    public boolean eliminarProductor(Integer id){
        return productorDao.eliminarProductor(id);
    }
}
