package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Editorial;

import java.util.List;

public interface EditorialDaoI {
    public List<Editorial> listarEditoriales();
    public String insertarEditoriales(List<Editorial> editoriales);
    String actualizarEditorial(Editorial editorial, Integer idEditorialI);
    public String eliminarEditorial(Integer idEditorialI);
    public Editorial buscarEditorialPorId(Integer idEditorialI);
}
