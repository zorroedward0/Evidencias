package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.config.ConexionDb;
import sena.adso.appbibliotecaweb.model.Editorial;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EditorialDao implements EditorialDaoI {

    @Override
    public List<Editorial> listarEditoriales() {
        List<Editorial> editoriales = new ArrayList<>();
        String sql = "SELECT ideditorial, nombre, pais, sitioWeb FROM editorial";
        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                editoriales.add(new Editorial(
                        rs.getObject("ideditorial", Integer.class),
                        rs.getString("nombre"),
                        rs.getString("pais"),
                        rs.getString("sitioWeb")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar editoriales ", e);
        }
        return editoriales;
    }

    @Override
    public String insertarEditoriales(List<Editorial> editoriales) {
        if (editoriales == null || editoriales.isEmpty()) {
            return null;
        }

        String sql = "INSERT INTO editorial (nombre, pais, sitioWeb) VALUES (?, ?, ?)";
        String mensaje;
        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            for (Editorial editorial : editoriales) {
                ps.setString(1, editorial.getNombre());
                ps.setString(2, editorial.getPais());
                ps.setString(3, editorial.getSitioWeb());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();
            int total = 0;
            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " editoriales.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar editoriales ", e);
        }
        return mensaje;
    }

    @Override
    public String actualizarEditorial(Editorial editorial, Integer idEditorialI) {
        if (editorial == null || idEditorialI == null) {
            return null;
        }

        String sql = "UPDATE editorial SET nombre = ?, pais = ?, sitioWeb = ? WHERE ideditorial = ?";
        String mensaje;
        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, editorial.getNombre());
            ps.setString(2, editorial.getPais());
            ps.setString(3, editorial.getSitioWeb());
            ps.setInt(4, idEditorialI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado la editorial " + editorial.getNombre() + " correctamente.";
            } else {
                mensaje = null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar la editorial ", e);
        }
        return mensaje;
    }

    @Override
    public String eliminarEditorial(Integer idEditorialI) {
        if (idEditorialI == null) {
            return null;
        }

        String sql = "DELETE FROM editorial WHERE ideditorial = ?";
        String mensaje;
        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEditorialI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado la editorial con el id " + idEditorialI + " correctamente.";
            } else {
                mensaje = null;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar la editorial ", e);
        }
        return mensaje;
    }

    @Override
    public Editorial buscarEditorialPorId(Integer idEditorial) {
        Editorial editorial = null;
        String sql = "SELECT ideditorial, nombre, pais, sitioWeb FROM editorial WHERE ideditorial = ?";

        try (Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setObject(1, idEditorial);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    editorial = new Editorial(
                            rs.getObject("ideditorial", Integer.class),
                            rs.getString("nombre"),
                            rs.getString("pais"),
                            rs.getString("sitioWeb")
                    );
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar editorial", e);
        }

        return editorial;
    }

}
