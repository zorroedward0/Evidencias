package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.config.ConexionDb;
import sena.adso.appbibliotecaweb.model.Categoria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDao implements CategoriaDaoI{

    @Override
    public List<Categoria> listarCategorias() {
        List<Categoria> categorias = new ArrayList<>();
        String sql = "SELECT idcategoria,nombre,descripcion FROM categoria";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                categorias.add(new Categoria(
                        rs.getInt("idcategoria"),
                        rs.getString("nombre"),
                        rs.getString("descripcion")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar categorias ", e);
        }
        return categorias;
    }

    @Override
    public String insertarCategorias(List<Categoria> categorias) {
        if (categorias == null || categorias.isEmpty()) return "No se ha encontrado categorias para insertar.";
        String sql = "INSERT INTO categoria (nombre,descripcion) values (?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (Categoria categoria : categorias) {
                ps.setString(1, categoria.getNombre());
                ps.setString(2, categoria.getDescripcion());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " categorias.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar las categorias ", e);
        }
        return mensaje;
    }

    @Override
    public String actualizarCategoria(Categoria categoria, Integer idCategoriaI) {

        if (categoria == null || idCategoriaI == null) return "No has ingresado el id  para actualizar la categoria.";
        String sql = " UPDATE categoria SET nombre = ?, descripcion = ? WHERE idcategoria = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, categoria.getNombre());
            ps.setString(2, categoria.getDescripcion());
            ps.setInt(3, idCategoriaI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado la categoria " + categoria.getNombre() + " correctamente.";
            }else mensaje = "No se ha podido actualizar la categoria.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar la  categoria ", e);
        }
        return mensaje;
    }
    @Override
    public String eliminarCategoria(Integer idCategoriaI) {

        if (idCategoriaI == null) return "No has ingresado el id del categoria para eliminar su informacion.";
        String sql = " DELETE FROM categoria WHERE idcategoria = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idCategoriaI);


            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado la categoria con el id " +idCategoriaI+ " correctamente.";
            }else mensaje = "No se ha podido eliminar la categoria.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar la categoria ", e);
        }
        return mensaje;
    }
}
