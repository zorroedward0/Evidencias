package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import sena.adso.appbibliotecaweb.controller.AutorController;
import sena.adso.appbibliotecaweb.model.Autor;

@WebServlet(name = "AutorServlet", urlPatterns = {"/AutorServlet"})
public class AutorServlet extends HttpServlet {

    private final AutorController controlA = new AutorController();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || !"Administrador".equals(rol)) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<Autor> lista = controlA.listarAutores();
        request.setAttribute("listaAutores", lista);

        request.getRequestDispatcher("Autores.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        switch (accion) {
            case "crear":
                crear(request, response);
                break;
            case "editar":
                editar(request, response);
                break;
            case "eliminar":
                eliminar(request, response);
                break;
            default:
                response.sendRedirect("AutorServlet");
        }
    }

    private void crear(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String nacionalidad = request.getParameter("nacionalidad");
        LocalDate fecha = LocalDate.parse(request.getParameter("fecha"));

        Autor a = new Autor(nombre, apellido, nacionalidad, fecha);

        List<Autor> lista = new ArrayList<>();
        lista.add(a);

        boolean creado = controlA.insertarAutores(lista);
        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creado");
        request.getRequestDispatcher("Autores.jsp").forward(request, response);
    }

    private void editar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Integer id = Integer.valueOf(request.getParameter("idAutor"));

        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String nacionalidad = request.getParameter("nacionalidad");
        LocalDate fecha = LocalDate.parse(request.getParameter("fecha"));

        Autor a = new Autor(nombre, apellido, nacionalidad, fecha);

        boolean actualizado = controlA.actualizarAutor(a, id);
        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");
        request.getRequestDispatcher("Autores.jsp").forward(request, response);

    }

    private void eliminar(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Integer id = Integer.valueOf(request.getParameter("idEliminar"));

        boolean eliminado = controlA.eliminarAutor(id);

        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");
        request.getRequestDispatcher("Autores.jsp").forward(request, response);
    }
}
