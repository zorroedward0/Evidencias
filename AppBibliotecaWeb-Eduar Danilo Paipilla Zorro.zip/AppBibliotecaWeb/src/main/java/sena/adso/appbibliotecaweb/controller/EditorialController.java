package sena.adso.appbibliotecaweb.controller;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Editorial;
import sena.adso.appbibliotecaweb.model.dao.EditorialDao;
import sena.adso.appbibliotecaweb.model.dao.EditorialDaoI;

public class EditorialController {

    private final EditorialDaoI EditorialDao = new EditorialDao();

    public List<Editorial> listarEditoriales() {
        return EditorialDao.listarEditoriales();
    }

    public boolean insertarEditoriales(List<Editorial> editoriales) {
        boolean inserto = EditorialDao.insertarEditoriales(editoriales) != null;
        return inserto;
    }

    public boolean actualizarEditorial(Editorial editorial, Integer idEditorialI) {
        boolean actualizo = EditorialDao.actualizarEditorial(editorial, idEditorialI) != null;
        return actualizo;
    }

    public boolean eliminarEditorial(Integer idEditorialI) {
        boolean elimino = EditorialDao.eliminarEditorial(idEditorialI) != null;
        return elimino;
    }

    public Editorial buscarEditorialPorId(Integer idEditorialI) {
        return EditorialDao.buscarEditorialPorId(idEditorialI);
    }

}
