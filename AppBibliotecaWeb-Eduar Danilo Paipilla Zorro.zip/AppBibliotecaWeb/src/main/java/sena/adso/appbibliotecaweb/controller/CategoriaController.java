package sena.adso.appbibliotecaweb.controller;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Categoria;
import sena.adso.appbibliotecaweb.model.dao.CategoriaDao;
import sena.adso.appbibliotecaweb.model.dao.CategoriaDaoI;

public class CategoriaController {
    
   private final CategoriaDaoI CategoriaDao = new CategoriaDao();
   
    public List<Categoria> listarCategorias(){
       return CategoriaDao.listarCategorias();
    }
    public boolean insertarCategorias(List<Categoria> categorias){
       boolean inserto = CategoriaDao.insertarCategorias(categorias)!=null;
       return inserto;
    }
    public boolean actualizarCategoria(Categoria categoria, Integer idCategoriaI){
        boolean actualizo = CategoriaDao.actualizarCategoria(categoria, idCategoriaI)!=null;
        return actualizo;
    }
    public boolean eliminarCategoria(Integer idCategoriaI){
        boolean elimino = CategoriaDao.eliminarCategoria(idCategoriaI)!=null;
        return elimino;
    }
   
}
