package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sena.adso.appbibliotecaweb.controller.TipoUsuarioController;
import sena.adso.appbibliotecaweb.controller.UsuarioController;
import sena.adso.appbibliotecaweb.model.TipoUsuario;
import sena.adso.appbibliotecaweb.model.Usuario;
import java.util.List;
import javax.servlet.http.HttpSession;

@WebServlet(name = "UsuarioServlet", urlPatterns = {"/UsuarioServlet"})
public class UsuarioServlet extends HttpServlet {

    private final UsuarioController controlU = new UsuarioController();
    private final TipoUsuarioController controlTu = new TipoUsuarioController();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Usuario> listaUsuarios = controlU.listarUsuarios();
        request.setAttribute("listaUsuarios", listaUsuarios);

        List<TipoUsuario> listaTiposUsuario = controlTu.listarTiposUsuario();
        request.setAttribute("listaTipos", listaTiposUsuario);

        RequestDispatcher rd = request.getRequestDispatcher("Usuarios.jsp");
        rd.forward(request, response);

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String accion = request.getParameter("accion");
        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null && !"Cliente".equals(rol) && "Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }
        switch (accion) {
            case "crear":
                crearUsuario(request, response);
                break;
            case "editar":
                editarUsuario(request, response);
                break;
            case "eliminar":
                eliminarUsuario(request, response);
                break;
            default:
                response.sendRedirect("usuarios.jsp");
                break;
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private void crearUsuario(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String documento = request.getParameter("documento");
        String email = request.getParameter("email");
        String telefono = request.getParameter("telefono");
        Integer idTipoUsuario = Integer.valueOf(request.getParameter("tipo"));
        String password = request.getParameter("password");

        Usuario usuario = new Usuario(documento, nombre, apellido, email, telefono, idTipoUsuario, password);
        List<Usuario> users = new ArrayList<>();
        users.add(usuario);

        boolean creado = controlU.insertarUsuarios(users);
        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creado");
        request.getRequestDispatcher("Usuarios.jsp").forward(request, response);

    }

    private void editarUsuario(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        String nombre = request.getParameter("nombre");
        Integer idUsuario = Integer.valueOf(request.getParameter("idUsuario"));
        String apellido = request.getParameter("apellido");
        String documento = request.getParameter("documento");
        String email = request.getParameter("email");
        String telefono = request.getParameter("telefono");
        Integer idTipoUsuario = Integer.valueOf(request.getParameter("tipo"));
        String password = request.getParameter("password");
        boolean estado = Boolean.parseBoolean(request.getParameter("estado"));

        Usuario usuario = new Usuario(idUsuario, documento, nombre, apellido, email, telefono, estado, idTipoUsuario, password);

        boolean actualizado = controlU.actualizarUsuario(usuario, idUsuario);
        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");
        request.getRequestDispatcher("Usuarios.jsp").forward(request, response);

    }

    private void eliminarUsuario(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        Integer idUsuario = Integer.valueOf(request.getParameter("idEliminar"));
        boolean eliminado = controlU.eliminarUsuario(idUsuario);
        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");
        request.getRequestDispatcher("Usuarios.jsp").forward(request, response);
    }

}
