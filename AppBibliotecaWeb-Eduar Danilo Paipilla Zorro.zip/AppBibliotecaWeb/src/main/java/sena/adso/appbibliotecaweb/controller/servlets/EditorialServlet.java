package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sena.adso.appbibliotecaweb.controller.EditorialController;
import sena.adso.appbibliotecaweb.model.Editorial;

@WebServlet(name = "EditorialServlet", urlPatterns = {"/EditorialServlet"})
public class EditorialServlet extends HttpServlet {

    private final EditorialController controlE = new EditorialController();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || !"Administrador".equals(rol)) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<Editorial> listaEditoriales = controlE.listarEditoriales();
        request.setAttribute("listaEditoriales", listaEditoriales);

        RequestDispatcher rd = request.getRequestDispatcher("Editoriales.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || !"Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        switch (accion) {
            case "crear":
                crearEditorial(request, response);
                break;
            case "editar":
                editarEditorial(request, response);
                break;
            case "eliminar":
                eliminarEditorial(request, response);
                break;
            default:
                response.sendRedirect("EditorialServlet");
                break;
        }
    }

    private void crearEditorial(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        String nombre = request.getParameter("nombre");
        String pais = request.getParameter("pais");
        String sitioWeb = request.getParameter("sitioWeb");

        List<Editorial> lista = new ArrayList<>();
        lista.add(new Editorial(nombre, pais, sitioWeb));

        boolean creado = controlE.insertarEditoriales(lista);

        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creada");

        request.getRequestDispatcher("Editoriales.jsp").forward(request, response);
    }

    private void editarEditorial(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer id = Integer.valueOf(request.getParameter("idEditorial"));
        String nombre = request.getParameter("nombre");
        String pais = request.getParameter("pais");
        String sitioWeb = request.getParameter("sitioWeb");

        Editorial e = new Editorial(nombre, pais, sitioWeb);

        boolean actualizado = controlE.actualizarEditorial(e, id);

        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");

        request.getRequestDispatcher("Editoriales.jsp").forward(request, response);
    }

    private void eliminarEditorial(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer id = Integer.valueOf(request.getParameter("idEliminar"));

        boolean eliminado = controlE.eliminarEditorial(id);

        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminada");

        request.getRequestDispatcher("Editoriales.jsp").forward(request, response);
    }
}
