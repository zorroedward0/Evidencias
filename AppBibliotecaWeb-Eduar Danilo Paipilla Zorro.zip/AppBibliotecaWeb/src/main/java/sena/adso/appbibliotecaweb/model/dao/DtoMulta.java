package sena.adso.appbibliotecaweb.model.dao;

import java.util.List;

public class DtoMulta {

    private int valor;
    private String nombreUser;
    private List<Integer> listaIdsPrestamos;

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public String getNombreUser() {
        return nombreUser;
    }

    public void setNombreUser(String nombreUser) {
        this.nombreUser = nombreUser;
    }

    public List<Integer> getListaIdsPrestamos() {
        return listaIdsPrestamos;
    }

    public void setListaIdsPrestamos(List<Integer> listaIdsPrestamos) {
        this.listaIdsPrestamos = listaIdsPrestamos;
    }

    public DtoMulta() {
    }

    public DtoMulta(int valor, String nombreUser, List<Integer> listaIdsPrestamos) {
        this.valor = valor;
        this.nombreUser = nombreUser;
        this.listaIdsPrestamos = listaIdsPrestamos;
    }

}
