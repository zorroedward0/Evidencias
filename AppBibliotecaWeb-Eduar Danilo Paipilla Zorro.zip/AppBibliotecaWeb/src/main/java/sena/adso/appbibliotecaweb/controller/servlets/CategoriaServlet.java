package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sena.adso.appbibliotecaweb.controller.CategoriaController;
import sena.adso.appbibliotecaweb.model.Categoria;

@WebServlet(name = "CategoriaServlet", urlPatterns = {"/CategoriaServlet"})
public class CategoriaServlet extends HttpServlet {

    private final CategoriaController controlC = new CategoriaController();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || !"Administrador".equals(rol)) {
            response.sendRedirect("login.jsp");
            return;
        }

        List<Categoria> listaCategorias = controlC.listarCategorias();
        request.setAttribute("listaCategorias", listaCategorias);

        RequestDispatcher rd = request.getRequestDispatcher("Categorias.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || !"Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        switch (accion) {
            case "crear":
                crearCategoria(request, response);
                break;
            case "editar":
                editarCategoria(request, response);
                break;
            case "eliminar":
                eliminarCategoria(request, response);
                break;
            default:
                response.sendRedirect("CategoriaServlet");
                break;
        }
    }

    private void crearCategoria(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");

        List<Categoria> lista = new ArrayList<>();
        lista.add(new Categoria(nombre, descripcion));

        boolean creado = controlC.insertarCategorias(lista);

        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creada");

        request.getRequestDispatcher("Categorias.jsp").forward(request, response);
    }

    private void editarCategoria(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer id = Integer.valueOf(request.getParameter("idCategoria"));
        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");

        Categoria c = new Categoria(nombre, descripcion);

        boolean actualizado = controlC.actualizarCategoria(c, id);

        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizada");

        request.getRequestDispatcher("Categorias.jsp").forward(request, response);
    }

    private void eliminarCategoria(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer id = Integer.valueOf(request.getParameter("idEliminar"));

        boolean eliminado = controlC.eliminarCategoria(id);

        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");

        request.getRequestDispatcher("Categorias.jsp").forward(request, response);
    }
}
