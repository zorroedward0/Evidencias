package sena.adso.appbibliotecaweb.model.dao;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Multa;

public interface MultaDaoI {

    public List<Multa> listarMultas();

    public boolean insertarMulta(Multa multa);

    public boolean actualizarMulta(Multa multa);

    public boolean eliminarMulta(Integer id);

    public List<Multa> listarMultasPorUsuario(int idUsuario);

    public int totalMultasPorUsuario(Integer idUsuario);

    public DtoMulta totalMultasPorUsuarioDto(Integer idUsuario);

}
