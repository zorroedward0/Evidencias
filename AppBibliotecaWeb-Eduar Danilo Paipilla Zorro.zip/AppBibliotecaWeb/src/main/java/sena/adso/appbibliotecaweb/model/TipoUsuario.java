package sena.adso.appbibliotecaweb.model;

public class TipoUsuario {
    private final Integer idTipoUsuario;
    private final String nombre;

    public TipoUsuario(Integer idTipoUsuario, String nombre) {
        this.idTipoUsuario = idTipoUsuario;
        this.nombre = nombre;
    }
    public TipoUsuario(String nombre) {
        this(null, nombre);
    }

    public Integer getIdTipoUsuario() {
        return idTipoUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "TipoUsuario{" +
                "idTipoUsuario=" + idTipoUsuario +
                ", nombre='" + nombre + '\'' +
                '}';
    }
}
