package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Categoria;

import java.util.List;

public interface CategoriaDaoI {
    public List<Categoria> listarCategorias();
    public String insertarCategorias(List<Categoria> categorias);
    public String actualizarCategoria(Categoria categoria, Integer idCategoriaI);
    public String eliminarCategoria(Integer idCategoriaI);
}
