package sena.adso.appbibliotecaweb.controller;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Autor;
import sena.adso.appbibliotecaweb.model.dao.AutorDao;
import sena.adso.appbibliotecaweb.model.dao.AutorDaoI;

public class AutorController {
 private final AutorDaoI AutorDao = new AutorDao();

    public List<Autor> listarAutores() {
        return AutorDao.listarAutores();
    }

    public boolean insertarAutores(List<Autor> autores) {
        boolean inserto = AutorDao.insertarAutores(autores)!= null;
        return inserto;
    }

    public boolean actualizarAutor(Autor autor, Integer idAutorI) {
        boolean actualizo = AutorDao.actualizarAutor(autor, idAutorI)!= null;
        return actualizo;
    }

    public boolean eliminarAutor(Integer idAutorI) {
        boolean elimino = AutorDao.eliminarAutor(idAutorI)!=null;
        return elimino;
    }
    
 
}
