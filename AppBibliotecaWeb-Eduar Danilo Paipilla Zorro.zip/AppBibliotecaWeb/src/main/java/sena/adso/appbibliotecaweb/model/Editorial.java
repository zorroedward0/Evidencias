package sena.adso.appbibliotecaweb.model;

public class Editorial {

    private final Integer idEditorial;
    private String nombre;
    private String pais;
    private String sitioWeb;

    public Editorial(Integer idEditorial, String nombre, String pais, String sitioWeb) {
        this.idEditorial = idEditorial;
        this.nombre = nombre;
        this.pais = pais;
        this.sitioWeb = sitioWeb;
    }

    public Editorial(String nombre, String pais, String sitioWeb) {
        this(null, nombre, pais, sitioWeb);
    }

    public Editorial(Integer idEditorial) {
        this.idEditorial = idEditorial;
    }

    public Integer getIdEditorial() {
        return idEditorial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getSitioWeb() {
        return sitioWeb;
    }

    public void setSitioWeb(String sitioWeb) {
        this.sitioWeb = sitioWeb;
    }

    @Override
    public String toString() {
        return "Editorial{"
                + "idEditorial=" + idEditorial
                + ", nombre='" + nombre + '\''
                + ", pais='" + pais + '\''
                + ", sitioWeb='" + sitioWeb + '\''
                + '}';
    }
}
