package sena.adso.appbibliotecaweb.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import sena.adso.appbibliotecaweb.config.ConexionDb;
import sena.adso.appbibliotecaweb.model.Multa;

public class MultaDao implements MultaDaoI {

    @Override
    public List<Multa> listarMultas() {
        List<Multa> multas = new ArrayList<>();
        String sql = "SELECT idmulta, idprestamo, valor, pagada, fecha FROM multa";
        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                multas.add(new Multa(
                        rs.getObject("idmulta", Integer.class),
                        rs.getObject("idprestamo", Integer.class),
                        rs.getInt("valor"),
                        rs.getBoolean("pagada"),
                        rs.getDate("fecha").toLocalDate()
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar multas ", e);
        }
        return multas;
    }

    @Override
    public List<Multa> listarMultasPorUsuario(int idUsuario) {

        List<Multa> multas = new ArrayList<>();

        String sql
                = "SELECT m.* "
                + "FROM multa m "
                + "INNER JOIN prestamo p ON m.idPrestamo = p.idPrestamo "
                + "WHERE p.idUsuario = ? ";

        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    multas.add(new Multa(
                            rs.getObject("idmulta", Integer.class),
                            rs.getObject("idprestamo", Integer.class),
                            rs.getInt("valor"),
                            rs.getBoolean("pagada"),
                            rs.getDate("fecha").toLocalDate()
                    ));
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al listar multas por usuario", e);
        }

        return multas;
    }

    @Override
    public boolean insertarMulta(Multa multa) {
        String sql = "INSERT INTO multa (idprestamo, valor, pagada,fecha) VALUES (?, ?, ?,?)";
        try (Connection cn = ConexionDb.establecerConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setObject(1, multa.getIdPrestamo());
            ps.setObject(2, multa.getValor());
            ps.setObject(3, multa.getPagada());
            ps.setObject(4, multa.getFecha());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar multa ", e);
        }
    }

    @Override
    public boolean actualizarMulta(Multa multa) {
        String sql = "UPDATE multa SET idprestamo=?, valor=?, pagada=?, fecha=? WHERE idmulta=?";

        try (Connection cn = ConexionDb.establecerConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {

            ps.setObject(1, multa.getIdPrestamo());
            ps.setObject(2, multa.getValor());
            ps.setObject(3, multa.getPagada());
            ps.setObject(4, multa.getFecha());
            ps.setObject(5, multa.getIdMulta());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar multa ", e);
        }
    }

    @Override
    public boolean eliminarMulta(Integer id) {
        String sql = " DELETE FROM multa WHERE idmulta = ?";
        try (Connection cn = ConexionDb.establecerConexion(); PreparedStatement ps = cn.prepareStatement(sql)) {
            ps.setObject(1, id);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar multa ", e);
        }
    }

    @Override
    public int totalMultasPorUsuario(Integer idUsuario) {

        String sql
                = "SELECT COALESCE(SUM(m.valor), 0) AS total "
                + "FROM multa m "
                + "INNER JOIN prestamo p ON m.idPrestamo = p.idPrestamo "
                + "WHERE p.idUsuario = ? "
                + "AND m.pagada = true";

        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("total");
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al calcular total de multas por usuario", e);
        }

        return 0;
    }

    @Override
    public DtoMulta totalMultasPorUsuarioDto(Integer idUsuario) {

        String sql
                = "SELECT "
                + "COALESCE(SUM(m.valor), 0) AS total, "
                + "u.nombre AS nombreUser, "
                + "GROUP_CONCAT(DISTINCT p.idprestamo) AS prestamos "
                + "FROM multa m "
                + "INNER JOIN prestamo p ON m.idPrestamo = p.idprestamo "
                + "INNER JOIN usuario u ON p.idUsuario = u.idusuario "
                + "WHERE p.idUsuario = ? "
                + "AND m.pagada = 0 "
                + "GROUP BY u.idusuario, u.nombre";

        DtoMulta dto = new DtoMulta();

        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuario);

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {

                    dto.setValor(rs.getInt("total"));
                    dto.setNombreUser(rs.getString("nombreUser"));

                    String prestamosStr = rs.getString("prestamos");

                    List<Integer> listaPrestamos = new java.util.ArrayList<>();

                    if (prestamosStr != null && !prestamosStr.isEmpty()) {
                        String[] partes = prestamosStr.split(",");

                        for (String p : partes) {
                            listaPrestamos.add(Integer.parseInt(p.trim()));
                        }
                    }

                    dto.setListaIdsPrestamos(listaPrestamos);

                } else {
                    dto.setValor(0);
                    dto.setNombreUser(null);
                    dto.setListaIdsPrestamos(new java.util.ArrayList<>());
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al obtener DTO de multas por usuario", e);
        }

        return dto;
    }

}
