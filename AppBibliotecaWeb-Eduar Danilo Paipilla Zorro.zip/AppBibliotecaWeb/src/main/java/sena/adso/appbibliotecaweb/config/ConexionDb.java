package sena.adso.appbibliotecaweb.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDb {

    private static final String URL = "jdbc:mysql://localhost:3306/dbbiblioteca";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";

    public static Connection establecerConexion() throws SQLException {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            return DriverManager.getConnection(URL, USER, PASSWORD);

        } catch (ClassNotFoundException e) {
            System.out.println("Driver no encontrado: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return null;
    }

}
