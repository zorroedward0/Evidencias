package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.config.ConexionDb;
import sena.adso.appbibliotecaweb.model.Libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import sena.adso.appbibliotecaweb.model.Autor;
import sena.adso.appbibliotecaweb.model.Categoria;
import sena.adso.appbibliotecaweb.model.Editorial;
import sena.adso.appbibliotecaweb.model.Prestamo;

public class LibroDao implements LibroDaoI {

    @Override
    public List<Libro> listarLibros() {

        Map<Integer, Libro> libroMap = new LinkedHashMap<>();

        String sql = "SELECT l.*, e.nombre AS ed_nombre, e.pais AS ed_pais, "
                + "a.idAutor, a.nombre AS au_nombre, a.apellido AS au_apellido, a.fechaNacimiento, "
                + "c.idCategoria, c.nombre AS cat_nombre "
                + "FROM Libro l "
                + "INNER JOIN Editorial e ON l.idEditorial = e.idEditorial "
                + "LEFT JOIN libroautor la ON l.idLibro = la.idLibro "
                + "LEFT JOIN Autor a ON la.idAutor = a.idAutor "
                + "LEFT JOIN librocategoria lc ON l.idLibro = lc.idLibro "
                + "LEFT JOIN Categoria c ON lc.idCategoria = c.idCategoria";

        try (Connection conn = ConexionDb.establecerConexion(); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int idLibro = rs.getInt("idLibro");

                Libro libro = libroMap.computeIfAbsent(idLibro, id -> {
                    Libro nuevo = new Libro(id);
                    try {
                        nuevo.setTitulo(rs.getString("titulo"));
                        nuevo.setIsbn(rs.getString("isbn"));
                        nuevo.setDestacado(rs.getBoolean("destacado"));
                        nuevo.setEstado(rs.getBoolean("disponible"));
                        nuevo.setImagen(rs.getString("imagen"));
                        nuevo.setAnioPublicacion(rs.getInt("añoPublicacion"));
                        nuevo.setNumPag(rs.getInt("numPag"));
                        Editorial ed = new Editorial(rs.getInt("idEditorial"));
                        ed.setNombre(rs.getString("ed_nombre"));
                        nuevo.setEditorial(ed);
                    } catch (SQLException e) {
                        throw new RuntimeException("Error al traer Editorial del libro", e);
                    }
                    return nuevo;
                });

                int idAutor = rs.getInt("idAutor");
                if (idAutor > 0 && libro.getAutores().stream().noneMatch(a -> a.getIdAutor() == idAutor)) {
                    Autor autor = new Autor(idAutor, rs.getDate("fechaNacimiento").toLocalDate());
                    autor.setNombre(rs.getString("au_nombre"));
                    autor.setApellido(rs.getString("au_apellido"));
                    libro.getAutores().add(autor);
                }

                int idCat = rs.getInt("idCategoria");
                if (idCat > 0 && libro.getCategorias().stream().noneMatch(c -> c.getIdCategoria() == idCat)) {
                    Categoria cat = new Categoria(idCat);
                    cat.setNombre(rs.getString("cat_nombre"));
                    libro.getCategorias().add(cat);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar libros ", e);
        }
        return new ArrayList<>(libroMap.values());
    }

    @Override
    public boolean insertarLibro(Libro libro, List<Integer> idsAutores, List<Integer> idsCategorias) {

        String sqlLibro = "INSERT INTO Libro (titulo, isbn, añoPublicacion, numPag, disponible, idEditorial, destacado, imagen) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        String sqlAutor = "INSERT INTO libroautor (idLibro, idAutor) VALUES (?, ?)";
        String sqlCat = "INSERT INTO librocategoria (idLibro, idCategoria) VALUES (?, ?)";

        boolean insertado = false;

        Connection conn = null;
        try {
            conn = ConexionDb.establecerConexion();
            conn.setAutoCommit(false);

            int idGenerado = 0;
            try (PreparedStatement psLibro = conn.prepareStatement(sqlLibro, Statement.RETURN_GENERATED_KEYS)) {
                psLibro.setString(1, libro.getTitulo());
                psLibro.setString(2, libro.getIsbn());
                psLibro.setInt(3, libro.getAnioPublicacion());
                psLibro.setInt(4, libro.getNumPag());
                psLibro.setBoolean(5, libro.getEstado());
                psLibro.setInt(6, libro.getEditorial().getIdEditorial());
                psLibro.setBoolean(7, libro.getDestacado());
                psLibro.setString(8, libro.getImagen());

                psLibro.executeUpdate();

                ResultSet rs = psLibro.getGeneratedKeys();
                if (rs.next()) {
                    idGenerado = rs.getInt(1);
                }
                if (idGenerado == 0) {
                    throw new SQLException("No se pudo obtener el ID del libro insertado");
                }
            }

            try (PreparedStatement psAutor = conn.prepareStatement(sqlAutor)) {
                for (Integer idAutor : idsAutores) {
                    psAutor.setInt(1, idGenerado);
                    psAutor.setInt(2, idAutor);
                    psAutor.addBatch();
                }
                psAutor.executeBatch();
            }

            try (PreparedStatement psCat = conn.prepareStatement(sqlCat)) {
                for (Integer idCat : idsCategorias) {
                    psCat.setInt(1, idGenerado);
                    psCat.setInt(2, idCat);
                    psCat.addBatch();
                }
                psCat.executeBatch();
            }

            conn.commit();
            insertado = true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new RuntimeException("Error al insertar libro ", ex);
                }
            }
            throw new RuntimeException("Error al insertar libro ", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    throw new RuntimeException("Error al cerrar conexion", e);
                }
            }
        }
        return insertado;
    }

    @Override
    public boolean actualizarLibro(Libro libro, List<Integer> nuevosIdsAutores, List<Integer> nuevosIdsCategorias) {
        String sqlLibro = "UPDATE Libro SET titulo=?, isbn=?, añoPublicacion=?, numPag=?, disponible=?, idEditorial=?, destacado=?, imagen=? WHERE idLibro=?";
        String sqlBorrarAutores = "DELETE FROM libroautor WHERE idLibro = ?";
        String sqlBorrarCategorias = "DELETE FROM librocategoria WHERE idLibro = ?";
        String sqlInsertAutor = "INSERT INTO libroautor (idLibro, idAutor) VALUES (?, ?)";
        String sqlInsertCat = "INSERT INTO librocategoria (idLibro, idCategoria) VALUES (?, ?)";

        boolean actualizado = false;

        Connection conn = null;
        try {
            conn = ConexionDb.establecerConexion();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(sqlLibro)) {
                ps.setString(1, libro.getTitulo());
                ps.setString(2, libro.getIsbn());
                ps.setInt(3, libro.getAnioPublicacion());
                ps.setInt(4, libro.getNumPag());
                ps.setBoolean(5, libro.getEstado());
                ps.setInt(6, libro.getEditorial().getIdEditorial());
                ps.setBoolean(7, libro.getDestacado());
                ps.setString(8, libro.getImagen());
                ps.setInt(9, libro.getIdLibro());
                int filas = ps.executeUpdate();
                if (filas == 0) {
                    throw new SQLException("No se encontró el libro con ID: " + libro.getIdLibro());
                }
            }

            try (PreparedStatement psDelA = conn.prepareStatement(sqlBorrarAutores); PreparedStatement psDelC = conn.prepareStatement(sqlBorrarCategorias)) {
                psDelA.setInt(1, libro.getIdLibro());
                psDelC.setInt(1, libro.getIdLibro());
                psDelA.executeUpdate();
                psDelC.executeUpdate();
            }

            try (PreparedStatement psInsA = conn.prepareStatement(sqlInsertAutor)) {
                for (int idAutor : nuevosIdsAutores) {
                    psInsA.setInt(1, libro.getIdLibro());
                    psInsA.setInt(2, idAutor);
                    psInsA.addBatch();
                }
                psInsA.executeBatch();
            }

            try (PreparedStatement psInsC = conn.prepareStatement(sqlInsertCat)) {
                for (int idCat : nuevosIdsCategorias) {
                    psInsC.setInt(1, libro.getIdLibro());
                    psInsC.setInt(2, idCat);
                    psInsC.addBatch();
                }
                psInsC.executeBatch();
            }

            conn.commit();
            actualizado = true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                }
            }
            throw new RuntimeException("Error al intentar actualizar el libro ", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    throw new RuntimeException("Error al cerrar conexion", e);
                }
            }
        }

        return actualizado;
    }

    @Override
    public boolean eliminarLibro(Integer idLibro) {

        final PrestamoDaoI prestamoDao = new PrestamoDao();
        List<Prestamo> prestamos = prestamoDao.listarPrestamos();
        for (Prestamo prestamo : prestamos) {
            if (Objects.equals(prestamo.getIdLibro(), idLibro)) {
                return false;
            }
        }

        boolean eliminado = false;

        if (idLibro == null) {
            return eliminado;
        }

        String sqlRelAutores = "DELETE FROM libroautor WHERE idLibro = ?";
        String sqlRelCategorias = "DELETE FROM librocategoria WHERE idLibro = ?";
        String sqlLibro = "DELETE FROM Libro WHERE idLibro = ?";

        Connection conn = null;
        try {
            conn = ConexionDb.establecerConexion();
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(sqlRelAutores)) {
                ps.setInt(1, idLibro);
                ps.executeUpdate();
            }

            try (PreparedStatement ps = conn.prepareStatement(sqlRelCategorias)) {
                ps.setInt(1, idLibro);
                ps.executeUpdate();
            }

            try (PreparedStatement ps = conn.prepareStatement(sqlLibro)) {
                ps.setInt(1, idLibro);
                int filasBorradas = ps.executeUpdate();

                if (filasBorradas > 0) {
                    eliminado = true;
                }
            }

            conn.commit();
            eliminado = true;

        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ex) {
                    throw new RuntimeException("Error al eliminar libro ", ex);
                }
            }
            throw new RuntimeException("Error al eliminar libro ", e);
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException e) {
                    throw new RuntimeException("Error al cerrar conexion", e);
                }
            }
        }
        return eliminado;
    }

    @Override
    public List<Libro> listarLibrosPorCategoria(Integer idCategoria) {
        if (idCategoria == null) {
            return null;
        }
        Map<Integer, Libro> libroMap = new LinkedHashMap<>();

        String sql = "SELECT l.*, e.nombre AS ed_nombre, e.pais AS ed_pais, "
                + "a.idAutor, a.nombre AS au_nombre, a.apellido AS au_apellido, "
                + "c.idCategoria, c.nombre AS cat_nombre "
                + "FROM Libro l "
                + "INNER JOIN Editorial e ON l.idEditorial = e.idEditorial "
                + "LEFT JOIN libroautor la ON l.idLibro = la.idLibro "
                + "LEFT JOIN Autor a ON la.idAutor = a.idAutor "
                + "LEFT JOIN librocategoria lc ON l.idLibro = lc.idLibro "
                + "LEFT JOIN Categoria c ON lc.idCategoria = c.idCategoria"
                + "WHERE c.idCategoria = ?";

        try (Connection conn = ConexionDb.establecerConexion(); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {

            pstmt.setInt(1, idCategoria);
            while (rs.next()) {
                int idLibro = rs.getInt("idLibro");

                Libro libro = libroMap.computeIfAbsent(idLibro, id -> {
                    Libro nuevo = new Libro(id);
                    try {
                        nuevo.setTitulo(rs.getString("titulo"));
                        nuevo.setIsbn(rs.getString("isbn"));
                        nuevo.setAnioPublicacion(rs.getInt("añoPublicacion"));

                        Editorial ed = new Editorial(rs.getInt("idEditorial"));
                        ed.setNombre(rs.getString("ed_nombre"));
                        nuevo.setEditorial(ed);
                    } catch (SQLException e) {
                        throw new RuntimeException("Error al traer Editorial del libro", e);
                    }
                    return nuevo;
                });

                int idAutor = rs.getInt("idAutor");
                if (idAutor > 0 && libro.getAutores().stream().noneMatch(a -> a.getIdAutor() == idAutor)) {
                    Autor autor = new Autor(idAutor, rs.getDate("fechaNacimiento").toLocalDate());
                    autor.setNombre(rs.getString("au_nombre"));
                    autor.setApellido(rs.getString("au_apellido"));
                    libro.getAutores().add(autor);
                }

                int idCat = rs.getInt("idCategoria");
                if (idCat > 0 && libro.getCategorias().stream().noneMatch(c -> c.getIdCategoria() == idCat)) {
                    Categoria cat = new Categoria(idCat);
                    cat.setNombre(rs.getString("cat_nombre"));
                    libro.getCategorias().add(cat);
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar libros ", e);
        }
        return new ArrayList<>(libroMap.values());
    }

    @Override
    public int cantidadLibros() {
        return listarLibros().size();
    }
}
