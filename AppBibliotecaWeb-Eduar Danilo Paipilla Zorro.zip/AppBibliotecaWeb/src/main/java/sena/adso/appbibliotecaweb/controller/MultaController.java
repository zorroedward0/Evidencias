package sena.adso.appbibliotecaweb.controller;

import java.time.LocalDate;
import java.util.List;
import sena.adso.appbibliotecaweb.model.Multa;
import sena.adso.appbibliotecaweb.model.dao.DtoMulta;
import sena.adso.appbibliotecaweb.model.dao.MultaDao;
import sena.adso.appbibliotecaweb.model.dao.MultaDaoI;

public class MultaController {

    private final MultaDaoI multaDao = new MultaDao();

    public List<Multa> listarMultas() {
        return multaDao.listarMultas();
    }

    public List<Multa> listarMultasId(Integer id) {
        return multaDao.listarMultasPorUsuario(id);
    }

    public boolean insertarMulta(Multa multa) {
        return multaDao.insertarMulta(multa);
    }

    public boolean actualizarMulta(Multa multa) {
        return multaDao.actualizarMulta(multa);
    }

    public boolean eliminarMulta(Integer id) {
        return multaDao.eliminarMulta(id);
    }

    public Multa generarMulta(Integer id, Integer dias) {
        Integer valorMulta = dias * 1000;
        Multa multaG = new Multa();
        multaG.setIdPrestamo(id);
        multaG.setPagada(false);
        multaG.setValor(valorMulta);
        multaG.setFecha(LocalDate.now());
        return multaG;

    }

    public boolean validarMulta(Multa multa) {
        List<Multa> listaMultas = multaDao.listarMultas();
        for (Multa m : listaMultas) {
            if (multa.getIdPrestamo().equals(m.getIdPrestamo()) && multa.getFecha().equals(m.getFecha())) {
                return true;
            }
        }
        return false;
    }

    public boolean validarMultaId(Multa multa) {
        List<Multa> listaMultas = multaDao.listarMultas();
        for (Multa m : listaMultas) {
            if (multa.getIdPrestamo().equals(m.getIdPrestamo())) {
                return true;
            }
        }
        return false;
    }

    public int totalMultasPorUsuario(Integer idUsuario) {
        return multaDao.totalMultasPorUsuario(idUsuario);
    }

    public DtoMulta totalMultasPorUsuarioDto(Integer idUsuario) {
        return multaDao.totalMultasPorUsuarioDto(idUsuario);
    }
}
