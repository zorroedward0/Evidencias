package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Autor;

import java.util.List;

public interface AutorDaoI {
public List<Autor> listarAutores();
public String insertarAutores(List<Autor> autores);
public String actualizarAutor(Autor autor, Integer idAutorI);
public String eliminarAutor(Integer idAutorI);
}
