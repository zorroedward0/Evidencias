package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import sena.adso.appbibliotecaweb.controller.LibroController;
import sena.adso.appbibliotecaweb.model.Libro;
import java.util.List;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import sena.adso.appbibliotecaweb.controller.AutorController;
import sena.adso.appbibliotecaweb.controller.CategoriaController;
import sena.adso.appbibliotecaweb.controller.EditorialController;
import sena.adso.appbibliotecaweb.model.Autor;
import sena.adso.appbibliotecaweb.model.Categoria;
import sena.adso.appbibliotecaweb.model.Editorial;

@WebServlet(name = "LibroServlet", urlPatterns = {"/LibroServlet"})
@MultipartConfig(
        fileSizeThreshold = 1024 * 1024,
        maxFileSize = 1024 * 1024 * 10,
        maxRequestSize = 1024 * 1024 * 15
)
public class LibroServlet extends HttpServlet {

    private final LibroController controlL = new LibroController();
    private final CategoriaController controlC = new CategoriaController();
    private final AutorController controlA = new AutorController();
    private final EditorialController controlE = new EditorialController();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || (!"Cliente".equals(rol) && !"Administrador".equals(rol))) {
            response.sendRedirect("inicio.jsp");
            return;
        } else if ("Cliente".equals(rol)) {
            List<Libro> listaLibros = controlL.listarLibros();
            request.setAttribute("listaLibros", listaLibros);

            List<Categoria> listaCategorias = controlC.listarCategorias();
            request.setAttribute("listaCategorias", listaCategorias);

            List<Autor> listaAutores = controlA.listarAutores();
            request.setAttribute("listaAutores", listaAutores);

            List<Editorial> listaEditorales = controlE.listarEditoriales();
            request.setAttribute("listaEditoriales", listaEditorales);

            RequestDispatcher rd = request.getRequestDispatcher("LibrosCliente.jsp");
            rd.forward(request, response);
        } else if ("Administrador".equals(rol)) {
            List<Libro> listaLibros = controlL.listarLibros();
            request.setAttribute("listaLibros", listaLibros);

            List<Categoria> listaCategorias = controlC.listarCategorias();
            request.setAttribute("listaCategorias", listaCategorias);

            List<Autor> listaAutores = controlA.listarAutores();
            request.setAttribute("listaAutores", listaAutores);

            List<Editorial> listaEditorales = controlE.listarEditoriales();
            request.setAttribute("listaEditoriales", listaEditorales);

            RequestDispatcher rd = request.getRequestDispatcher("Libros.jsp");
            rd.forward(request, response);
        } else {
            response.sendRedirect("inicio.jsp");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null && !"Cliente".equals(rol) && "Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }
        String accion = request.getParameter("accion");

        switch (accion) {
            case "crear":
                crearLibro(request, response);
                break;
            case "editar":
                editarLibro(request, response);
                break;
            case "eliminar":
                eliminarLibro(request, response);
                break;
            default:
                response.sendRedirect("usuarios.jsp");
                break;
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

    private void crearLibro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String titulo = request.getParameter("titulo");
        String isbn = request.getParameter("isbn");
        Integer anioPublicacion = Integer.valueOf(request.getParameter("anioPublicacion"));
        int numPag = Integer.parseInt(request.getParameter("numPag"));
        boolean estado = Boolean.parseBoolean(request.getParameter("estado"));
        boolean destacado = Boolean.parseBoolean(request.getParameter("destacado"));
        int idEditorial = Integer.parseInt(request.getParameter("editorial"));
        ArrayList<Integer> idsAutores = new ArrayList<>();
        var autoresid = request.getParameterValues("autores");
        if (autoresid != null) {
            for (String id : autoresid) {
                idsAutores.add(Integer.valueOf(id));
            }
        } else {
            idsAutores = null;
        }

        ArrayList<Integer> idsCategorias = new ArrayList<>();
        var categoriasid = request.getParameterValues("categorias");
        if (categoriasid != null) {
            for (String id : categoriasid) {
                idsCategorias.add(Integer.valueOf(id));
            }
        } else {
            idsCategorias = null;
        }

        Libro libro = new Libro();
        Editorial editorial = new Editorial(idEditorial);
        libro.setTitulo(titulo);
        libro.setIsbn(isbn);
        libro.setAnioPublicacion(anioPublicacion);
        libro.setNumPag(numPag);
        libro.setEditorial(editorial);
        libro.setEstado(estado);
        libro.setDestacado(destacado);

        Part filePart = request.getPart("imagencrear");

        if (filePart != null && filePart.getSize() > 0) {

            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

            String fileNameFinal = System.currentTimeMillis() + "_" + fileName;

            String uploadPath = getServletContext().getRealPath("/imagenes");

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            filePart.write(uploadPath + File.separator + fileNameFinal);

            libro.setImagen("imagenes/" + fileNameFinal);

        } else {
            request.setAttribute("hecho", false);
            request.setAttribute("accion", "creado");
            request.getRequestDispatcher("Libros.jsp").forward(request, response);
            return;
        }

        boolean creado = controlL.insertarLibro(libro, idsAutores, idsCategorias);
        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creado");
        request.getRequestDispatcher("Libros.jsp").forward(request, response);

    }

    private void editarLibro(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String titulo = request.getParameter("titulo");
        String isbn = request.getParameter("isbn");
        String imagenAntigua = request.getParameter("imagenUrl");
        Integer anioPublicacion = Integer.valueOf(request.getParameter("anioPublicacion"));
        int numPag = Integer.parseInt(request.getParameter("numPag"));
        int idLibro = Integer.parseInt(request.getParameter("idLibro"));
        boolean estado = Boolean.parseBoolean(request.getParameter("estado"));
        boolean destacado = Boolean.parseBoolean(request.getParameter("destacado"));
        int idEditorial = Integer.parseInt(request.getParameter("editorial"));
        ArrayList<Integer> nuevosIdsAutores = new ArrayList<>();
        String[] autoresid = request.getParameterValues("autores");
        if (autoresid != null) {
            for (String id : autoresid) {
                nuevosIdsAutores.add(Integer.valueOf(id));
            }
        } else {
            nuevosIdsAutores = null;
        }

        ArrayList<Integer> nuevosIdsCategorias = new ArrayList<>();
        String[] categoriasid = request.getParameterValues("categorias");
        if (categoriasid != null) {
            for (String id : categoriasid) {
                nuevosIdsCategorias.add(Integer.valueOf(id));
            }
        } else {
            nuevosIdsCategorias = null;
        }

        Libro libro = new Libro(idLibro);
        Editorial editorial = new Editorial(idEditorial);
        libro.setTitulo(titulo);
        libro.setIsbn(isbn);
        libro.setAnioPublicacion(anioPublicacion);
        libro.setNumPag(numPag);
        libro.setEditorial(editorial);
        libro.setEstado(estado);
        libro.setDestacado(destacado);

        Part filePart = request.getPart("imagen");

        if (filePart != null && filePart.getSize() > 0) {

            String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();

            String fileNameFinal = System.currentTimeMillis() + "_" + fileName;

            String uploadPath = getServletContext().getRealPath("/imagenes");

            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            filePart.write(uploadPath + File.separator + fileNameFinal);

            libro.setImagen("imagenes/" + fileNameFinal);

        } else if(filePart==null || filePart.getSize()<=0) {
          libro.setImagen(imagenAntigua);
        } else {
            request.setAttribute("hecho", false);
            request.setAttribute("accion", "actualizado");
            request.getRequestDispatcher("Libros.jsp").forward(request, response);
        }

        boolean actualizado = controlL.actualizarLibro(libro, nuevosIdsAutores, nuevosIdsCategorias);
        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");
        request.getRequestDispatcher("Libros.jsp").forward(request, response);
    }

    private void eliminarLibro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Integer idLibro = Integer.valueOf(request.getParameter("idEliminar"));
        String imagenE = request.getParameter("imagenE");
        if (imagenE != null) {

            String rutaImagen = getServletContext().getRealPath("/") + imagenE;

            File archivo = new File(rutaImagen);

            if (archivo.exists()) {
                archivo.delete();
            }
        }

        boolean eliminado = controlL.eliminarLibro(idLibro);
        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");
        request.getRequestDispatcher("Libros.jsp").forward(request, response);
    }

}
