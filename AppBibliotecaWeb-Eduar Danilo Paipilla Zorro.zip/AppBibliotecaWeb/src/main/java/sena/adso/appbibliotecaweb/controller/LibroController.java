package sena.adso.appbibliotecaweb.controller;

import java.util.ArrayList;
import java.util.List;
import sena.adso.appbibliotecaweb.model.Libro;
import sena.adso.appbibliotecaweb.model.dao.LibroDao;
import sena.adso.appbibliotecaweb.model.dao.LibroDaoI;

public class LibroController {

    private final LibroDaoI libroDao = new LibroDao();

    public List<Libro> listarLibros() {
        return libroDao.listarLibros();
    }

    public boolean insertarLibro(Libro libro, List<Integer> idsAutores, List<Integer> idsCategorias) {
        return libroDao.insertarLibro(libro, idsAutores, idsCategorias);
    }

    public boolean actualizarLibro(Libro libro, List<Integer> nuevosIdsAutores, List<Integer> nuevosIdsCategorias) {
        return libroDao.actualizarLibro(libro, nuevosIdsAutores, nuevosIdsCategorias);
    }

    public boolean eliminarLibro(Integer idLibroI) {

        return libroDao.eliminarLibro(idLibroI);
    }

    public List<Libro> listarLibrosPorCategoria(Integer idCategoria) {
        return libroDao.listarLibrosPorCategoria(idCategoria);
    }

    public int cantidadLibros() {
        return libroDao.cantidadLibros();
    }

    public List<Libro> librosDestacados() {
        List<Libro> listaDestacados = new ArrayList<>();
        for (Libro libro : libroDao.listarLibros()) {
            if (libro.getDestacado() == true) {
                listaDestacados.add(libro);
            }
        }
        return listaDestacados;
    }

}
