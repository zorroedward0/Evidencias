package sena.adso.appbibliotecaweb.controller;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import sena.adso.appbibliotecaweb.model.Multa;
import sena.adso.appbibliotecaweb.model.Prestamo;
import sena.adso.appbibliotecaweb.model.Usuario;
import sena.adso.appbibliotecaweb.model.dao.PrestamoDaoI;
import sena.adso.appbibliotecaweb.model.dao.PrestamoDao;

public class PrestamoController {

    private final PrestamoDaoI prestamoDao = new PrestamoDao();
    private final MultaController controlM = new MultaController();

    public List<Prestamo> listarPrestamos() {
        List<Prestamo> listaPrestamos = prestamoDao.listarPrestamos();
        LocalDate hoy = LocalDate.now();

        for (Prestamo prestamo : listaPrestamos) {
            if (prestamo.getEstado() == true) {
                LocalDate fechaEsperada = prestamo.getFechaDevolucionEsperada();
                long dias = ChronoUnit.DAYS.between(hoy, fechaEsperada);
                if (dias < 0) {
                    long diasMulta = Math.abs(dias);
                    Multa multaGenerada = controlM.generarMulta(prestamo.getIdPrestamo(), Math.toIntExact(diasMulta));
                    boolean multaExiste = controlM.validarMultaId(multaGenerada);
                    if (!multaExiste) {
                        controlM.insertarMulta(multaGenerada);
                    } else if (multaExiste) {
                        boolean multaHoyExiste = controlM.validarMulta(multaGenerada);
                        if (!multaHoyExiste) {
                            controlM.actualizarMulta(multaGenerada);
                        }
                    }
                }
            }
        }
        return listaPrestamos;
    }

    public boolean insertarPrestamo(Prestamo p) {
        return prestamoDao.insertarPrestamo(p);
    }

    public boolean actualizarPrestamo(Prestamo prestamo, Integer idPrestamoI) {
        return prestamoDao.actualizarPrestamo(prestamo, idPrestamoI);
    }

    public boolean eliminarPrestamo(Prestamo p) {
        return prestamoDao.eliminarPrestamo(p);
    }

    public int cantdadPrestamos() {
        return prestamoDao.cantidadPrestamos();
    }
    
    public Usuario obtenerUsuarioPorPrestamo(Integer idPrestamo){
        return prestamoDao.obtenerUsuarioPorPrestamo(idPrestamo);
    }

    public boolean validarMultas(Integer id) {
        List<Multa> listaMultas = controlM.listarMultas();
        List<Prestamo> listaPrestamos = prestamoDao.listarPrestamos();

        for (Prestamo prestamo : listaPrestamos) {
            if (prestamo.getIdUsuario().equals(id)) {

                for (Multa multa : listaMultas) {
                    if (prestamo.getIdPrestamo().equals(multa.getIdPrestamo()) && multa.getPagada() != true) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
