package sena.adso.appbibliotecaweb.model;

import java.time.LocalDate;

public class Prestamo {

    private Integer idPrestamo;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucionEsperada;
    private LocalDate fechaDevolucionReal;
    private boolean estado;
    private Integer idLibro;
    private Integer idUsuario;

    public Prestamo(Integer idPrestamo, LocalDate fechaPrestamo, LocalDate fechaDevolucionEsperada, LocalDate fechaDevolucionReal, boolean estado, Integer idLibro, Integer idUsuario) {
        this.idPrestamo = idPrestamo;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucionEsperada = fechaDevolucionEsperada;
        this.fechaDevolucionReal = fechaDevolucionReal;
        this.estado = estado;
        this.idLibro = idLibro;
        this.idUsuario = idUsuario;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public void setFechaDevolucionEsperada(LocalDate fechaDevolucionEsperada) {
        this.fechaDevolucionEsperada = fechaDevolucionEsperada;
    }

    public void setIdPrestamo(Integer idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public void setIdLibro(Integer idLibro) {
        this.idLibro = idLibro;
    }

    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Prestamo(LocalDate fechaPrestamo, LocalDate fechaDevolucionEsperada, Integer idLibro, Integer idUsuario) {
        this(null, fechaPrestamo, fechaDevolucionEsperada, null, true, idLibro, idUsuario);
    }

    public Prestamo() {
    }

    public Integer getIdPrestamo() {
        return idPrestamo;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public LocalDate getFechaDevolucionEsperada() {
        return fechaDevolucionEsperada;
    }

    public LocalDate getFechaDevolucionReal() {
        return fechaDevolucionReal;
    }

    public void setFechaDevolucionReal(LocalDate fechaDevolucionReal) {
        this.fechaDevolucionReal = fechaDevolucionReal;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Integer getIdLibro() {
        return idLibro;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    @Override
    public String toString() {
        return "Prestamo{"
                + "idPrestamo=" + idPrestamo
                + ", fechaPrestamo=" + fechaPrestamo
                + ", fechaDevolucionEsperada=" + fechaDevolucionEsperada
                + ", fechaDevolucionReal=" + fechaDevolucionReal
                + ", estado=" + estado
                + ", idLibro=" + idLibro
                + ", idUsuario=" + idUsuario
                + '}';
    }
}
