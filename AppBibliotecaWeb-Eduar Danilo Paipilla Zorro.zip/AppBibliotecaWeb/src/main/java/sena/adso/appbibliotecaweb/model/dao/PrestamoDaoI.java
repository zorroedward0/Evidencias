package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Prestamo;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Usuario;

public interface PrestamoDaoI {
    public List<Prestamo> listarPrestamos();
    public boolean insertarPrestamo(Prestamo p);
    public boolean actualizarPrestamo(Prestamo prestamo, Integer idPrestamoI);
    public boolean eliminarPrestamo(Prestamo p);
    public int cantidadPrestamos();
    public Usuario obtenerUsuarioPorPrestamo(Integer idPrestamo);
}
