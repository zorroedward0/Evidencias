package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sena.adso.appbibliotecaweb.controller.MultaController;
import sena.adso.appbibliotecaweb.model.Multa;
import sena.adso.appbibliotecaweb.model.Usuario;

@WebServlet(name = "MultaServlet", urlPatterns = {"/MultaServlet"})
public class MultaServlet extends HttpServlet {

    private final MultaController controlM = new MultaController();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");
        Usuario user = (Usuario) session.getAttribute("usuarioLogueado");

        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        if (rol == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        if ("Cliente".equalsIgnoreCase(rol)) {
            List<Multa> listaMultas = controlM.listarMultasId(user.getIdUsuario());
            request.setAttribute("listaMultas", listaMultas);
            request.getRequestDispatcher("MultasCliente.jsp").forward(request, response);

        } else if ("Administrador".equalsIgnoreCase(rol)) {
            List<Multa> listaMultas = controlM.listarMultas();
            request.setAttribute("listaMultas", listaMultas);
            request.getRequestDispatcher("Multas.jsp").forward(request, response);

        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || !"Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }

        String accion = request.getParameter("accion");

        switch (accion) {
            case "editar":
                editarMulta(request, response);
                break;
            case "eliminar":
                eliminarMulta(request, response);
                break;
            default:
                response.sendRedirect("MultaServlet");
                break;
        }
    }

    private void editarMulta(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer idMulta = Integer.valueOf(request.getParameter("idMulta"));
        Integer idPrestamo = Integer.valueOf(request.getParameter("idPrestamo"));
        Integer valor = Integer.valueOf(request.getParameter("valor"));
        boolean pagada = Boolean.parseBoolean(request.getParameter("pagada"));

        String fechaStr = request.getParameter("fecha");
        LocalDate fecha = null;

        if (fechaStr != null && !fechaStr.isEmpty()) {
            fecha = LocalDate.parse(fechaStr);
        }

        Multa m = new Multa();
        m.setIdMulta(idMulta);
        m.setIdPrestamo(idPrestamo);
        m.setValor(valor);
        m.setPagada(pagada);
        m.setFecha(fecha);

        boolean actualizado = controlM.actualizarMulta(m);

        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");

        request.getRequestDispatcher("Multas.jsp").forward(request, response);
    }

    private void eliminarMulta(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer idMulta = Integer.valueOf(request.getParameter("idEliminar"));

        boolean eliminado = controlM.eliminarMulta(idMulta);

        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");

        request.getRequestDispatcher("Multas.jsp").forward(request, response);
    }
}
