package sena.adso.appbibliotecaweb.controller;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Usuario;
import sena.adso.appbibliotecaweb.model.dao.UsuarioDao;
import sena.adso.appbibliotecaweb.model.dao.UsuarioDaoI;


public class UsuarioController {

    private final UsuarioDaoI UsuarioDao = new UsuarioDao();

    public List<Usuario> listarUsuarios() {
        return UsuarioDao.listarUsuarios();
    }

    public boolean insertarUsuarios(List<Usuario> usuarios) {
        boolean inserto = UsuarioDao.insertarUsuarios(usuarios)!= null;
        return inserto;
    }
    
    public boolean actualizarUsuario(Usuario autor, Integer idAutorI) {
        boolean actualizo = UsuarioDao.actualizarUsuario(autor, idAutorI)!= null;
        return actualizo;
    }

    public boolean eliminarUsuario(Integer idAutorI) {
        boolean elimino = UsuarioDao.eliminarUsuario(idAutorI)!=null;
        return elimino;
    }
    
    public Usuario login(String email,String password){
        List<Usuario> listaUsuarios = listarUsuarios();
        for(Usuario usu : listaUsuarios){
            if((email).equals(usu.getEmail()) && (password).equals(usu.getPassword())){
                return usu;
            }
        }
        return null;
    }
    public int cantidadrUsuarios(){
        return UsuarioDao.cantidadUsuarios();
    }
 

}
