package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.TipoUsuario;

import java.util.List;

public interface TipoUsuarioDaoI {
    public List<TipoUsuario> listarTiposUsuario();
    public String insertarTiposUsuario(List<TipoUsuario> tiposUsuario);
    public String actualizarTipoUsuario(TipoUsuario tipoUsuario, Integer idTipoUsuarioI);
    public String eliminarTipoUsuario(Integer idTipoUsuarioI);


}
