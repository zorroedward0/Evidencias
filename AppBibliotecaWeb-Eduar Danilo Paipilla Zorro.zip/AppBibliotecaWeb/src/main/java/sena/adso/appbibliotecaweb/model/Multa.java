package sena.adso.appbibliotecaweb.model;

import java.time.LocalDate;

public class Multa {

    private Integer idMulta;
    private Integer idPrestamo;
    private Integer valor;
    private boolean pagada;
    private LocalDate fecha;

    public Multa() {
    }

    public Multa(Integer idMulta, Integer idPrestamo, Integer valor, boolean pagada, LocalDate fecha) {
        this.idMulta = idMulta;
        this.idPrestamo = idPrestamo;
        this.valor = valor;
        this.pagada = pagada;
        this.fecha = fecha;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public boolean getPagada() {
        return pagada;
    }

    public void setPagada(boolean pagada) {
        this.pagada = pagada;
    }

    public Integer getIdPrestamo() {
        return idPrestamo;
    }

    public void setIdPrestamo(Integer idPrestamo) {
        this.idPrestamo = idPrestamo;
    }

    public Integer getIdMulta() {
        return idMulta;
    }

    public void setIdMulta(Integer idMulta) {
        this.idMulta = idMulta;
    }

    public Integer getValor() {
        return valor;
    }

    public void setValor(Integer valor) {
        this.valor = valor;
    }

}
