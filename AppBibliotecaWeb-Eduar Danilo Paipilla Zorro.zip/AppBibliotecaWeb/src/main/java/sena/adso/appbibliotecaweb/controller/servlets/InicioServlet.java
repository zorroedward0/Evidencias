package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import sena.adso.appbibliotecaweb.controller.LibroController;
import sena.adso.appbibliotecaweb.controller.PrestamoController;
import sena.adso.appbibliotecaweb.controller.UsuarioController;

@WebServlet(name = "InicioServlet", urlPatterns = {"/Inicio"})
public class InicioServlet extends HttpServlet {

    UsuarioController controlU = new UsuarioController();
    LibroController controlL = new LibroController();
    PrestamoController controlP = new PrestamoController();

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null || (!"Cliente".equals(rol) && !"Administrador".equals(rol))) {
            response.sendRedirect("login.jsp");
        } else if ("Administrador".equals(rol)) {
            int cantidadLibros = controlL.cantidadLibros();
            request.setAttribute("cantidadLibros", cantidadLibros);
            int cantidadPrestamos = controlP.cantdadPrestamos();
            request.setAttribute("cantidadPrestamos", cantidadPrestamos);
            int cantidadrUsuarios = controlU.cantidadrUsuarios();
            request.setAttribute("cantidadUsuarios", cantidadrUsuarios);

            RequestDispatcher rd = request.getRequestDispatcher("inicio.jsp");
            rd.forward(request, response);
        } else if("Cliente".equals(rol)) {
            response.sendRedirect("inicioCliente.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
