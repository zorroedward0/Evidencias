<%@page import="sena.adso.appbibliotecaweb.model.Multa"%>
<%@page import="java.util.List"%>
<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");
    Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");

    if (rol == null || !"Cliente".equals(rol) || usuario == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/x-icon" href="images/multa.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/ClienteStyles.css" rel="stylesheet"/>

        <title>Mis Multas</title>
    </head>

    <body style="background: linear-gradient(135deg, #7ea3d8, #a9c9f5);">


        <% List<Multa> lista = (List<Multa>) request.getAttribute("listaMultas");%>

        <jsp:include page="navbar.jsp"/>

        <div class="container mt-5">

            <h2 class="mb-4 text-center">Mis Multas</h2>

            <div class="card shadow">
                <div class="card-body">

                    <table id="tblMultas" class="table table-striped table-hover table-bordered dataTable">

                        <% if (lista == null || lista.size() < 1) { %>

                        <thead class="table-info">
                            <tr>
                                <th>Multas</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td>No tienes multas registradas</td>
                            </tr>
                        </tbody>

                        <% } else { %>

                        <thead class="table-info">
                            <tr>
                                <th>ID</th>
                                <th>Pr�stamo</th>
                                <th>Valor</th>
                                <th>Estado</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>

                        <tbody>
                            <c:forEach var="m" items="${listaMultas}">
                                <tr>
                                    <td>${m.idMulta}</td>
                                    <td>${m.idPrestamo}</td>
                                    <td>$ ${m.valor}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${m.pagada}">
                                                <span class="badge bg-success">Pagada</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-danger">Pendiente</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td>${m.fecha}</td>
                                </tr>
                            </c:forEach>
                        </tbody>

                        <% }%>

                    </table>

                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

        <script>

            $(document).ready(function () {

                let table = $('#tblMultas').DataTable({
                    pageLength: 15,
                    lengthChange: false,
                    dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
                });

                let input = $('.dataTables_filter input');
                input.attr("placeholder", "? Buscar en mis Multas...");

                $('.dataTables_filter label').contents().filter(function () {
                    return this.nodeType === 3;
                }).remove();

            });


        </script>


    </body>
</html>