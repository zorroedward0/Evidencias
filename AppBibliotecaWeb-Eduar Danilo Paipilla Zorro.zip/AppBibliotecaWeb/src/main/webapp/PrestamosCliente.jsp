<%@page import="sena.adso.appbibliotecaweb.model.Prestamo"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%
    String rol = (String) session.getAttribute("rol");
    Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");

    if (rol == null || !"Cliente".equals(rol) || usuario == null) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/x-icon" href="images/prestamo.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/ClienteStyles.css" rel="stylesheet"/>
        <title>Mis Prestamos</title>

    </head>

    <body>
        <% List<Prestamo> lista = (List<Prestamo>) request.getAttribute("listaPrestamos");%>
        <jsp:include page="navbar.jsp"/>

        <div class="container mt-4">
            <h1>Mis Prestamos</h1>
            <div class="card shadow">
                <div class="card-body">

                    <table id="tblPrestamos" class="table table-striped table-hover table-bordered dataTable">
                        <%if (lista == null || lista.size() < 1) {%>


                        <thead class="table-info text-center">
                            <tr>
                                <th>Sin Prestamos</th>

                            </tr>
                        </thead>

                        <tbody class="text-center">

                            <tr>
                                <td><%= "No hay prestamo registrados a tu nombre."%></td>

                            </tr>

                        </tbody>
                        <%} else {%>


                        <thead class="table-info text-center">
                            <tr>
                                <th>ID</th>
                                <th>Fecha Devolucion Esperada</th>
                                <th>Estado</th>
                                <th>Libro</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <c:forEach var="p" items="${listaPrestamos}">
                                <c:if test="${p.idUsuario == usuarioLogueado.idUsuario}">
                                    <tr>
                                        <td>${p.idPrestamo}</td>
                                        <td>${p.fechaDevolucionEsperada}</td>
                                        <td>${p.estado==true?"Activo":"Finalizado"}</td>

                                        <td>
                                            <c:forEach var="l" items="${listaLibros}">
                                                <c:if test="${l.idLibro == p.idLibro}">
                                                    ${l.titulo}
                                                </c:if>
                                            </c:forEach>
                                        </td>

                                    </tr>
                                </c:if>
                            </c:forEach>
                        </tbody>
                        <%}%>
                    </table>

                </div>
            </div>

        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

        <script>

            $(document).ready(function () {

                let table = $('#tblPrestamos').DataTable({
                    pageLength: 15,
                    lengthChange: false,
                    dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
                });

                let input = $('.dataTables_filter input');
                input.attr("placeholder", "🔍 Buscar en mis Prestamos...");

                $('.dataTables_filter label').contents().filter(function () {
                    return this.nodeType === 3;
                }).remove();

            });


        </script>

    </body>
</html>