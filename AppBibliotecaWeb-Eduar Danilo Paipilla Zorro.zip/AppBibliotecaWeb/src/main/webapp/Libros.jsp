<%@page import="sena.adso.appbibliotecaweb.model.TipoUsuario"%>
<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>


<head>
    <meta charset="UTF-8">

    <link rel="icon" type="image/x-icon" href="images/libros.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="Css/AdminStyles.css" rel="stylesheet"/>
    <title>Manejo de Libros</title>

    
</head>
<body>

    <jsp:include page="navbar.jsp"/>

    <div class="container">



        <div class="text-end mb-3">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCrear">
                <i class="bi bi-plus-circle"></i> Nuevo libro
            </button>
        </div>

        <div class="card shadow">
            <div class="card-body">

                <table id="tblUsuarios" class="table table-striped table-hover table-bordered dataTable">

                    <thead class="table-info text-center">
                        <tr>
                            <th>Referencia</th>
                            <th>Titulo</th>
                            <th>Imagen</th>
                            <th>Isbn</th>
                            <th>Año de Publicacion</th>
                            <th>Numero de Paginas</th>
                            <th>Estado</th>
                            <th>Es Destacado</th>
                            <th>Editorial</th>
                            <th>Autores</th>
                            <th>Categorias</th>
                            <th>Funciones</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">
                        <c:forEach var="libro" items="${listaLibros}">
                            <tr>
                                <td>${libro.idLibro}</td>
                                <td>${libro.titulo}</td>
                                <td><img src="${libro.imagen}" width="70" height="70" alt="alt" class="imgCustom"/></td>
                                <td>${libro.isbn}</td>
                                <td>${libro.anioPublicacion}</td>
                                <td>${libro.numPag}</td>
                                <td>${libro.estado==true?"Disponible":"No Disponible"}</td>
                                <td>${libro.destacado==true?"Si":"No"}</td>
                                <td>${libro.editorial.nombre}</td>
                                <td>
                                    <c:forEach var="autor" items="${libro.autores}" varStatus="status">

                                        <div>${autor.nombre} ${autor.apellido}</div><br>

                                    </c:forEach>
                                </td>
                                <td>
                                    <c:forEach var="categoria" items="${libro.categorias}" varStatus="status">

                                        <div>${categoria.nombre}</div><br>

                                    </c:forEach>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-warning me-1"
                                            data-id="${libro.idLibro}"
                                            data-titulo="${libro.titulo}"
                                            data-isbn="${libro.isbn}"
                                            data-aniopublicacion="${libro.anioPublicacion}"
                                            data-numpag="${libro.numPag}"
                                            data-estado="${libro.estado}"
                                            data-destacado="${libro.destacado}"
                                            data-imagen="${libro.imagen}"
                                            data-editorialid="${libro.editorial.idEditorial}"
                                            data-autores="<c:forEach var='a' items='${libro.autores}' varStatus='st'>${a.idAutor}<c:if test='${!st.last}'>,</c:if></c:forEach>"
                                            data-categorias="<c:forEach var='c' items='${libro.categorias}' varStatus='st'>${c.idCategoria}<c:if test='${!st.last}'>,</c:if></c:forEach>"

                                                    onclick="abrirModalEditar(this)">
                                                    <i class="bi bi-pencil"></i>
                                                </button>

                                                <button type="button" class="btn btn-danger"
                                                        data-id="${libro.idLibro}"
                                            data-imageneliminar="${libro.imagen}"
                                            data-nombre="${libro.titulo}"
                                            onclick="abrirModalEliminar(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>

                </table>

            </div>
        </div>


    </div>



    <div class="modal fade" id="modalEditar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">


                <div class="modal-header">
                    <h5 class="modal-title">Editar Libro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="LibroServlet" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">

                        <input type="hidden" name="accion" value="editar">

                        <h6>ID</h6>
                        <input type="text" id="idLibro" name="idLibro" class="form-control mb-2" readonly>

                        <h6>Titulo</h6>
                        <input type="text" id="titulo" name="titulo" class="form-control mb-2">

                        <div class="upload-container">
                            <h6>Imagen actual</h6>
                            <input type="hidden" name="imagenUrl" id="imagenUrl" value="src.jpg">
                            <img id="imagen" src="img.png" width="100" height="100" alt="imagen no encontrada"/>

                            <h6>Cambiar Imagen</h6>
                            <label for="file-upload" class="custom-file-upload">
                                Seleccionar archivo
                            </label>
                            <input id="file-upload" type="file" name="imagen"/>
                        </div>


                        <h6>Isbn</h6>
                        <input type="text" id="isbn" name="isbn" class="form-control mb-2">

                        <h6>Año de Publicacion</h6>
                        <input type="text" id="anioPublicacion" name="anioPublicacion" class="form-control mb-2">

                        <h6>Numero de paginas</h6>
                        <input type="text" id="numPag" name="numPag" class="form-control mb-2">

                        <h6>Estado</h6>
                        <select name="estado" id="estado" class="form-select mb-2">
                            <option value="true">Disponible</option>
                            <option value="false">No Disponible</option>
                        </select>

                        <h6>Es Destacado</h6>
                        <select name="destacado" id="destacado" class="form-select mb-2">
                            <option value="true">Si</option>
                            <option value="false">No</option>
                        </select>

                        <h6>Editorial</h6>
                        <select name="editorial" id="editorial" class="form-select mb-2">
                            <c:forEach var="e" items="${listaEditoriales}">
                                <option value="${e.idEditorial}">${e.nombre}</option>
                            </c:forEach>
                        </select>

                        <h6>Autores</h6>
                        <select id="autores" name="autores" multiple class="form-select mb-2">
                            <c:forEach var="a" items="${listaAutores}">
                                <option value="${a.idAutor}">
                                    ${a.nombre}
                                </option>
                            </c:forEach>
                        </select>

                        <h6>Categorias</h6>
                        <select id="categorias" name="categorias" multiple class="form-select mb-2">
                            <c:forEach var="c" items="${listaCategorias}">
                                <option value="${c.idCategoria}">
                                    ${c.nombre}
                                </option>
                            </c:forEach>
                        </select>


                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>

            </div>
        </div>


    </div>



    <div class="modal fade" id="modalEliminar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">


                <div class="modal-header">
                    <h5 class="modal-title">Eliminar Libro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="LibroServlet" method="POST" enctype="multipart/form-data">
                    <div class="modal-body text-center">
                        <input type="hidden" name="accion" value="eliminar">

                        <input type="hidden" id="idEliminar" name="idEliminar">

                        <h5>¿Desea eliminar este libro?</h5>

                        <input type="text" id="nombreEliminar" class="form-control text-center mb-2" readonly style="border:none;">

                        <div style=" display: flex; justify-content: center; ">
                            <img id="imagenE" name="imagenE" src="img.png" class="imgCustom" width="150" height="150" alt="no se encontro imagen"/>
                        </div>
                        <small class="text-muted">Esta acción es irreversible</small>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </div>
                </form>

            </div>
        </div>


    </div>



    <div class="modal fade" id="modalCrear" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">


                <div class="modal-header">
                    <h5 class="modal-title">Crear Libro</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="LibroServlet" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">

                        <input type="hidden" name="accion" value="crear">

                        <h6>Titulo</h6>
                        <input type="text" name="titulo" class="form-control mb-2">


                        <div class="upload-container">
                            <h6>Imagen</h6>
                            <label for="file-upload-create" class="custom-file-upload">
                                Seleccionar archivo
                            </label>
                            <input id="file-upload-create" type="file" name="imagencrear"/>
                        </div>


                        <h6>Isbn</h6>
                        <input type="text" name="isbn" class="form-control mb-2">

                        <h6>Año de Publicacion</h6>
                        <input type="text" name="anioPublicacion" class="form-control mb-2">

                        <h6>Numero de paginas</h6>
                        <input type="text" name="numPag" class="form-control mb-2">

                        <h6>Estado</h6>
                        <select name="estado" class="form-select mb-2">
                            <option value="true">Disponible</option>
                            <option value="false">No Disponible</option>
                        </select>

                        <h6>Es Destacado</h6>
                        <select name="destacado" class="form-select mb-2">
                            <option value="true">Si</option>
                            <option value="false">No</option>
                        </select>

                        <h6>Editorial</h6>
                        <select name="editorial" class="form-select mb-2">
                            <c:forEach var="e" items="${listaEditoriales}">
                                <option value="${e.idEditorial}">${e.nombre}</option>
                            </c:forEach>
                        </select>

                        <h6>Autores</h6>
                        <select name="autores" multiple class="form-select mb-2">
                            <c:forEach var="a" items="${listaAutores}">
                                <option value="${a.idAutor}">
                                    ${a.nombre}
                                </option>
                            </c:forEach>
                        </select>

                        <h6>Categorias</h6>
                        <select name="categorias" multiple class="form-select mb-2">
                            <c:forEach var="c" items="${listaCategorias}">
                                <option value="${c.idCategoria}">
                                    ${c.nombre}
                                </option>
                            </c:forEach>
                        </select>


                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Crear</button>
                    </div>
                </form>

            </div>
        </div>


    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <% String accionSwal = (String) request.getAttribute("accion");%>
    <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>
    <% if (hecho != null) { %>

    <script>
        <% if (hecho) {%>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Libro <%=accionSwal%>',
                                                    text: 'El libro se ha <%=accionSwal%> correctamente',
                                                    confirmButtonText: 'Aceptar'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = '/AppBibliotecaWeb/LibroServlet';
                                                    }
                                                });
        <% } else {%>
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Error',
                                                    text: 'No se ha <%=accionSwal%> el libro',
                                                    confirmButtonText: 'Aceptar'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = '/AppBibliotecaWeb/LibroServlet';
                                                    }
                                                });
        <% } %>
    </script>
    <% }%>

    <script>
        function abrirModalEditar(btn) {
            const modal = document.getElementById("modalEditar");

            modal.querySelector("#idLibro").value = btn.dataset.id;
            modal.querySelector("#titulo").value = btn.dataset.titulo;
            modal.querySelector("#isbn").value = btn.dataset.isbn;
            modal.querySelector("#anioPublicacion").value = btn.dataset.aniopublicacion;
            modal.querySelector("#numPag").value = btn.dataset.numpag;
            modal.querySelector("#estado").value = btn.dataset.estado;
            modal.querySelector("#destacado").value = btn.dataset.destacado;
            modal.querySelector("#imagen").src = btn.dataset.imagen;
            modal.querySelector("#imagenUrl").value = btn.dataset.imagen;
            modal.querySelector("#editorial").value = btn.dataset.editorialid;



            let autores = btn.dataset.autores
                    ? btn.dataset.autores.split(",").map(a => a.trim())
                    : [];

            let categorias = btn.dataset.categorias
                    ? btn.dataset.categorias.split(",").map(c => c.trim())
                    : [];

            $('#autores').val(autores).trigger('change');
            $('#categorias').val(categorias).trigger('change');

            new bootstrap.Modal(modal).show();
        }

        function abrirModalEliminar(btn) {
            const modal = document.getElementById("modalEliminar");

            modal.querySelector("#idEliminar").value = btn.dataset.id;
            modal.querySelector("#nombreEliminar").value = btn.dataset.nombre;
            modal.querySelector("#imagenE").src = btn.dataset.imageneliminar;

            new bootstrap.Modal(modal).show();
        }


        $(document).ready(function () {
            $('#autores').select2({
                placeholder: "Selecciona autores",
                width: '100%',
                dropdownParent: $('#modalEditar'),
                closeOnSelect: false
            });

            $('#categorias').select2({
                placeholder: "Selecciona categorías",
                width: '100%',
                dropdownParent: $('#modalEditar'),
                closeOnSelect: false
            });

            $('#modalCrear select[name="autores"]').select2({
                placeholder: "Selecciona autores",
                width: '100%',
                dropdownParent: $('#modalCrear'),
                closeOnSelect: false
            });

            $('#modalCrear select[name="categorias"]').select2({
                placeholder: "Selecciona categorías",
                width: '100%',
                dropdownParent: $('#modalCrear'),
                closeOnSelect: false
            });

            $('#autores').on('select2:unselect', function () {
                $(this).select2('open');
            });

            $('#categorias').on('select2:unselect', function () {
                $(this).select2('open');
            });
        });

        $(document).ready(function () {

            let table = $('#tblUsuarios').DataTable({
                pageLength: 15,
                lengthChange: false,
                dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
            });

            let input = $('.dataTables_filter input');
            input.attr("placeholder", "🔍 Buscar libro...");

            $('.dataTables_filter label').contents().filter(function () {
                return this.nodeType === 3;
            }).remove();

        });



    </script>
</body>


