<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>
<% Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");%>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>
<html lang="es">
    <head>
        <link rel="icon" type="image/x-icon" href="images/prestamo.ico">
        <meta charset="UTF-8">
        <title>Crear Préstamo</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="Css/prestamoIndividual.css" rel="stylesheet">

    </head>
    <body>

        <div class="prestamo-card">

            <h3>Crear Préstamo</h3>

            <div class="libro-info">
                <c:forEach var="l" items="${listaLibros}">
                    <c:if test="${l.idLibro == idLibroSeleccionado}">
                        <img src="${l.imagen}" alt="${l.titulo}">
                        <h5>${l.titulo}</h5>
                    </c:if>
                </c:forEach>
            </div>

            <div class="usuario-info">
                Usuario: ${usuarioLogueado.nombre} ${usuarioLogueado.apellido}
            </div>

            <form action="PrestamoServlet" method="POST">

                <input type="hidden" name="accion" value="crearI">

                <input type="hidden" name="idLibro" value="${idLibroSeleccionado}">

                <input type="hidden" name="idUsuario" value="${usuarioLogueado.idUsuario}">

                <label class="form-label">Fecha Préstamo</label>
                <input type="date" name="fechaPrestamo" class="form-control mb-3" required>

                <label class="form-label">Fecha Devolución Esperada</label>
                <input type="date" name="fechaEsperada" class="form-control mb-3" required>

                <button type="submit" class="btn btn-prestamo">
                    Crear Préstamo
                </button>

                <a href="LibroServlet" 
                   class="btn btn-volver w-100">
                    Volver
                </a>



            </form>

        </div>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <% String accionSwal = (String) request.getAttribute("accion"); %>
        <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>

        <% if (hecho != null) { %>
        <script>
            <% if (hecho) {%>
            Swal.fire({
                icon: 'success',
                title: 'Prestamo <%=accionSwal%>',
                text: 'El prestamo se ha <%=accionSwal%> correctamente',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                window.location.href = '/AppBibliotecaWeb/LibroServlet';
            });
            <% } else {%>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se ha <%=accionSwal%> el prestamo',
                confirmButtonText: 'Aceptar'
            });
            <% } %>
        </script>
        <% }%>

        <% String accionSwala = (String) request.getAttribute("accion"); %>
        <% String tiempo = (String) (request.getAttribute("tiempo"));%>

        <% if (accionSwala != null && accionSwala.equalsIgnoreCase("errorTiempo")) {%>
        <script>

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se ha podido crear el prestamo el prestamo tiene una duracion de <%=tiempo%> dias,Duracion maxima permitida de 10 dias',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                window.location.href = '/AppBibliotecaWeb/LibroServlet';
            });
        </script>
        <% }%>

        <% String accionSwa = (String) request.getAttribute("accion"); %>

        <% if (accionSwa != null && accionSwa.equalsIgnoreCase("errorDia")) { %>
        <script>

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se ha podido crear el prestamo, el dia de creacion de prestamo no corresponde a hoy',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                window.location.href = '/AppBibliotecaWeb/LibroServlet';
            });
        </script>
        <% }%>

        <% String accionSw = (String) request.getAttribute("accion"); %>

        <% if (accionSw != null && accionSw.equalsIgnoreCase("errorTiempoMenor")) {%>
        <script>

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se ha podido crear el prestamo, el prestamo no puede tener fechas pasadas.',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                window.location.href = '/AppBibliotecaWeb/LibroServlet';
            });
        </script>
        <% }%>

        <% String accionSwe = (String) request.getAttribute("accion"); %>

        <% if (accionSwe != null && accionSwe.equalsIgnoreCase("errorMultasExisten")) {%>
        <script>

            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'No se ha podido crear el prestamo,tienes multas pendientes.',
                confirmButtonText: 'Aceptar'
            }).then(() => {
                window.location.href = '/AppBibliotecaWeb/LibroServlet';
            });
        </script>
        <% }%>
    </body>
</html>