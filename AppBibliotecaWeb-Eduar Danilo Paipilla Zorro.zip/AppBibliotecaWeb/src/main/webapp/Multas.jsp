<%@page import="sena.adso.appbibliotecaweb.model.Multa"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/x-icon" href="images/multa.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/AdminStyles.css" rel="stylesheet"/>

        <title>Manejo de Multas</title>
    </head>

    <body style="background: linear-gradient(135deg, #7ea3d8, #a9c9f5);">

        <% List<Multa> lista = (List<Multa>) request.getAttribute("listaMultas");%>

        <jsp:include page="navbar.jsp"/>

        <div class="container">

            <div class="card shadow">
                <div class="card-body">

                    <table id="tblMultas" class="table table-striped table-hover table-bordered dataTable">

                        <% if (lista == null || lista.size() < 1) { %>

                        <thead class="table-info text-center">
                            <tr><th>Multas</th></tr>
                        </thead>

                        <tbody class="text-center">
                            <tr>
                                <td>No hay multas registradas.</td>
                            </tr>
                        </tbody>

                        <% } else { %>

                        <thead class="table-info text-center">
                            <tr>
                                <th>ID</th>
                                <th>Prestamo</th>
                                <th>Valor</th>
                                <th>Pagada</th>
                                <th>Fecha</th>
                                <th>Funciones</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <c:forEach var="m" items="${listaMultas}">
                                <tr>
                                    <td>${m.idMulta}</td>
                                    <td>${m.idPrestamo}</td>
                                    <td>$ ${m.valor}</td>
                                    <td>${m.pagada ? "Sí" : "No"}</td>
                                    <td>${m.fecha}</td>

                                    <td>
                                        <c:choose>
                                            <c:when test="${not m.pagada}">
                                                <button type="button" class="btn btn-warning me-1"
                                                        data-id="${m.idMulta}"
                                                        data-prestamo="${m.idPrestamo}"
                                                        data-valor="${m.valor}"
                                                        data-pagada="${m.pagada}"
                                                        data-fecha="${m.fecha}"
                                                        onclick="abrirModalEditar(this)">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                            </c:when>
                                            <c:otherwise>
                                                <button type="button" class="btn btn-secondary me-1"> 
                                                    <i class="bi bi-lock-fill"></i> 
                                                </button>
                                            </c:otherwise>
                                        </c:choose>

                                        <button type="button" class="btn btn-danger"
                                                data-id="${m.idMulta}"
                                                onclick="abrirModalEliminar(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>

                        <% }%>

                    </table>

                </div>
            </div>
        </div>

        <div class="card shadow mt-4 card-chart">
            <div class="card-body">
                <h5 class="text-center">Valores de Multas</h5>
                <div id="chartBar"></div>
            </div>
        </div>

        <div class="modal fade" id="modalEditar">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Editar Multa</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <form action="MultaServlet" method="POST">
                        <div class="modal-body">

                            <input type="hidden" name="accion" value="editar">

                            <h6>ID</h6>
                            <input type="text" id="idMulta" name="idMulta" class="form-control mb-2" readonly>

                            <h6>ID Prestamo</h6>
                            <input type="number" id="idPrestamo" name="idPrestamo" class="form-control mb-2">

                            <h6>Valor</h6>
                            <input type="number" id="valor" name="valor" class="form-control mb-2">

                            <h6>Estado</h6>
                            <select id="pagada" name="pagada" class="form-select mb-2">
                                <option value="true">Pagada</option>
                                <option value="false">Pendiente</option>
                            </select>

                            <h6>Fecha</h6>
                            <input type="date" id="fecha" name="fecha" class="form-control mb-2">

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-primary">Guardar Cambios</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEliminar">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Eliminar Multa</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <form action="MultaServlet" method="POST">
                        <div class="modal-body text-center">

                            <input type="hidden" name="accion" value="eliminar">
                            <input type="hidden" id="idEliminar" name="idEliminar">

                            <h5>¿Desea eliminar esta multa?</h5>
                            <small class="text-muted">Esta acción es irreversible</small>

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-danger">Eliminar</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <% String accionSwal = (String) request.getAttribute("accion"); %>
        <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>

        <% if (hecho != null) { %>
        <script>
            <% if (hecho) {%>
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Multa <%=accionSwal%>',
                                                        text: 'La multa se ha <%=accionSwal%> correctamente',
                                                        confirmButtonText: 'Aceptar'
                                                    }).then(() => {
                                                        window.location.href = '/AppBibliotecaWeb/MultaServlet';
                                                    });
            <% } else {%>
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: 'Error',
                                                        text: 'No se  <%=accionSwal%> la multa',
                                                        confirmButtonText: 'Aceptar'
                                                    }).then(() => {
                                                        window.location.href = '/AppBibliotecaWeb/MultaServlet';
                                                    });
            <% } %>
        </script>
        <% }%>
        <script>
            function abrirModalEditar(btn) {
                const modal = document.getElementById("modalEditar");

                modal.querySelector("#idMulta").value = btn.dataset.id;
                modal.querySelector("#idPrestamo").value = btn.dataset.prestamo;
                modal.querySelector("#valor").value = btn.dataset.valor;
                modal.querySelector("#pagada").value = btn.dataset.pagada;
                modal.querySelector("#fecha").value = btn.dataset.fecha;

                new bootstrap.Modal(modal).show();
            }

            function abrirModalEliminar(btn) {
                const modal = document.getElementById("modalEliminar");
                modal.querySelector("#idEliminar").value = btn.dataset.id;

                new bootstrap.Modal(modal).show();
            }

            $(document).ready(function () {

                let table = $('#tblMultas').DataTable({
                    pageLength: 15,
                    lengthChange: false,
                    dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
                });

                let input = $('.dataTables_filter input');
                input.attr("placeholder", "🔍 Buscar Multa...");

                $('.dataTables_filter label').contents().filter(function () {
                    return this.nodeType === 3;
                }).remove();

            });

        </script>
        <%
            StringBuilder categorias = new StringBuilder();
            StringBuilder valoresBarra = new StringBuilder();

            if (lista != null) {
                for (Multa m : lista) {
                    categorias.append("\"Multa ").append(m.getIdMulta()).append("\",");
                    valoresBarra.append(m.getValor()).append(",");
                }

                if (categorias.length() > 0) {
                    categorias.setLength(categorias.length() - 1);
                }
                if (valoresBarra.length() > 0) {
                    valoresBarra.setLength(valoresBarra.length() - 1);
                }
            }
        %>
        <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

        <script>
            var options = {
                series: [{
                        name: 'Valor',
                        data: [<%= valoresBarra.toString()%>]
                    }],
                chart: {
                    type: 'bar',
                    height: 350
                },
                plotOptions: {
                    bar: {
                        borderRadius: 5,
                        horizontal: false
                    }
                },
                dataLabels: {
                    enabled: false
                },
                xaxis: {
                    categories: [<%= categorias.toString()%>]
                }
            };

            new ApexCharts(document.querySelector("#chartBar"), options).render();
        </script>
    </body>
</html>