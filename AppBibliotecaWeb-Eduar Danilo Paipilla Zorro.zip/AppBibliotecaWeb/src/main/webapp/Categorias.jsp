<%@page import="sena.adso.appbibliotecaweb.model.Categoria"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/x-icon" href="images/categoria.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/AdminStyles.css" rel="stylesheet"/>

        <title>Categorías</title>
    </head>

    <body>

        <% List<Categoria> lista = (List<Categoria>) request.getAttribute("listaCategorias");%>

        <jsp:include page="navbar.jsp"/>

        <div class="container">

            <div class="text-end mb-3">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCrear">
                    <i class="bi bi-plus-circle"></i> Nueva Categoría
                </button>
            </div>

            <div class="card shadow">
                <div class="card-body">

                    <table id="tblCategorias" class="table table-striped table-hover table-bordered dataTable">

                        <% if (lista == null || lista.size() < 1) { %>

                        <thead class="table-info text-center">
                            <tr><th>Categorías</th></tr>
                        </thead>

                        <tbody class="text-center">
                            <tr>
                                <td>No hay categorías registradas.</td>
                            </tr>
                        </tbody>

                        <% } else { %>

                        <thead class="table-info text-center">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Descripción</th>
                                <th>Funciones</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <c:forEach var="c" items="${listaCategorias}">
                                <tr>
                                    <td>${c.idCategoria}</td>
                                    <td>${c.nombre}</td>
                                    <td>${c.descripcion}</td>

                                    <td>
                                        <button class="btn btn-warning"
                                                data-id="${c.idCategoria}"
                                                data-nombre="${c.nombre}"
                                                data-descripcion="${c.descripcion}"
                                                onclick="abrirModalEditar(this)">
                                            <i class="bi bi-pencil"></i>
                                        </button>

                                        <button class="btn btn-danger"
                                                data-id="${c.idCategoria}"
                                                onclick="abrirModalEliminar(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>

                        <% }%>
                    </table>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEditar">
            <div class="modal-dialog">
                <div class="modal-content">

                    <form action="CategoriaServlet" method="POST">
                        <input type="hidden" name="accion" value="editar">

                        <div class="modal-header">
                            <h5>Editar Categoría</h5>
                        </div>

                        <div class="modal-body">

                            <input type="text" id="idCategoria" name="idCategoria" class="form-control mb-2" readonly>

                            <input type="text" id="nombre" name="nombre" class="form-control mb-2" placeholder="Nombre">

                            <textarea id="descripcion" name="descripcion" class="form-control mb-2" placeholder="Descripción"></textarea>

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-primary">Guardar</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEliminar">
            <div class="modal-dialog">
                <div class="modal-content">

                    <form action="CategoriaServlet" method="POST">
                        <input type="hidden" name="accion" value="eliminar">
                        <input type="hidden" id="idEliminar" name="idEliminar">

                        <div class="modal-body text-center">
                            <h5>¿Eliminar categoría?</h5>
                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-danger">Eliminar</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalCrear">
            <div class="modal-dialog">
                <div class="modal-content">

                    <form action="CategoriaServlet" method="POST">
                        <input type="hidden" name="accion" value="crear">

                        <div class="modal-header">
                            <h5>Crear Categoría</h5>
                        </div>

                        <div class="modal-body">

                            <input type="text" name="nombre" class="form-control mb-2" placeholder="Nombre">
                            <textarea name="descripcion" class="form-control mb-2" placeholder="Descripción"></textarea>

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-success">Crear</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <% String accionSwal = (String) request.getAttribute("accion"); %>
        <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>

        <% if (hecho != null) { %>
        <script>
            <% if (hecho) {%>
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Categoria <%=accionSwal%>',
                                                        text: 'La categoria ha sido <%=accionSwal%> correctamente',
                                                        confirmButtonText: 'Aceptar'
                                                    }).then(() => {
                                                        window.location.href = '/AppBibliotecaWeb/CategoriaServlet';
                                                    });
            <% } else {%>
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: 'Error',
                                                        text: 'No se  <%=accionSwal%> la categoria',
                                                        confirmButtonText: 'Aceptar'
                                                    }).then(() => {
                                                        window.location.href = '/AppBibliotecaWeb/CategoriaServlet';
                                                    });
            <% } %>
        </script>
        <% }%>
        <script>
            function abrirModalEditar(btn) {
                const modal = document.getElementById("modalEditar");

                modal.querySelector("#idCategoria").value = btn.dataset.id;
                modal.querySelector("#nombre").value = btn.dataset.nombre;
                modal.querySelector("#descripcion").value = btn.dataset.descripcion;

                new bootstrap.Modal(modal).show();
            }

            function abrirModalEliminar(btn) {
                const modal = document.getElementById("modalEliminar");
                modal.querySelector("#idEliminar").value = btn.dataset.id;

                new bootstrap.Modal(modal).show();
            }

            $(document).ready(function () {

                let table = $('#tblCategorias').DataTable({
                    pageLength: 15,
                    lengthChange: false,
                    dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
                });

                let input = $('.dataTables_filter input');
                input.attr("placeholder", "🔍 Buscar Categoria...");

                $('.dataTables_filter label').contents().filter(function () {
                    return this.nodeType === 3;
                }).remove();

            });


        </script>

    </body>
</html>