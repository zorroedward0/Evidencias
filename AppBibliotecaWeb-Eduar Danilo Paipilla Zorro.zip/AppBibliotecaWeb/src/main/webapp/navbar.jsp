<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");
    if (rol == null) {
        rol = "";
    }
    if (rol != null) {
        response.sendRedirect("login.jsp");
    }
%>

<head>
    <link href="Css/navbar.css" rel="stylesheet"/>
</head>

<nav class="navbar-custom">


    <div class="nav-left">

        <div class="nav-links">
            <%
                if ("Administrador".equals(rol)) {
            %>
            <a href="Inicio">Inicio</a>
            <a href="LibroServlet">Libros</a>
            <a href="PrestamoServlet">Préstamos</a>
            <a href="UsuarioServlet">Usuarios</a>
            <a href="MultaServlet">Multas</a>
            <a href="CategoriaServlet">Generos</a>
            <a href="EditorialServlet">Editoriales</a>
            <a href="AutorServlet">Autores</a>

            <%
            } else if ("Cliente".equals(rol)) {
            %>
            <a href="Inicio">Inicio</a>
            <a href="LibroServlet">Libros</a>
            <a href="PrestamoServlet">Mis Préstamos</a>
            <a href="MultaServlet">Mis Multas</a>
            <%
                }
            %>
        </div>

    </div>

    <form action="logout.jsp" method="post">
        <button type="submit" class="logout">Salir</button>
    </form>


</nav>
