<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }

    if (request.getAttribute("cantidadLibros") == null) {
        response.sendRedirect("/AppBibliotecaWeb/Inicio");
        return;
    }

%>

<!DOCTYPE html>
<html>
    <head>
        <title>Inicio</title>

        <link href="Css/inicio.css" rel="stylesheet"/>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="images/dash.ico">

    </head>

    <body>

        <jsp:include page="navbar.jsp"/>

        <div class="container">

            <h1 class="title">Dashboard</h1>
            <p class="subtitle">Bienvenid@ ${usuarioLogueado.nombre} 👋</p>

            <div class="dashboard-container">
                <div class="dashboard-card">
                    <h4>Libros</h4>
                    <h3>${cantidadLibros}</h3>
                </div>

                <div class="dashboard-card">
                    <h4>Préstamos</h4>
                    <h3>${cantidadPrestamos}</h3>
                </div>

                <div class="dashboard-card">
                    <h4>Usuarios</h4>
                    <h3>${cantidadUsuarios}</h3>
                </div>
            </div>

            <div class="cards">

                <div class="card">
                    <h3>📚 Libros</h3>
                    <p>Gestiona el catálogo completo</p>
                    <a href="LibroServlet">Entrar</a>
                </div>

                <div class="card">
                    <h3>🔄 Préstamos</h3>
                    <p>Control de préstamos</p>
                    <a href="PrestamoServlet">Entrar</a>
                </div>

                <div class="card">
                    <h3>👤 Usuarios</h3>
                    <p>Administración de usuarios</p>
                    <a href="UsuarioServlet">Entrar</a>
                </div>

                <div class="card">
                    <h3>💰 Multas</h3>
                    <p>Control de multas</p>
                    <a href="MultaServlet">Entrar</a>
                </div>

                <div class="card">
                    <h3>🏷️ Categorías</h3>
                    <p>Organiza los géneros</p>
                    <a href="CategoriaServlet">Entrar</a>
                </div>

                <div class="card">
                    <h3>🏢 Editoriales</h3>
                    <p>Gestión de editoriales</p>
                    <a href="EditorialServlet">Entrar</a>
                </div>

                <div class="card">
                    <h3>✍️ Autores</h3>
                    <p>Administra autores</p>
                    <a href="AutorServlet">Entrar</a>
                </div>

            </div>

        </div>
        <script src="https://cdn.botpress.cloud/webchat/v3.6/inject.js"></script>
        <script src="https://files.bpcontent.cloud/2026/03/27/12/20260327122358-J1TV4VO2.js" defer></script>
    </body>
</html>