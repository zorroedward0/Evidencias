<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html lang="es">
    <head>
        <title>Panel del Cliente</title>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="images/dash.ico">
        <link href="Css/inicioCliente.css" rel="stylesheet">

    </head>
    <body>

        <jsp:include page="navbar.jsp"/>

        <div class="container">
            <h1 class="title">Dashboard</h1>
            <p class="subtitle">Bienvenid@ ${usuarioLogueado.nombre} 👋</p>


            <div class="cards">
                <div class="card">
                    <h3>Ver Libros Disponibles</h3>
                    <p>Explora el catálogo y encuentra tu próximo libro.</p>
                    <a href="LibroServlet">Ver Libros</a>
                </div>

                <div class="card">
                    <h3>Mis Multas</h3>
                    <p>Consulta tus multas actuales.</p>
                    <a href="MultaServlet">Ver Multas</a>
                </div>

                <div class="card">
                    <h3>Historial de Préstamos</h3>
                    <p>Revisa todos los préstamos que has realizado anteriormente.</p>
                    <a href="PrestamoServlet">Ver Historial</a>
                </div>
            </div>
        </div>

        <script src="https://cdn.botpress.cloud/webchat/v3.6/inject.js"></script>
        <script src="https://files.bpcontent.cloud/2026/03/27/12/20260327122358-J1TV4VO2.js" defer></script>

    </body>
</html>