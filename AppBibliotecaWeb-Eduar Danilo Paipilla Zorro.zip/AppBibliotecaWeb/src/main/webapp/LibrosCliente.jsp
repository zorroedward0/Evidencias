<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="sena.adso.appbibliotecaweb.model.TipoUsuario"%>
<%@ page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@ page import="java.util.List"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");
    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<jsp:include page="navbar.jsp"/>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Libros</title>
        <link rel="icon" type="image/x-icon" href="images/libros.ico">
        <link rel="icon" type="image/x-icon" href="images/libros.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/ClienteStyles.css" rel="stylesheet"/>

    </head>
    <body>

        <div class="container">
            <h1 class="titulo-libros"> Visualizador de Libros</h1>
            <h5 class="subtitulo-libros h4-libros" style="text-align: center">Explora nuestro catálogo y disfruta de tus libros favoritos desde aquí.</h5>

            <div class="row justify-content-center">
                <c:forEach var="libro" items="${listaLibros}">
                    <div class="col-md-4 d-flex justify-content-center mb-4">
                        <div class="card-flip">
                            <div class="card-inner">
                                <div class="card-front">

                                    <img style="  width: 349px; height: 460px;" src="${libro.imagen}" alt="${libro.titulo}">

                                    <h5>${libro.titulo}</h5>
                                </div>
                                <div class="card-back">
                                    <form action="PrestamoServlet" method="POST">
                                        <input type="hidden" name="accion" value="irCrear">
                                        <input type="hidden" name="idLibro" value="${libro.idLibro}">
                                        <p><strong>ISBN:</strong> ${libro.isbn}</p>
                                        <p><strong>Año:</strong> ${libro.anioPublicacion}</p>
                                        <p><strong>Páginas:</strong> ${libro.numPag}</p>
                                        <p><strong>Estado:</strong> ${libro.estado == true ? "Disponible" : "No Disponible"}</p>
                                        <p><strong>Editorial:</strong> ${libro.editorial.nombre}</p>

                                        <p><strong>Autores:</strong></p>
                                        <ul>
                                            <c:forEach var="autor" items="${libro.autores}">
                                                <li>${autor.nombre} ${autor.apellido}</li>
                                                </c:forEach>
                                        </ul>

                                        <p><strong>Categorías:</strong></p>
                                        <ul>
                                            <c:forEach var="categoria" items="${libro.categorias}">
                                                <li>${categoria.nombre}</li>
                                                </c:forEach>
                                        </ul>


                                        <c:set var="prestamoActivo" value="false" />

                                        <c:forEach var="prestamo" items="${listaPrestamos}">
                                            <c:if test="${prestamo.idLibro == libro.idLibro && prestamo.estado}">
                                                <c:set var="prestamoActivo" value="true" />
                                            </c:if>
                                        </c:forEach>

                                        <c:choose>
                                            <c:when test="${prestamoActivo}">
                                                <button type="button" class="btn btn-secondary" disabled>
                                                    Prestado Actualmente
                                                </button>
                                            </c:when>

                                            <c:when test="${!libro.estado}">
                                                <button type="button" class="btn btn-secondary" disabled>
                                                    No disponible
                                                </button>
                                            </c:when>

                                            <c:otherwise>
                                                <button type="submit" class="btn btn-primary" >
                                                    Préstamo
                                                </button>
                                            </c:otherwise>
                                        </c:choose>


                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </c:forEach>
            </div>
        </div>

        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
        <script>
            $(document).ready(function () {
                $('#tblLibros').DataTable({
                    pageLength: 15,
                    lengthChange: false
                });
            });
        </script>

    </body>
</html>