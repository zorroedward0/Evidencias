<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link rel="icon" type="image/x-icon" href="images/login.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
        <script type="module" src="https://unpkg.com/@splinetool/viewer@1.12.73/build/spline-viewer.js"></script>
        <link href="Css/login.css" rel="stylesheet"/>

    </head>

    <body>

    <spline-viewer 
        class="bg-spline"
        url="https://prod.spline.design/ucE4jchLbxZRPCl4/scene.splinecode"
        loading-anim-type="none"
        interaction="auto">
    </spline-viewer>

    <div class="login-wrapper">

        <div class="left-content">
            <h1>Bienvenidos</h1>
            <p class="desc">
                Explora un mundo de conocimiento, accede a recursos digitales y forma parte de nuestra comunidad.
            </p>

            <div class="features">
                <div><i class="bi bi-book"></i> Préstamo de libros</div>
                <div><i class="bi bi-people"></i> Comunidad activa</div>
                <div><i class="bi bi-laptop"></i> Recursos digitales</div>
            </div>
        </div>

        <div class="login-box">

            <span class="badge-custom">Biblioteca Digital</span>

            <h2 class="text-center">Iniciar Sesión</h2>
            <p class="subtext">Accede a tu espacio</p>

            <form action="LoginServlet" method="POST">

                <div class="input-group mb-3">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" class="form-control" placeholder="Correo electrónico">
                </div>

                <div class="input-group mb-2">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" class="form-control" placeholder="Contraseña">
                </div>

                <div class="text-end mb-3">
                    <a href="#" id="forgotPassword" class="forgot">¿Olvidaste tu contraseña?</a>
                </div>

                <button type="submit" class="btn btn-login w-100">Ingresar</button>

            </form>

        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <%
        String resultado = (String) request.getAttribute("error");
        if (resultado != null && !resultado.isEmpty()) {
    %>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: '<%=resultado%>'
        });
    </script>
    <%
        }
    %>
    <script>
        document.getElementById("forgotPassword").addEventListener("click", function (e) {
            e.preventDefault();

            Swal.fire({
                icon: 'warning',
                title: 'Recuperación de contraseña',
                text: 'Contacta a soporte para recuperar tu cuenta.'
            });
        });
    </script>

</body>
</html>