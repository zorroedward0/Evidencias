<%@page import="sena.adso.appbibliotecaweb.model.Editorial"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/x-icon" href="images/editorial.ico">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
        <link href="Css/AdminStyles.css" rel="stylesheet"/>

        <title>Editoriales</title>
    </head>

    <body>

        <% List<Editorial> lista = (List<Editorial>) request.getAttribute("listaEditoriales");%>

        <jsp:include page="navbar.jsp"/>

        <div class="container">

            <div class="text-end mb-3">
                <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCrear">
                    <i class="bi bi-plus-circle"></i> Nueva Editorial
                </button>
            </div>

            <div class="card shadow">
                <div class="card-body">

                    <table id="tblEditoriales" class="table table-striped table-hover table-bordered dataTable">

                        <% if (lista == null || lista.size() < 1) { %>

                        <thead class="table-info text-center">
                            <tr><th>Editoriales</th></tr>
                        </thead>

                        <tbody class="text-center">
                            <tr>
                                <td>No hay editoriales registradas.</td>
                            </tr>
                        </tbody>

                        <% } else { %>

                        <thead class="table-info text-center">
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>País</th>
                                <th>Sitio Web</th>
                                <th>Funciones</th>
                            </tr>
                        </thead>

                        <tbody class="text-center">
                            <c:forEach var="e" items="${listaEditoriales}">
                                <tr>
                                    <td>${e.idEditorial}</td>
                                    <td>${e.nombre}</td>
                                    <td>${e.pais}</td>
                                    <td>${e.sitioWeb}</td>

                                    <td>
                                        <button type="button" class="btn btn-warning me-1"
                                                data-id="${e.idEditorial}"
                                                data-nombre="${e.nombre}"
                                                data-pais="${e.pais}"
                                                data-web="${e.sitioWeb}"
                                                onclick="abrirModalEditar(this)">
                                            <i class="bi bi-pencil"></i>
                                        </button>

                                        <button type="button" class="btn btn-danger"
                                                data-id="${e.idEditorial}"
                                                onclick="abrirModalEliminar(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            </c:forEach>
                        </tbody>

                        <% }%>

                    </table>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEditar">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Editar Editorial</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <form action="EditorialServlet" method="POST">
                        <div class="modal-body">

                            <input type="hidden" name="accion" value="editar">

                            <h6>ID</h6>
                            <input type="text" id="idEditorial" name="idEditorial" class="form-control mb-2" readonly>

                            <h6>Nombre</h6>
                            <input type="text" id="nombre" name="nombre" class="form-control mb-2">

                            <h6>País</h6>
                            <input type="text" id="pais" name="pais" class="form-control mb-2">

                            <h6>Sitio Web</h6>
                            <input type="text" id="sitioWeb" name="sitioWeb" class="form-control mb-2">

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-primary">Guardar Cambios</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalEliminar">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Eliminar Editorial</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <form action="EditorialServlet" method="POST">
                        <div class="modal-body text-center">

                            <input type="hidden" name="accion" value="eliminar">
                            <input type="hidden" id="idEliminar" name="idEliminar">

                            <h5>¿Desea eliminar esta editorial?</h5>
                            <small class="text-muted">Esta acción es irreversible</small>

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-danger">Eliminar</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

        <div class="modal fade" id="modalCrear">
            <div class="modal-dialog">
                <div class="modal-content">

                    <div class="modal-header">
                        <h5 class="modal-title">Crear Editorial</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <form action="EditorialServlet" method="POST">
                        <div class="modal-body">

                            <input type="hidden" name="accion" value="crear">

                            <h6>Nombre</h6>
                            <input type="text" name="nombre" class="form-control mb-2">

                            <h6>País</h6>
                            <input type="text" name="pais" class="form-control mb-2">

                            <h6>Sitio Web</h6>
                            <input type="text" name="sitioWeb" class="form-control mb-2">

                        </div>

                        <div class="modal-footer">
                            <button class="btn btn-success">Crear</button>
                        </div>

                    </form>

                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <% String accionSwal = (String) request.getAttribute("accion"); %>
        <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>

        <% if (hecho != null) { %>
        <script>
            <% if (hecho) {%>
                                                    Swal.fire({
                                                        icon: 'success',
                                                        title: 'Editorial <%=accionSwal%>',
                                                        text: 'La editorial se ha <%=accionSwal%> correctamente',
                                                        confirmButtonText: 'Aceptar'
                                                    }).then(() => {
                                                        window.location.href = '/AppBibliotecaWeb/EditorialServlet';
                                                    });
            <% } else {%>
                                                    Swal.fire({
                                                        icon: 'error',
                                                        title: 'Error',
                                                        text: 'No se  <%=accionSwal%> la editorial',
                                                        confirmButtonText: 'Aceptar'
                                                    }).then(() => {
                                                        window.location.href = '/AppBibliotecaWeb/EditorialServlet';
                                                    });
            <% } %>
        </script>
        <% }%>
        <script>
            function abrirModalEditar(btn) {
                const modal = document.getElementById("modalEditar");

                modal.querySelector("#idEditorial").value = btn.dataset.id;
                modal.querySelector("#nombre").value = btn.dataset.nombre;
                modal.querySelector("#pais").value = btn.dataset.pais;
                modal.querySelector("#sitioWeb").value = btn.dataset.web;

                new bootstrap.Modal(modal).show();
            }

            function abrirModalEliminar(btn) {
                const modal = document.getElementById("modalEliminar");
                modal.querySelector("#idEliminar").value = btn.dataset.id;

                new bootstrap.Modal(modal).show();
            }

            $(document).ready(function () {

                let table = $('#tblEditoriales').DataTable({
                    pageLength: 15,
                    lengthChange: false,
                    dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
                });

                let input = $('.dataTables_filter input');
                input.attr("placeholder", "🔍 Buscar Editorial...");

                $('.dataTables_filter label').contents().filter(function () {
                    return this.nodeType === 3;
                }).remove();

            });


        </script>

    </body>
</html>