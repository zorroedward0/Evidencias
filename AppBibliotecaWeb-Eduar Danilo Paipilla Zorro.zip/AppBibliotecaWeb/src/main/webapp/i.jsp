<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<% Usuario usuario = (Usuario) session.getAttribute("usuarioLogueado");%>


<!DOCTYPE html>
<html style="font-size: 16px;" lang="es">

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">
        <meta name="keywords" content="Hike the amazing mountains">
        <meta name="description" content="">
        <title>Home</title>
        <link rel="icon" type="image/x-icon" href="images/favicon.ico">
        <link rel="stylesheet" href="Css/nicepage.css" media="screen">
        <link rel="stylesheet" href="Css/index.css" media="screen">
        <script class="u-script" type="text/javascript" src="Js/jquery.js" defer=""></script>
        <script class="u-script" type="text/javascript" src="Js/nicepage.js" defer=""></script>
        <meta name="generator" content="Nicepage 8.4.14, nicepage.com">









        <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css2?display=swap&amp;family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&amp;family=Palanquin+Dark:wght@400;500;600;700">
        <script type="application/ld+json">{
            "@context": "http://schema.org",
            "@type": "Organization",
            "name": "",
            "logo": "images/default-logo.png"
            }</script>
        <meta name="theme-color" content="#478ac9">
        <meta property="og:title" content="Home 1">
        <meta property="og:type" content="website">
        <meta data-intl-tel-input-cdn-path="intlTelInput/">
    </head>

    <body data-home-page="https://website6636691.nicepage.io/Home-1.html?version=f7112e71-6834-b891-8499-74716beeec28"
          data-home-page-title="Home 1" data-path-to-root="./" data-include-products="false" class="u-body u-clearfix u-xl-mode"
          data-lang="es">
        <style>
            :root {
                --accent: #00d2ff;
                --accent-glow: #3a7bd5;
                --bg-dark: #020617;
            }

            #preloader {
                position: fixed;
                inset: 0;
                z-index: 9999;
                background: linear-gradient(rgba(2, 6, 23, 0.8), rgba(2, 6, 23, 0.8)),
                    url('images/backgroundAnimation.jpeg') no-repeat center center;
                background-size: cover;
                display: flex;
                justify-content: center;
                align-items: center;
                transition: transform 1s cubic-bezier(0.85, 0, 0.15, 1);
            }

            .loader-content {
                text-align: center;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 15px;
            }

            .loader-content h2 {
                font-size: 3rem;
                font-weight: 800;
                color: white;
                letter-spacing: 5px;
                background: linear-gradient(to right, #ffffff, var(--accent));
                -webkit-background-clip: text;
                -webkit-text-fill-color: transparent;
                margin: 0;
            }

            .loader-content img {
                width: 120px;
                height: 120px;
                object-fit: cover;
                border-radius: 50%;
                border: 3px solid rgba(255, 255, 255, 0.1);
                box-shadow: 0 0 25px rgba(0, 210, 255, 0.2);
                margin: 10px 0;
            }

            .loader-bar {
                width: 220px;
                height: 4px;
                background: rgba(255, 255, 255, 0.05);
                border-radius: 10px;
                overflow: hidden;
                position: relative;
            }

            .progress {
                height: 100%;
                width: 0;
                background: linear-gradient(90deg, var(--accent-glow), var(--accent));
                box-shadow: 0 0 15px var(--accent);
                animation: fill 2s cubic-bezier(0.65, 0, 0.35, 1) forwards;
            }

            @keyframes fill {
                to {
                    width: 100%;
                }
            }

            #preloader.loaded {
                transform: translateY(-100%);
            }

        </style>
        <div id="preloader">
            <div class="loader-content">
                <div>
                    <h2>Uni Bliblioteca</h2>
                    <img style="border-radius: 50%" src="images/logo.jpg" class="">
                </div>
                <div class="loader-bar"><div class="progress"></div></div>
            </div>
        </div>
        <header class="u-clearfix u-header u-header" id="sec-3fd7" style="  background: linear-gradient(135deg, #F7FAFC 0%, #F5F5DC 100%);">
            <div
                class="u-clearfix u-sheet u-valign-middle-lg u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-sheet-1">
                <a href="Home" class="u-image u-logo u-image-1" style="
                   display: inline-flex;
                   align-items: center;
                   gap: 12px;
                   text-decoration: none;
                   font-family: 'Segoe UI', Roboto, sans-serif;
                   font-weight: 600;
                   font-size: 1.2rem;
                   color: #333;
                   transition: color 0.3s ease;
                   ">
                    <img style="border-radius: 50%; width: 45px; height: 45px; object-fit: cover; box-shadow: 0 2px 5px rgba(0,0,0,0.1);" src="images/logo.jpg" class="u-logo-image u-logo-image-1">
                    <span class="logo-text">Home</span>
                </a>
                <%if (usuario == null) {%>
                <a href="login.jsp"
                   class="u-border-2 u-btn u-btn-round u-button-style u-custom-font u-hover-feature u-hover-palette-1-dark-3 u-palette-1-base u-radius u-btn-1"
                   data-animation-name="customAnimationIn" data-animation-duration="1000" data-animation-delay="0">Login </a>
                <%} else if (usuario != null) {%>
                <a href="Inicio"
                   class="u-border-2 u-btn u-btn-round u-button-style u-custom-font u-hover-feature u-hover-palette-1-dark-3 u-palette-1-base u-radius u-btn-1"
                   data-animation-name="customAnimationIn" data-animation-duration="1000" data-animation-delay="0">Volver </a>
                <%}%>
            </div>
        </header>
        <section class="u-align-center u-clearfix u-container-align-center u-section-1" id="sec-db91" style="background-image: url('images/backHome.jpg');">
            <div
                class="u-clearfix u-sheet u-valign-middle-lg u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-sheet-1">
                <div class="data-layout-selected u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
                    <div class="u-layout">
                        <div class="u-layout-row">
                            <div
                                class="u-align-left u-container-align-left u-container-style u-layout-cell u-size-29-lg u-size-29-xl u-size-60-md u-size-60-sm u-size-60-xs u-layout-cell-1"
                                data-animation-name="customAnimationIn" data-animation-duration="1500">
                                <div class="u-container-layout u-valign-middle u-container-layout-1">
                                    <div style="background-color: white; border-radius: 50px; padding: 40px;">
                                        <h1 class="u-align-left u-text u-text-2" data-animation-name="customAnimationIn"
                                            data-animation-duration="1500" data-animation-delay="500">
                                            <b><span style="font-weight: 400;"></span></b>Uni Biblioteca
                                        </h1>
                                        <h6 class="u-align-left u-text u-text-1">Donde las historias cobran vida y el conocimiento te espera.</h6>
                                    </div>

                                </div>
                            </div>
                            <div
                                class="u-align-left u-container-align-left u-container-style u-image u-image-round u-layout-cell u-radius-50 u-size-31-lg u-size-31-xl u-size-60-md u-size-60-sm u-size-60-xs u-image-1"
                                data-animation-name="customAnimationIn" data-animation-duration="1750" data-animation-delay="750">
                                <div class="u-container-layout u-container-layout-2"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="u-black u-clearfix u-section-2" id="sec-df7c">
            <img class="u-expanded-width u-image u-image-1"
                 src="https://i0.wp.com/www.julianmarquina.es/wp-content/uploads/The-Old-Library-Trinity-College.-CC-Diliff.jpg"
                 data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
            <h1 class="u-text u-text-body-alt-color u-text-default u-text-1" data-animation-name="customAnimationIn"
                data-animation-duration="1500" data-animation-delay="0">Libros Destacados <br>
            </h1>
        </section>
        <section class="u-black u-clearfix u-container-align-center u-section-3" id="carousel_5daf">
            <div class="u-clearfix u-sheet u-sheet-1">
                <div class="u-expanded-width u-list u-list-1">
                    <div class="u-repeater u-repeater-1">

                        <c:forEach var="libro" items="${listaDestacados}">
                            <div  style="border-radius: 15px !important" class="u-container-style u-list-item u-repeater-item u-shape-rectangle u-white u-list-item-1"
                                  data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                                <div class="u-container-layout u-similar-container u-valign-top u-container-layout-1">
                                    <img   style="border-radius: 10px !important" class="u-expanded-width u-image u-image-default u-image-1" src="${libro.imagen}" alt=""
                                           data-image-width="670" data-image-height="530" data-animation-name="customAnimationIn"
                                           data-animation-duration="1500" data-animation-delay="500">
                                    <h4 style="align-content: center"class="u-custom-font u-text u-text-1" data-animation-name="customAnimationIn"
                                        data-animation-duration="1500" data-animation-delay="500"> ${libro.titulo}</h4>
                                    <h5 style="align-content: center"class="u-custom-font u-text u-text-1" data-animation-name="customAnimationIn"
                                        data-animation-duration="1500" data-animation-delay="500"> Autores</h5>
                                    <h6 style="align-content: center"class="u-custom-font u-text u-text-1" data-animation-name="customAnimationIn"
                                        data-animation-duration="1500" data-animation-delay="500">
                                        <c:forEach var="autor" items="${libro.autores}" varStatus="status">

                                            <div>${autor.nombre} ${autor.apellido}</div><br>

                                        </c:forEach></h6>
                                    <h6 style="align-content: center"class="u-custom-font u-text u-text-1" data-animation-name="customAnimationIn"
                                        data-animation-duration="1500" data-animation-delay="500">${libro.anioPublicacion}</h6>
                                    <p class="u-text u-text-2" data-animation-name="customAnimationIn" data-animation-duration="1500"
                                       data-animation-delay="500">
                                    </p>
                                </div>
                            </div>
                        </c:forEach>

                    </div>
                </div>
            </div>
        </section>
        <section style="background:#092D37; padding:80px 0 40px 0;">

            <img src="https://www.upv.es/entidades/abdc/wp-content/uploads/2024/02/2024-01-23-BIBLIOTECA-CENTRAL-UPV-11-1-980x654.jpg"
                 style="display:block;
                 width:90%;
                 max-width:1400px;
                 height:450px;
                 object-fit:cover;
                 margin:0 auto;
                 border-radius:40px 40px 10px 10px;
                 box-shadow:0px 25px 60px rgba(0,0,0,0.3);">

        </section>
        <section style="background:#092D37; padding:40px 0 120px 0; min-height:900px;">
            <div style="display:flex; justify-content:center; gap:80px; flex-wrap:wrap; max-width:1600px; margin:auto;">

                <div style="background-image:url('images/backCard.jpg');
                     background-size:cover;
                     background-position:center;
                     border-radius:40px;
                     box-shadow:0px 25px 60px rgba(0,0,0,0.3);
                     display:flex;
                     justify-content:center;
                     align-items:center;
                     width:650px;
                     min-height:700px;
                     padding:60px;">

                    <div style="background:rgba(255,255,255,0.97);
                         padding:60px;
                         border-radius:30px;
                         width:100%;">

                        <h2 style="text-align:center; font-size:3.5rem; color:#1a202c; margin-bottom:35px;">
                            Servicios
                        </h2>

                        <ul style="list-style:none; padding:0; margin:0; color:#2d3748; font-size:1.4rem; line-height:2.2;">
                            <li>• Préstamo de libros físicos</li>
                            <li>• Sala de lectura silenciosa y espacios de estudio grupal</li>
                            <li>• Acceso a internet y recursos digitales</li>
                            <li>• Orientación y apoyo para tareas e investigaciones</li>
                            <li>• Actividades culturales y educativas durante el año</li>
                            <li>• Zona infantil con material didáctico</li>
                            <li>• Asesoría básica en búsqueda de información</li>
                        </ul>

                    </div>
                </div>

                <div style="background-image:url('images/backCard.jpg');
                     background-size:cover;
                     background-position:center;
                     border-radius:40px;
                     box-shadow:0px 25px 60px rgba(0,0,0,0.3);
                     display:flex;
                     justify-content:center;
                     align-items:center;
                     width:650px;
                     min-height:700px;
                     padding:60px;">

                    <div style="background:rgba(255,255,255,0.97);
                         padding:60px;
                         border-radius:30px;
                         width:100%;">

                        <h2 style="text-align:center; font-size:3.5rem; color:#1a202c; margin-bottom:35px;">
                            Comunidad
                        </h2>

                        <ul style="list-style:none; padding:0; margin:0; color:#2d3748; font-size:1.4rem; line-height:2.2;">
                            <li>• Clubes de lectura para todas las edades</li>
                            <li>• Talleres creativos y educativos</li>
                            <li>• Charlas, eventos culturales y presentaciones de libros</li>
                            <li>• Actividades para niños, jóvenes y adultos mayores</li>
                            <li>• Espacios de integración y aprendizaje colaborativo</li>
                            <li>• Promoción de la lectura en la comunidad</li>
                            <li>• Programas de participación y voluntariado</li>
                        </ul>

                    </div>
                </div>

            </div>
        </section>
        <section class="u-clearfix u-container-align-center u-section-6" id="sec-b38c">
            <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
                <div class="data-layout-selected u-clearfix u-expanded-width u-layout-wrap u-layout-wrap-1">
                    <div class="u-layout">
                        <div class="u-layout-row">
                            <div
                                class="u-container-align-center-xl u-container-style u-image u-layout-cell u-radius-50 u-size-30-lg u-size-30-xl u-size-60-md u-size-60-sm u-size-60-xs u-image-1"
                                data-animation-name="customAnimationIn" data-animation-duration="1250" data-animation-delay="0">
                                <div class="u-container-layout u-valign-middle u-container-layout-1"></div>
                            </div>
                            <div
                                class="u-container-style u-layout-cell u-size-30-lg u-size-30-xl u-size-60-md u-size-60-sm u-size-60-xs u-layout-cell-2"
                                data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="250">
                                <div
                                    class="u-container-layout u-valign-middle-lg u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-container-layout-2">
                                    <h2 class="u-align-center u-text u-text-default u-text-1" data-animation-name="customAnimationIn"
                                        data-animation-duration="1500" data-animation-delay="500">Sobre Nosostros<span
                                            style="font-size: 3rem;"></span>
                                    </h2>
                                    <p class="u-align-center u-text u-text-default u-text-2"> Somos un espacio dedicado a promover la
                                        lectura, el aprendizaje y la cultura. Nuestra biblioteca ofrece libros, recursos y actividades para
                                        todas las edades en un ambiente acogedor y accesible.<br>
                                        <br> Creemos que el conocimiento transforma vidas y queremos ser un punto de encuentro para lectores,
                                        estudiantes y soñadores.
                                    </p>
                                    <p class="u-align-center u-text u-text-3">Te invitamos a formar parte de nuestra comunidad</p>
                                    <a href="login.jsp"
                                       class="u-active-black u-align-center u-border-2 u-border-active-black u-border-custom-color-1 u-border-hover-black u-btn u-btn-round u-button-style u-hover-black u-none u-radius-50 u-text-active-white u-text-body-color u-text-hover-white u-btn-1"
                                       data-animation-name="" data-animation-duration="0" data-animation-delay="0"
                                       data-animation-direction="">Comencemos </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="u-align-center u-clearfix u-container-align-center u-image u-shading u-section-7" id="carousel_c2d1"
                 data-animation-name="" data-animation-duration="0" data-animation-delay="0" data-animation-direction="">
            <div
                class="u-clearfix u-sheet u-valign-middle-lg u-valign-middle-md u-valign-middle-sm u-valign-middle-xs u-sheet-1">
                <div class="u-list u-list-1">
                    <div class="u-repeater u-repeater-1">
                        <div class="u-container-style u-list-item u-repeater-item u-white u-list-item-1"
                             data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                            <div class="u-container-layout u-similar-container u-container-layout-1">
                                <h5 class="u-align-center u-custom-item u-text u-text-1" data-animation-name=""
                                    data-animation-duration="0" data-animation-delay="0" data-animation-direction="">Donde encontrarnos</h5>
                                <p class="u-align-center u-custom-item u-text u-text-2"> Cra. 11, Sogamoso, Boyacá<br>
                                </p>
                            </div>
                        </div>
                        <div class="u-container-style u-list-item u-repeater-item u-white u-list-item-2"
                             data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                            <div class="u-container-layout u-similar-container u-container-layout-2">
                                <h5 class="u-align-center u-custom-item u-text u-text-3" data-animation-name=""
                                    data-animation-duration="0" data-animation-delay="0" data-animation-direction="">Horario</h5>
                                <p class="u-align-center u-custom-item u-text u-text-4"><span style="font-weight: 700;">Lunes –
                                        Sábado</span>
                                    <br>8am – 7pm<br><b>Domingo</b>
                                    <br>10am – 5pm<br>
                                </p>
                            </div>
                        </div>
                        <div class="u-container-style u-list-item u-repeater-item u-white u-list-item-3"
                             data-animation-name="customAnimationIn" data-animation-duration="1500" data-animation-delay="500">
                            <div class="u-container-layout u-similar-container u-container-layout-3">
                                <h5 class="u-align-center u-custom-item u-text u-text-5" data-animation-name=""
                                    data-animation-duration="0" data-animation-delay="0" data-animation-direction="">Contactos</h5>
                                <p class="u-align-center u-custom-item u-text u-text-6">
                                    <a href="#"
                                       class="u-active-none u-border-1 u-border-active-black u-border-hover-black u-border-no-left u-border-no-right u-border-no-top u-border-palette-2-base u-btn u-button-link u-button-style u-hover-none u-none u-text-active-black u-text-hover-black u-text-palette-2-base u-btn-1"
                                       data-animation-name="" data-animation-duration="0" data-animation-delay="0"
                                       data-animation-direction=""> &nbsp;​310 456 7890</a>
                                    <br>
                                    <br>
                                    <a href="#"
                                       class="u-active-none u-border-1 u-border-active-black u-border-hover-black u-border-no-left u-border-no-right u-border-no-top u-border-palette-2-base u-btn u-button-link u-button-style u-hover-none u-none u-text-active-black u-text-hover-black u-text-palette-2-base u-btn-2"
                                       data-animation-name="" data-animation-duration="0" data-animation-delay="0"
                                       data-animation-direction=""> 312 987 6543</a>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        <footer style="background-color: black !important;" class="u-align-center u-clearfix u-container-align-center u-footer u-grey-80 u-footer" id="sec-75cc">
            <div class="u-clearfix u-sheet u-sheet-1">
                <p class="u-small-text u-text u-text-variant u-text-1">Adso2026©</p>
            </div>
        </footer>
        <script>
            window.addEventListener('load', () => {
                const preloader = document.getElementById('preloader');
                setTimeout(() => {
                    preloader.classList.add('loaded');
                }, 2000);
            });
        </script>
    </body>

</html>