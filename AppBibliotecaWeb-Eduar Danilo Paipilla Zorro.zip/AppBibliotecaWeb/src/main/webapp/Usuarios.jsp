<%@page import="sena.adso.appbibliotecaweb.model.TipoUsuario"%>
<%@page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>


<head>
    <meta charset="UTF-8">

    <link rel="icon" type="image/x-icon" href="images/usuarios.ico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
    <link href="Css/AdminStyles.css" rel="stylesheet">
    <title>Manejo de Usuarios</title>


</head>
<body>
    <jsp:include page="navbar.jsp"/>

    <div class="container">



        <div class="text-end mb-3">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCrear">
                <i class="bi bi-plus-circle"></i> Nuevo Usuario
            </button>
        </div>

        <div class="card shadow">
            <div class="card-body">

                <table id="tblUsuarios" class="table table-striped table-hover table-bordered align-middle">

                    <thead class="table-info text-center">
                        <tr>
                            <th>Referencia</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Documento</th>
                            <th>Email</th>
                            <th>Telefono</th>
                            <th>Estado</th>
                            <th>Rol</th>
                            <th>Funciones</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">
                        <c:forEach var="usu" items="${listaUsuarios}">
                            <tr>
                                <td>${usu.idUsuario}</td>
                                <td>${usu.nombre}</td>
                                <td>${usu.apellido}</td>
                                <td>${usu.documento}</td>
                                <td>${usu.email}</td>
                                <td>${usu.telefono}</td>
                                <td>${usu.estado==true?"Activo":"Inactivo"}</td>
                                <td>
                                    <c:forEach var="tipo" items="${listaTipos}">
                                        <c:if test="${tipo.idTipoUsuario == usu.idTipoUsuario}">
                                            ${tipo.nombre}
                                        </c:if>
                                    </c:forEach>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-warning me-1"
                                            data-id="${usu.idUsuario}"
                                            data-nombre="${usu.nombre}"
                                            data-apellido="${usu.apellido}"
                                            data-documento="${usu.documento}"
                                            data-email="${usu.email}"
                                            data-telefono="${usu.telefono}"
                                            data-estado="${usu.estado}"
                                            data-password="${usu.password}"
                                            data-tipousuario="${usu.idTipoUsuario}"
                                            onclick="abrirModalEditar(this)">
                                        <i class="bi bi-pencil"></i>
                                    </button>

                                    <button type="button" class="btn btn-danger"
                                            data-id="${usu.idUsuario}"
                                            data-nombre="${usu.nombre}"
                                            onclick="abrirModalEliminar(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>

                </table>

            </div>
        </div>


    </div>



    <div class="modal fade" id="modalEditar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">


                <div class="modal-header">
                    <h5 class="modal-title">Editar Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="UsuarioServlet" method="POST">
                    <div class="modal-body">

                        <input type="hidden" name="accion" value="editar">

                        <h6>ID</h6>
                        <input type="text" id="idUsuario" name="idUsuario" class="form-control mb-2" readonly>

                        <h6>Nombre</h6>
                        <input type="text" id="nombre" name="nombre" class="form-control mb-2">

                        <h6>Apellido</h6>
                        <input type="text" id="apellido" name="apellido" class="form-control mb-2">

                        <h6>Documento</h6>
                        <input type="text" id="documento" name="documento" class="form-control mb-2">

                        <h6>Email</h6>
                        <input type="text" id="email" name="email" class="form-control mb-2">

                        <h6>Contraseña</h6>
                        <input type="text" id="password" name="password" class="form-control mb-2">

                        <h6>Teléfono</h6>
                        <input type="text" id="telefono" name="telefono" class="form-control mb-2">

                        <h6>Tipo Usuario</h6>
                        <select name="tipo" id="tipo" class="form-select mb-2">
                            <c:forEach var="t" items="${listaTipos}">
                                <option value="${t.idTipoUsuario}">${t.nombre}</option>
                            </c:forEach>
                        </select>

                        <h6>Estado</h6>
                        <select name="estado" id="estado" class="form-select mb-2">
                            <option value="true">Activo</option>
                            <option value="false">Inactivo</option>
                        </select>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>

            </div>
        </div>


    </div>



    <div class="modal fade" id="modalEliminar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">


                <div class="modal-header">
                    <h5 class="modal-title">Eliminar Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="UsuarioServlet" method="post">
                    <div class="modal-body text-center">
                        <input type="hidden" name="accion" value="eliminar">

                        <input type="hidden" id="idEliminar" name="idEliminar">

                        <h5>¿Desea eliminar este usuario?</h5>

                        <input type="text" id="nombreEliminar" class="form-control text-center mb-2" readonly style="border:none;">

                        <small class="text-muted">Esta acción es irreversible</small>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </div>
                </form>

            </div>
        </div>


    </div>



    <div class="modal fade" id="modalCrear" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">


                <div class="modal-header">
                    <h5 class="modal-title">Crear Usuario</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="UsuarioServlet" method="POST">
                    <div class="modal-body">

                        <input type="hidden" name="accion" value="crear">

                        <h6>Nombre</h6>
                        <input type="text" name="nombre" class="form-control mb-2">

                        <h6>Apellido</h6>
                        <input type="text" name="apellido" class="form-control mb-2">

                        <h6>Documento</h6>
                        <input type="text" name="documento" class="form-control mb-2">

                        <h6>Email</h6>
                        <input type="text" name="email" class="form-control mb-2">

                        <h6>Contraseña</h6>
                        <input type="password" name="password" class="form-control mb-2">

                        <h6>Teléfono</h6>
                        <input type="text" name="telefono" class="form-control mb-2">

                        <h6>Tipo Usuario</h6>
                        <select name="tipo" class="form-select mb-2">
                            <c:forEach var="t" items="${listaTipos}">
                                <option value="${t.idTipoUsuario}">${t.nombre}</option>
                            </c:forEach>
                        </select>

                        <h6>Estado</h6>
                        <select name="activo" class="form-select mb-2">
                            <option value="true">Activo</option>
                            <option value="false">Inactivo</option>
                        </select>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Crear</button>
                    </div>
                </form>

            </div>
        </div>


    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <% String accionSwal = (String) request.getAttribute("accion");%>
    <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>
    <% if (hecho != null) { %>

    <script>
        <% if (hecho) {%>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Usuario <%=accionSwal%>',
                                                    text: 'El usuario se ha <%=accionSwal%> correctamente',
                                                    confirmButtonText: 'Aceptar'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = '/AppBibliotecaWeb/UsuarioServlet';
                                                    }
                                                });
        <% } else {%>
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Error',
                                                    text: 'No se ha podido <%=accionSwal%> el usuario',
                                                    confirmButtonText: 'Aceptar'
                                                }).then((result) => {
                                                    if (result.isConfirmed) {
                                                        window.location.href = '/AppBibliotecaWeb/UsuarioServlet';
                                                    }
                                                });
        <% } %>
    </script>
    <% }%>

    <script>
        function abrirModalEditar(btn) {
            const modal = document.getElementById("modalEditar");

            modal.querySelector("#idUsuario").value = btn.dataset.id;
            modal.querySelector("#nombre").value = btn.dataset.nombre;
            modal.querySelector("#apellido").value = btn.dataset.apellido;
            modal.querySelector("#documento").value = btn.dataset.documento;
            modal.querySelector("#email").value = btn.dataset.email;
            modal.querySelector("#telefono").value = btn.dataset.telefono;
            modal.querySelector("#password").value = btn.dataset.password;
            modal.querySelector("#estado").value = btn.dataset.estado;
            modal.querySelector("#tipo").value = parseInt(btn.dataset.tipousuario, 10);

            new bootstrap.Modal(modal).show();
        }

        function abrirModalEliminar(btn) {
            const modal = document.getElementById("modalEliminar");

            modal.querySelector("#idEliminar").value = btn.dataset.id;
            modal.querySelector("#nombreEliminar").value = btn.dataset.nombre;

            new bootstrap.Modal(modal).show();
        }

        $(document).ready(function () {

            let table = $('#tblUsuarios').DataTable({
                pageLength: 15,
                lengthChange: false,
                dom: '<"d-flex justify-content-between align-items-center mb-3"f>rt<"d-flex justify-content-between mt-2"ip>'
            });

            let input = $('.dataTables_filter input');
            input.attr("placeholder", "🔍 Buscar Usuario...");

            $('.dataTables_filter label').contents().filter(function () {
                return this.nodeType === 3;
            }).remove();

        });

    </script>
</body>


