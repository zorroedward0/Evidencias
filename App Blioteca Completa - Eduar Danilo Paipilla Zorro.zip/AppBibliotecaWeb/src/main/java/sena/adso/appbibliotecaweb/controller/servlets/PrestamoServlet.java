package sena.adso.appbibliotecaweb.controller.servlets;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sena.adso.appbibliotecaweb.controller.LibroController;
import sena.adso.appbibliotecaweb.controller.PrestamoController;
import sena.adso.appbibliotecaweb.controller.TipoUsuarioController;
import sena.adso.appbibliotecaweb.controller.UsuarioController;
import sena.adso.appbibliotecaweb.model.Libro;
import sena.adso.appbibliotecaweb.model.Prestamo;
import sena.adso.appbibliotecaweb.model.TipoUsuario;
import sena.adso.appbibliotecaweb.model.Usuario;

@WebServlet(name = "PrestamoServlet", urlPatterns = {"/PrestamoServlet"})
public class PrestamoServlet extends HttpServlet {

    private final PrestamoController controlP = new PrestamoController();
    private final UsuarioController controlU = new UsuarioController();
    private final LibroController controlL = new LibroController();
    private final TipoUsuarioController controlTu = new TipoUsuarioController();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null && !"Cliente".equals(rol) && "Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }
        if ("Cliente".equalsIgnoreCase(rol)) {
            List<Usuario> listaUsuarios = controlU.listarUsuarios();
            request.setAttribute("listaUsuarios", listaUsuarios);

            List<Prestamo> listaPrestamos = controlP.listarPrestamos();
            request.setAttribute("listaPrestamos", listaPrestamos);

            List<Libro> listaLibros = controlL.listarLibros();
            request.setAttribute("listaLibros", listaLibros);

            List<TipoUsuario> listaTiposUsuario = controlTu.listarTiposUsuario();
            request.setAttribute("listaTipos", listaTiposUsuario);

            RequestDispatcher rd = request.getRequestDispatcher("PrestamosCliente.jsp");
            rd.forward(request, response);
        } else if ("Administrador".equalsIgnoreCase(rol)) {
            List<Usuario> listaUsuarios = controlU.listarUsuarios();
            request.setAttribute("listaUsuarios", listaUsuarios);

            List<Prestamo> listaPrestamos = controlP.listarPrestamos();
            request.setAttribute("listaPrestamos", listaPrestamos);

            List<Libro> listaLibros = controlL.listarLibros();
            request.setAttribute("listaLibros", listaLibros);

            List<TipoUsuario> listaTiposUsuario = controlTu.listarTiposUsuario();
            request.setAttribute("listaTipos", listaTiposUsuario);

            RequestDispatcher rd = request.getRequestDispatcher("Prestamos.jsp");
            rd.forward(request, response);
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String rol = (String) session.getAttribute("rol");

        if (rol == null && !"Cliente".equals(rol) && "Administrador".equals(rol)) {
            response.sendRedirect("inicio.jsp");
            return;
        }
        String accion = request.getParameter("accion");

        switch (accion) {
            case "crear":
                crearPrestamo(request, response);
                break;
            case "editar":
                editarPrestamo(request, response);
                break;
            case "eliminar":
                eliminarPrestamo(request, response);
                break;
            default:
                response.sendRedirect("PrestamoServlet");
                break;
        }
    }

    private void crearPrestamo(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        LocalDate fechaPrestamo = LocalDate.parse(request.getParameter("fechaPrestamo"));
        LocalDate fechaEsperada = LocalDate.parse(request.getParameter("fechaEsperada"));

        Integer idLibro = Integer.valueOf(request.getParameter("idLibro"));
        Integer idUsuario = Integer.valueOf(request.getParameter("idUsuario"));

        Prestamo p = new Prestamo();

        p.setFechaPrestamo(fechaPrestamo);
        p.setFechaDevolucionEsperada(fechaEsperada);
        p.setFechaDevolucionReal(null);
        p.setEstado(true);
        p.setIdLibro(idLibro);
        p.setIdUsuario(idUsuario);

        boolean creado = controlP.insertarPrestamo(p);

        request.setAttribute("hecho", creado);
        request.setAttribute("accion", "creado");
        request.getRequestDispatcher("Prestamos.jsp").forward(request, response);
    }

    private void editarPrestamo(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer idPrestamo = Integer.valueOf(request.getParameter("idPrestamo"));

        LocalDate fechaEsperada = LocalDate.parse(request.getParameter("fechaEsperada"));

        String fechaRealStr = request.getParameter("fechaReal");
        LocalDate fechaReal = (fechaRealStr == null || fechaRealStr.isEmpty())
                ? null
                : LocalDate.parse(fechaRealStr);

        boolean estado = Boolean.parseBoolean(request.getParameter("estado"));
        Integer idLibro = Integer.valueOf(request.getParameter("idLibro"));

        Prestamo p = new Prestamo();

        p.setFechaDevolucionEsperada(fechaEsperada);
        p.setFechaDevolucionReal(fechaReal);
        if (p.getFechaDevolucionReal() != null) {
            p.setEstado(false);
        } else {
            p.setEstado(estado);
        }

        p.setIdLibro(idLibro);

        boolean actualizado = controlP.actualizarPrestamo(p, idPrestamo);

        request.setAttribute("hecho", actualizado);
        request.setAttribute("accion", "actualizado");
        request.getRequestDispatcher("Prestamos.jsp").forward(request, response);
    }

    private void eliminarPrestamo(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {

        Integer idPrestamo = Integer.valueOf(request.getParameter("idEliminar"));
        Integer idLibro = Integer.valueOf(request.getParameter("idLibro"));

        Prestamo p = new Prestamo();

        p.setIdPrestamo(idPrestamo);
        p.setIdLibro(idLibro);

        boolean eliminado = controlP.eliminarPrestamo(p);

        request.setAttribute("hecho", eliminado);
        request.setAttribute("accion", "eliminado");
        request.getRequestDispatcher("Prestamos.jsp").forward(request, response);
    }
}
