package sena.adso.appbibliotecaweb.controller;

import java.util.List;
import sena.adso.appbibliotecaweb.model.Prestamo;
import sena.adso.appbibliotecaweb.model.dao.PrestamoDaoI;
import sena.adso.appbibliotecaweb.model.dao.PrestamoDao;

public class PrestamoController {

    private final PrestamoDaoI prestamoDao = new PrestamoDao();

    public List<Prestamo> listarPrestamos(){
        return prestamoDao.listarPrestamos();
    }

    public boolean insertarPrestamo(Prestamo p){
        return prestamoDao.insertarPrestamo(p);
    }

    public boolean actualizarPrestamo(Prestamo prestamo, Integer idPrestamoI){
        return prestamoDao.actualizarPrestamo(prestamo, idPrestamoI);
    }

    public boolean eliminarPrestamo(Prestamo p){
        return prestamoDao.eliminarPrestamo(p);
    }
}
