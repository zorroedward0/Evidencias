package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Usuario;

import java.util.List;

public interface UsuarioDaoI {
    public List<Usuario> listarUsuarios();
    public String insertarUsuarios(List<Usuario> usuarios);
    public String actualizarUsuario(Usuario usuario, Integer idUsuarioI);
    public String eliminarUsuario(Integer idUsuarioI);

}
