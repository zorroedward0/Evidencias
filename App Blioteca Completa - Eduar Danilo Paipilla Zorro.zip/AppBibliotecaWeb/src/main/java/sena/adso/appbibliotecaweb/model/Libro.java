package sena.adso.appbibliotecaweb.model;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class Libro {
   
    private Integer idLibro;
    private String titulo;
    private String isbn;
    private Integer anioPublicacion;
    private int numPag;
    private boolean estado;
    private Editorial editorial; 
    private List<Autor> autores = new ArrayList<>();
    private List<Categoria> categorias = new ArrayList<>();

    public Libro(Integer idLibro) { this.idLibro = idLibro; }

    public Libro() {
    }

    
    public Integer getIdLibro() {
        return idLibro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Integer getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(Integer anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public int getNumPag() {
        return numPag;
    }

    public void setNumPag(int numPag) {
        this.numPag = numPag;
    }


    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean disponible) {
        this.estado = disponible;
    }
//    @Override
//    public String toString() {
//        return "Libro{" +
//                "idLibro=" + idLibro +
//                ", titulo='" + titulo + '\'' +
//                ", isbn='" + isbn + '\'' +
//                ", anioPublicacion=" + anioPublicacion +
//                ", numPag=" + numPag +
//                ", disponible=" + disponible +
//                ", idEditorial=" + idEditorial +
//                '}';
//    }

    public Editorial getEditorial() {
        return editorial;
    }

    public void setEditorial(Editorial editorial) {
        this.editorial = editorial;
    }

    public List<Autor> getAutores() {
        return autores;
    }

    public void setAutores(List<Autor> autores) {
        this.autores = autores;
    }

    public List<Categoria> getCategorias() {
        return categorias;
    }

    public void setCategorias(List<Categoria> categorias) {
        this.categorias = categorias;
    }
    
}
