package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Prestamo;

import java.util.List;

public interface PrestamoDaoI {
    public List<Prestamo> listarPrestamos();
    public boolean insertarPrestamo(Prestamo p);
    public boolean actualizarPrestamo(Prestamo prestamo, Integer idPrestamoI);
    public boolean eliminarPrestamo(Prestamo p);
}
