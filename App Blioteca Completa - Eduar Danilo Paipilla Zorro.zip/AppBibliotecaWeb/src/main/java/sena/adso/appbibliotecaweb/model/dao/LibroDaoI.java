package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.model.Libro;

import java.util.List;

public interface LibroDaoI {
    public List<Libro> listarLibros();
    public boolean insertarLibro(Libro libro, List<Integer> idsAutores, List<Integer> idsCategorias);
    public boolean actualizarLibro (Libro libro, List<Integer> nuevosIdsAutores, List<Integer> nuevosIdsCategorias);
    public boolean eliminarLibro(Integer idLibroI);
    public List<Libro>  listarLibrosPorCategoria(Integer idCategoria);

}
