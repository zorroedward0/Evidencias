package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.config.ConexionDb;
import sena.adso.appbibliotecaweb.model.Prestamo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDao implements PrestamoDaoI {

    @Override
    public List<Prestamo> listarPrestamos() {
        List<Prestamo> lista = new ArrayList<>();
        String sql = "SELECT * FROM prestamo";

        try (Connection con = ConexionDb.establecerConexion(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {

                Date fP = rs.getDate("fechaPrestamo");
                Date fDE = rs.getDate("fechaDevolucionEsperada");
                Date fDR = rs.getDate("fechaDevolucionReal");

                lista.add(new Prestamo(
                        rs.getInt("idPrestamo"),
                        (fP != null) ? fP.toLocalDate() : null,
                        (fDE != null) ? fDE.toLocalDate() : null,
                        (fDR != null) ? fDR.toLocalDate() : null,
                        rs.getBoolean("estado"),
                        rs.getInt("idLibro"),
                        rs.getInt("idUsuario")
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al listar préstamos", e);
        }

        return lista;
    }

    @Override
    public boolean insertarPrestamo(Prestamo p) {
        if (p == null) {
            return false;
        }

        String sqlPrestamo = "INSERT INTO prestamo (fechaPrestamo, fechaDevolucionEsperada, fechaDevolucionReal, estado, idLibro, idUsuario) VALUES (?, ?, ?, ?, ?, ?)";
        String sqlLibro = "UPDATE libro SET disponible = false WHERE idLibro = ?";

        try (Connection con = ConexionDb.establecerConexion()) {
            con.setAutoCommit(false);

            try (PreparedStatement psP = con.prepareStatement(sqlPrestamo); PreparedStatement psL = con.prepareStatement(sqlLibro)) {

                if (p.getFechaPrestamo() != null) {
                    psP.setDate(1, Date.valueOf(p.getFechaPrestamo()));
                } else {
                    psP.setNull(1, Types.DATE);
                }

                if (p.getFechaDevolucionEsperada() != null) {
                    psP.setDate(2, Date.valueOf(p.getFechaDevolucionEsperada()));
                } else {
                    psP.setNull(2, Types.DATE);
                }

                if (p.getFechaDevolucionReal() != null) {
                    psP.setDate(3, Date.valueOf(p.getFechaDevolucionReal()));
                } else {
                    psP.setNull(3, Types.DATE);
                }

                psP.setBoolean(4, p.getEstado());
                psP.setInt(5, p.getIdLibro());
                psP.setInt(6, p.getIdUsuario());

                if (psP.executeUpdate() == 0) {
                    con.rollback();
                    return false;
                }

                psL.setInt(1, p.getIdLibro());
                if (psL.executeUpdate() == 0) {
                    con.rollback();
                    return false;
                }

                con.commit();
                return true;

            } catch (SQLException e) {
                con.rollback();
                throw new RuntimeException("Error al insertar préstamo", e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error de conexión al insertar préstamo", e);
        }
    }

    @Override
    public boolean actualizarPrestamo(Prestamo p, Integer idPrestamo) {
        if (p == null || idPrestamo == null) {
            return false;
        }

        String sqlPrestamo = "UPDATE prestamo SET fechaDevolucionEsperada=?, fechaDevolucionReal=?, estado=? WHERE idPrestamo=?";
        String sqlLibro = "UPDATE libro SET disponible = true WHERE idLibro=?";

        try (Connection con = ConexionDb.establecerConexion()) {
            con.setAutoCommit(false);

            try (PreparedStatement psP = con.prepareStatement(sqlPrestamo); PreparedStatement psL = con.prepareStatement(sqlLibro)) {

                if (p.getFechaDevolucionEsperada() != null) {
                    psP.setDate(1, Date.valueOf(p.getFechaDevolucionEsperada()));
                } else {
                    psP.setNull(1, Types.DATE);
                }

                if (p.getFechaDevolucionReal() != null) {
                    psP.setDate(2, Date.valueOf(p.getFechaDevolucionReal()));
                } else {
                    psP.setNull(2, Types.DATE);
                }

                psP.setBoolean(3, p.getEstado());
                psP.setInt(4, idPrestamo);

                if (psP.executeUpdate() == 0) {
                    con.rollback();
                    return false;
                }

                psL.setInt(1, p.getIdLibro());
                psL.executeUpdate();

                con.commit();
                return true;

            } catch (SQLException e) {
                con.rollback();
                throw new RuntimeException("Error al actualizar préstamo", e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error de conexión al actualizar préstamo", e);
        }
    }

    @Override
    public boolean eliminarPrestamo(Prestamo p) {
        if (p == null || p.getIdPrestamo() == null) {
            return false;
        }

        String sqlDelete = "DELETE FROM prestamo WHERE idPrestamo=?";
        String sqlLibro = "UPDATE libro SET disponible=true WHERE idLibro=?";

        try (Connection con = ConexionDb.establecerConexion()) {
            con.setAutoCommit(false);

            try (PreparedStatement psD = con.prepareStatement(sqlDelete); PreparedStatement psL = con.prepareStatement(sqlLibro)) {

                psD.setInt(1, p.getIdPrestamo());

                if (psD.executeUpdate() == 0) {
                    con.rollback();
                    return false;
                }

                if (p.getEstado()) {
                    psL.setInt(1, p.getIdLibro());
                    psL.executeUpdate();
                }

                con.commit();
                return true;

            } catch (SQLException e) {
                con.rollback();
                throw new RuntimeException("Error al eliminar préstamo", e);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error de conexión al eliminar préstamo", e);
        }
    }
}
