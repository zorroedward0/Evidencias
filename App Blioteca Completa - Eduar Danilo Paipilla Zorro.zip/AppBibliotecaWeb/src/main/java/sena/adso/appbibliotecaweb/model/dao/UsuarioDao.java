package sena.adso.appbibliotecaweb.model.dao;

import sena.adso.appbibliotecaweb.config.ConexionDb;
import sena.adso.appbibliotecaweb.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDao implements UsuarioDaoI{

    @Override
    public List<Usuario> listarUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT idUsuario, documento, nombre, apellido, email, telefono, estado, idTipoUsuario,password FROM usuario";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                usuarios.add(new Usuario(
                        rs.getObject("idUsuario", Integer.class),
                        rs.getString("documento"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("email"),
                        rs.getString("telefono"),
                        rs.getBoolean("estado"),
                        rs.getObject("idTipoUsuario", Integer.class),
                        rs.getString("password")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar usuarios ", e);
        }
        return usuarios;
    }

    @Override
    public String insertarUsuarios(List<Usuario> usuarios) {
        if (usuarios == null || usuarios.isEmpty()) return "No se ha encontrado usuarios para insertar.";
        String sql = "INSERT INTO usuario (documento, nombre, apellido, email, telefono, estado, idTipoUsuario,password) values (?,?,?,?,?,?,?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (Usuario usuario : usuarios) {
                ps.setString(1, usuario.getDocumento());
                ps.setString(2, usuario.getNombre());
                ps.setString(3, usuario.getApellido());
                ps.setString(4, usuario.getEmail());
                ps.setString(5, usuario.getTelefono());
                ps.setBoolean(6, usuario.isEstado());
                ps.setObject(7, usuario.getIdTipoUsuario());
                ps.setObject(8, usuario.getPassword());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " usuarios.";
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al insertar usuarios ", e);
            }
        }
        return mensaje;
    }

    @Override
    public String actualizarUsuario(Usuario usuario, Integer idUsuarioI) {

        if (usuario == null || idUsuarioI == null) return "No has ingresado informacion suficiente para actualizar un usuario.";
        String sql = " UPDATE usuario SET documento = ?, nombre = ?, apellido = ?, email = ?, telefono = ?, estado = ?, idTipoUsuario = ? , password = ? WHERE idUsuario = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, usuario.getDocumento());
            ps.setString(2, usuario.getNombre());
            ps.setString(3, usuario.getApellido());
            ps.setString(4, usuario.getEmail());
            ps.setString(5, usuario.getTelefono());
            ps.setBoolean(6, usuario.isEstado());
            ps.setObject(7, usuario.getIdTipoUsuario());
            ps.setString(8, usuario.getPassword());
            ps.setInt(9, idUsuarioI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado el usuario correctamente.";
            } else mensaje = "No se ha podido actualizar el usuario.";
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al intentar actualizar el usuario ", e);
            }
        }
        return mensaje;
    }
    @Override
    public String eliminarUsuario(Integer idUsuarioI) {

        if (idUsuarioI == null) return "No has ingresado el id del usuario para eliminar su informacion.";
        String sql = " DELETE FROM usuario WHERE idUsuario = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idUsuarioI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el usuario con el id " + idUsuarioI + " correctamente.";
            } else mensaje = "No se ha podido eliminar el usuario.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el usuario ", e);
        }
        return mensaje;
    }
}