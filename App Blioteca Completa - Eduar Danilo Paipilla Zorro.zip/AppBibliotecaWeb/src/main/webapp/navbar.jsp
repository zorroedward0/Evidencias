<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");
    if (rol == null) {
        rol = "";
    }
    if (rol != null) {
        response.sendRedirect("login.jsp");
    }
%>

<style>
    nav {
        background-color: #ffffff;
        padding: 15px 30px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
        border-radius: 10px;
        margin: 20px auto;
        max-width: 1200px;
    }

    nav .nav-links {
        display: flex;
        gap: 20px;
    }

    nav a {
        color: #2f3640;
        text-decoration: none;
        font-weight: 500;
        padding: 8px 15px;
        border-radius: 8px;
        transition: background-color 0.3s, color 0.3s;
    }

    nav a:hover {
        background-color: #00a8ff;
        color: #fff;
    }

    .logout {
        color: #e84118;
        font-weight: 600;
        padding: 8px 15px;
        border-radius: 8px;
        transition: background-color 0.3s, color 0.3s;
    }

    .logout:hover {
        background-color: #e84118;
        color: #fff;
    }

    @media (max-width: 600px) {
        nav {
            flex-direction: column;
            gap: 10px;
        }
        nav .nav-links {
            flex-direction: column;
            gap: 10px;
        }
    }
</style>

<nav>
    <div class="nav-links">
        <%
            if ("Administrador".equals(rol)) {
        %>
        <a href="inicio.jsp">Inicio</a>
        <a href="LibroServlet">Libros</a>
        <a href="PrestamoServlet">Préstamos</a>
        <a href="UsuarioServlet">Usuarios</a>
        <%
        } else if ("Cliente".equals(rol)) {
        %>
        <a href="inicioCliente.jsp">Inicio</a>
        <a href="LibroServlet">Libros</a>
        <a href="PrestamoServlet">Mis Préstamos</a>
        <%
            }
        %>
    </div>

    <form action="logout.jsp" method="post">
        <button type="submit" class="logout">Salir</button>
    </form>
</nav>