<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");
    if (rol == null) {
        rol = "";
    }
    if (rol != null) {
        response.sendRedirect("login.jsp");
    }
%>


<style>
    .navbar-custom {
        background: linear-gradient(135deg, #1e3c72, #2a5298);
        padding: 12px 25px;
        font-family: 'Segoe UI', sans-serif;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);

        display: flex;
        justify-content: space-between;
        align-items: center;

        border-radius: 12px;
        margin: 20px auto;
        max-width: 1200px;
    }

    .nav-left {
        display: flex;
        align-items: center;
        gap: 25px;
    }

    .logo {
        height: 45px;
        width: auto;
        object-fit: contain;
    }

    .nav-links {
        display: flex;
        gap: 15px;
    }

    .nav-links a {
        color: #ffffff;
        text-decoration: none;
        font-weight: 500;
        padding: 8px 14px;
        border-radius: 8px;
        transition: all 0.3s ease;
    }

    .nav-links a:hover {
        background: rgba(255,255,255,0.2);
    }

    .logout {
        background: #0b3c5d;
        color: #fff;
        font-weight: 600;
        padding: 8px 16px;
        border-radius: 20px;
        border: none;
        transition: 0.3s;
    }

    .logout:hover {
        background: #cce4f6;
        color: #0b1f2a;
    }

    @media (max-width: 768px) {
        .navbar-custom {
            flex-direction: column;
            gap: 10px;
            text-align: center;
        }

        .nav-left {
            flex-direction: column;
            gap: 10px;
        }

        .nav-links {
            flex-direction: column;
        }
    }
</style>

<nav class="navbar-custom">


    <div class="nav-left">

        <div class="nav-links">
            <%
                if ("Administrador".equals(rol)) {
            %>
            <a href="inicio.jsp">Inicio</a>
            <a href="LibroServlet">Libros</a>
            <a href="PrestamoServlet">Préstamos</a>
            <a href="UsuarioServlet">Usuarios</a>

            <%
            } else if ("Cliente".equals(rol)) {
            %>
            <a href="inicioCliente.jsp">Inicio</a>
            <a href="LibroServlet">Libros</a>
            <a href="PrestamoServlet">Mis Préstamos</a>
            <%
                }
            %>
        </div>

    </div>

    <form action="logout.jsp" method="post">
        <button type="submit" class="logout">Salir</button>
    </form>


</nav>
