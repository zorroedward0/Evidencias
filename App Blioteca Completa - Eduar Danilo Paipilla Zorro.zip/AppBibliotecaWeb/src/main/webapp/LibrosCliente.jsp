<%@ page contentType="text/html;charset=UTF-8" %>
<%@ page import="sena.adso.appbibliotecaweb.model.TipoUsuario"%>
<%@ page import="sena.adso.appbibliotecaweb.model.Usuario"%>
<%@ page import="java.util.List"%>
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>

<%
    String rol = (String) session.getAttribute("rol");
    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<jsp:include page="navbar.jsp"/>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Libros</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
    <link href="Css/ClienteStyles.css" rel="stylesheet"/>
   
</head>
<body>

<div class="container">
    <h1>Visualizador Libros</h1>
    <h5 class="h4-libros">Recuerda que si deseas tomar prestado alguno de estos libros puedes dirigirte ala biblioteca y pedirlo con uno de nuestros funcionarios </h5>

    <div class="table-responsive">
        <table id="tblLibros" class="table table-striped table-hover table-bordered align-middle">
            <thead class="text-center">
                <tr>
                    <th>Referencia</th>
                    <th>Titulo</th>
                    <th>Isbn</th>
                    <th>Año de Publicacion</th>
                    <th>Numero de Paginas</th>
                    <th>Estado</th>
                    <th>Editorial</th>
                    <th>Autores</th>
                    <th>Categorias</th>
                </tr>
            </thead>
            <tbody class="text-center">
                <c:forEach var="libro" items="${listaLibros}">
                    <tr>
                        <td>${libro.idLibro}</td>
                        <td>${libro.titulo}</td>
                        <td>${libro.isbn}</td>
                        <td>${libro.anioPublicacion}</td>
                        <td>${libro.numPag}</td>
                        <td>${libro.estado==true?"Disponible":"No Disponible"}</td>
                        <td>${libro.editorial.nombre}</td>
                        <td>
                            <c:forEach var="autor" items="${libro.autores}">
                                <div>${autor.nombre} ${autor.apellido}</div>
                            </c:forEach>
                        </td>
                        <td>
                            <c:forEach var="categoria" items="${libro.categorias}">
                                <div>${categoria.nombre}</div>
                            </c:forEach>
                        </td>
                    </tr>
                </c:forEach>
            </tbody>
        </table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
<script>
    $(document).ready(function () {
        $('#tblLibros').DataTable({
            pageLength: 15,
            lengthChange: false
        });
    });
</script>

</body>
</html>