<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<jsp:include page="navbar.jsp"/>
<head>
    <link href="Css/inicio.css" rel="stylesheet"/>
</head>

<body>
    <div class="container">
        <h1>Panel del Administrador</h1>
        <p>Bienvenido, tienes acceso completo al sistema.</p>

        <div class="cards">
            <div class="card">
                <h3>Gestión de Libros</h3>
                <p>Agregar, editar o eliminar libros del catálogo.</p>
                <a href="LibroServlet">Ir a Libros</a>
            </div>

            <div class="card">
                <h3>Gestión de Préstamos</h3>
                <p>Revisar préstamos activos, historial y devoluciones.</p>
                <a href="PrestamoServlet">Ir a Préstamos</a>
            </div>

            <div class="card">
                <h3>Gestión de Usuarios</h3>
                <p>Administrar roles, permisos y datos de los usuarios.</p>
                <a href="UsuarioServlet">Ir a Usuarios</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.botpress.cloud/webchat/v3.6/inject.js"></script>
    <script src="https://files.bpcontent.cloud/2026/03/27/12/20260327122358-J1TV4VO2.js" defer></script>

</body>