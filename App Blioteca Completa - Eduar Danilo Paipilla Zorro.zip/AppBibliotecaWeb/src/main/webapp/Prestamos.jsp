<%@page import="sena.adso.appbibliotecaweb.model.Prestamo"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Administrador".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>
<!DOCTYPE html>

<head>
    <meta charset="UTF-8">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.4/font/bootstrap-icons.css" />
    <link href="Css/AdminStyles.css" rel="stylesheet"/>
    <title>Manejo de Prestamos</title>


</head>

<body>
    <% List<Prestamo> lista = (List<Prestamo>) request.getAttribute("listaPrestamos");%>
    <jsp:include page="navbar.jsp"/>


    <div class="container">

        <div class="text-end mb-3">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalCrear">
                <i class="bi bi-plus-circle"></i> Nuevo Prestamo
            </button>
        </div>

        <div class="card shadow">
            <div class="card-body">

                <table id="tblPrestamos" class="table table-striped table-hover table-bordered align-middle">
                    <%if (lista == null || lista.size()<1) {%>

                    <thead class="table-info text-center">
                        <tr>
                            <th>Prestamos</th>

                        </tr>
                    </thead>

                    <tbody class="text-center">

                        <tr>
                            <td><%= "No hay prestamo registrados actualmente."%></td>

                        </tr>

                    </tbody>

                    <%} else {%>
                    <thead class="table-info text-center">
                        <tr>
                            <th>ID</th>
                            <th>Fecha Prestamo</th>
                            <th>Fecha Esperada</th>
                            <th>Fecha Devolucion</th>
                            <th>Estado</th>
                            <th>Libro</th>
                            <th>Usuario</th>
                            <th>Funciones</th>
                        </tr>
                    </thead>

                    <tbody class="text-center">
                        <c:forEach var="p" items="${listaPrestamos}">
                            <tr>
                                <td>${p.idPrestamo}</td>
                                <td>${p.fechaPrestamo}</td>
                                <td>${p.fechaDevolucionEsperada}</td>
                                <td>${p.fechaDevolucionReal == null ? "Aún no devuelto" : p.fechaDevolucionReal}</td>
                                <td>${p.estado==true?"Activo":"Finalizado"}</td>

                                <td>
                                    <c:forEach var="l" items="${listaLibros}">
                                        <c:if test="${l.idLibro == p.idLibro}">
                                            ${l.titulo}
                                        </c:if>
                                    </c:forEach>
                                </td>

                                <td>
                                    <c:forEach var="u" items="${listaUsuarios}">
                                        <c:if test="${u.idUsuario == p.idUsuario}">
                                            <div>${u.nombre} ${u.apellido} </div>

                                            <c:forEach var="tipo" items="${listaTipos}">
                                                <c:if test="${tipo.idTipoUsuario == u.idTipoUsuario}">
                                                    <div style="${tipo.nombre.equalsIgnoreCase("Cliente")?"background-color: #ADD8E6; border-radius:50px;":" background-color: #90EE90; border-radius:50px;"}">  ${tipo.nombre}</div>
                                                </c:if>
                                            </c:forEach>

                                        </c:if>
                                    </c:forEach>
                                </td>

                                <td>
                                    <button type="button" class="btn btn-warning me-1"
                                            data-id="${p.idPrestamo}"
                                            data-fechaesperada="${p.fechaDevolucionEsperada}"
                                            data-fechareal="${p.fechaDevolucionReal}"
                                            data-estado="${p.estado}"
                                            data-libro="${p.idLibro}"
                                            data-usuario="${p.idUsuario}"
                                            onclick="abrirModalEditar(this)">
                                        <i class="bi bi-pencil"></i>
                                    </button>

                                    <button type="button" class="btn btn-danger"
                                            data-id="${p.idPrestamo}"
                                            data-idlibro="${p.idLibro}"
                                            onclick="abrirModalEliminar(this)">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                    <%}%>
                </table>

            </div>
        </div>

    </div>

    <div class="modal fade" id="modalEditar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Editar Prestamo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="PrestamoServlet" method="POST">
                    <div class="modal-body">

                        <input type="hidden" name="accion" value="editar">

                        <h6>ID</h6>
                        <input type="text" id="idPrestamo" name="idPrestamo" class="form-control mb-2" readonly>

                        <h6>Fecha Devolucion Esperada</h6>
                        <input type="date" id="fechaEsperada" name="fechaEsperada" class="form-control mb-2">

                        <h6>Fecha Devolucion Real</h6>
                        <input type="date" id="fechaReal" name="fechaReal" class="form-control mb-2">

                        <h6>Estado</h6>
                        <select name="estado" id="estado" class="form-select mb-2">
                            <option value="true">Activo</option>
                            <option value="false">Finalizado</option>
                        </select>

                        <h6>Libro</h6>
                        <select name="idLibro" id="idLibro" class="form-select mb-2">
                            <c:forEach var="l" items="${listaLibros}">
                                <option value="${l.idLibro}">${l.titulo}</option>
                            </c:forEach>
                        </select>

                        <h6>Usuario</h6>
                        <select name="idUsuario" id="idUsuario" class="form-select mb-2">
                            <c:forEach var="u" items="${listaUsuarios}">
                                <option value="${u.idUsuario}">${u.nombre}
                                    <c:forEach var="tipo" items="${listaTipos}">
                                        <c:if test="${tipo.idTipoUsuario == u.idTipoUsuario}">
                                            ${"Rol:"} ${tipo.nombre}
                                        </c:if>
                                    </c:forEach>
                                </option>
                            </c:forEach>
                        </select>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modalEliminar" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Eliminar Prestamo</h5>
                    <small class="text-muted">Esta acción es irreversible</small>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="PrestamoServlet" method="post">
                    <div class="modal-body text-center">

                        <input type="hidden" name="accion" value="eliminar">

                        <input type="hidden" id="idEliminar" name="idEliminar">

                        <input type="hidden" id="idLibro" name="idLibro">

                        <h5>¿Desea eliminar este prestamo?</h5>

                        <small class="text-muted">Esta acción es irreversible</small>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-danger">Eliminar</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <div class="modal fade" id="modalCrear" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title">Crear Prestamo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <form action="PrestamoServlet" method="POST">
                    <div class="modal-body">

                        <input type="hidden" name="accion" value="crear">

                        <h6>Fecha Prestamo</h6>
                        <input type="date" name="fechaPrestamo" class="form-control mb-2">

                        <h6>Fecha Devolucion Esperada</h6>
                        <input type="date" name="fechaEsperada" class="form-control mb-2">

                        <h6>Libro</h6>
                        <select name="idLibro" class="form-select mb-2">
                            <c:forEach var="l" items="${listaLibros}">
                                <option value="${l.idLibro}">${l.titulo}</option>
                            </c:forEach>
                        </select>

                        <h6>Usuario</h6>
                        <select name="idUsuario" class="form-select mb-2">
                            <c:forEach var="u" items="${listaUsuarios}">
                                <option value="${u.idUsuario}">${u.nombre}</option>
                            </c:forEach>
                        </select>

                    </div>

                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Crear</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <% String accionSwal = (String) request.getAttribute("accion"); %>
    <% Boolean hecho = (Boolean) request.getAttribute("hecho"); %>

    <% if (hecho != null) { %>
    <script>
        <% if (hecho) {%>
                                                Swal.fire({
                                                    icon: 'success',
                                                    title: 'Prestamo <%=accionSwal%>',
                                                    text: 'El prestamo se ha <%=accionSwal%> correctamente',
                                                    confirmButtonText: 'Aceptar'
                                                }).then(() => {
                                                    window.location.href = '/AppBibliotecaWeb/PrestamoServlet';
                                                });
        <% } else {%>
                                                Swal.fire({
                                                    icon: 'error',
                                                    title: 'Error',
                                                    text: 'No se ha podido <%=accionSwal%> el prestamo',
                                                    confirmButtonText: 'Aceptar'
                                                }).then(() => {
                                                    window.location.href = '/AppBibliotecaWeb/PrestamoServlet';
                                                });
        <% } %>
    </script>
    <% }%>

    <script>
        function abrirModalEditar(btn) {
            const modal = document.getElementById("modalEditar");

            modal.querySelector("#idPrestamo").value = btn.dataset.id;
            modal.querySelector("#fechaEsperada").value = btn.dataset.fechaesperada;
            modal.querySelector("#fechaReal").value = btn.dataset.fechareal;
            modal.querySelector("#estado").value = btn.dataset.estado;
            modal.querySelector("#idLibro").value = btn.dataset.libro;
            modal.querySelector("#idUsuario").value = btn.dataset.usuario;

            new bootstrap.Modal(modal).show();
        }

        function abrirModalEliminar(btn) {
            const modal = document.getElementById("modalEliminar");

            modal.querySelector("#idEliminar").value = btn.dataset.id;
            modal.querySelector("#idLibro").value = btn.dataset.idlibro;

            new bootstrap.Modal(modal).show();
        }

        $(document).ready(function () {
            $('#tblPrestamos').DataTable({
                pageLength: 15,
                lengthChange: false
            });
        });
    </script>

</body>