<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="Css/login.css" rel="stylesheet">
    </head>

    <body>
<% String resultado = (String) request.getAttribute("error"); %>
<%=resultado%>
        <div class="container-fluid">
            <div class="row login-container">

                <div class="col-md-6 d-none d-md-block img-side"></div>

                <div class="col-md-6 d-flex align-items-center justify-content-center">
                    <div class="card shadow p-4" style="width: 100%; max-width: 400px;">

                        <h3 class="text-center mb-4 title-login">Iniciar Sesión</h3>

                        <form action="LoginServlet" method="POST">
                            <div class="mb-3">
                                <label class="form-label">Correo</label>
                                <input type="email" name="email" class="form-control" placeholder="Ingrese su correo">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Contraseña</label>
                                <input type="password" name="password" class="form-control" placeholder="Ingrese su contraseña">
                            </div>

                            <button type="submit" class="btn btn-library w-100">Ingresar</button>
                        </form>

                    </div>
                </div>

            </div>
        </div>

    </body>
</html>