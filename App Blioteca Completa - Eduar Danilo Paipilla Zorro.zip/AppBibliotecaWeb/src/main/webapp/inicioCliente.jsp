<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<jsp:include page="navbar.jsp"/>
<head>
    <link href="Css/inicioCliente.css" rel="stylesheet"/>
</head>
<body>
    <div class="container">
        <h1>Panel del Cliente</h1>
        <p>Bienvenido, aquí puedes gestionar tus préstamos.</p>

        <div class="cards">
            <div class="card">
                <h3>Ver Libros Disponibles</h3>
                <p>Explora el catálogo y encuentra tu próximo libro.</p>
                <a href="LibroServlet">Ver Libros</a>
            </div>

            <div class="card">
                <h3>Mis Préstamos</h3>
                <p>Consulta los libros que tienes actualmente en préstamo.</p>
                <a href="PrestamoServlet">Ir a Mis Préstamos</a>
            </div>

            <div class="card">
                <h3>Historial de Préstamos</h3>
                <p>Revisa todos los préstamos que has realizado anteriormente.</p>
                <a href="PrestamoServlet">Ver Historial</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.botpress.cloud/webchat/v3.6/inject.js"></script>
    <script src="https://files.bpcontent.cloud/2026/03/27/12/20260327122358-J1TV4VO2.js" defer></script>

</body>