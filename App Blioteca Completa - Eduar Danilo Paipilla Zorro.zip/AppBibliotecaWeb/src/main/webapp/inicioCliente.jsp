<%@ page contentType="text/html;charset=UTF-8" %>
<%
    String rol = (String) session.getAttribute("rol");

    if (rol == null || !"Cliente".equals(rol)) {
        response.sendRedirect("login.jsp");
        return;
    }
%>

<jsp:include page="navbar.jsp"/>

<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #1E5370;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 900px;
        margin: 40px auto;
        background-color: #ffffff;
        padding: 40px;
        border-radius: 15px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #2f3640;
    }

    p {
        text-align: center;
        color: #718093;
        font-size: 1.1em;
    }

    .cards {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
        margin-top: 30px;
        gap: 20px;
    }

    .card {
        flex: 1 1 250px;
        background-color: #f1f2f6;
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        transition: transform 0.3s, box-shadow 0.3s;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 15px 25px rgba(0, 0, 0, 0.2);
    }

    .card h3 {
        margin-bottom: 15px;
        color: #2f3640;
    }

    .card p {
        color: #636e72;
        margin-bottom: 20px;
    }

    .card a {
        display: inline-block;
        padding: 10px 20px;
        background-color: #00a8ff;
        color: white;
        text-decoration: none;
        border-radius: 8px;
        transition: background-color 0.3s;
    }

    .card a:hover {
        background-color: #0097e6;
    }
</style>

<div class="container">
    <h1>Panel del Cliente</h1>
    <p>Bienvenido, aquí puedes gestionar tus préstamos.</p>

    <div class="cards">
        <div class="card">
            <h3>Ver Libros Disponibles</h3>
            <p>Explora el catálogo y encuentra tu próximo libro.</p>
            <a href="LibroServlet">Ver Libros</a>
        </div>

        <div class="card">
            <h3>Mis Préstamos</h3>
            <p>Consulta los libros que tienes actualmente en préstamo.</p>
            <a href="PrestamoServlet">Ir a Mis Préstamos</a>
        </div>

        <div class="card">
            <h3>Historial de Préstamos</h3>
            <p>Revisa todos los préstamos que has realizado anteriormente.</p>
            <a href="PrestamoServlet">Ver Historial</a>
        </div>
    </div>
</div>