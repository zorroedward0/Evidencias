package vista;

import modelo.*;
import dao.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

                Scanner sc = new Scanner(System.in);
                boolean salir = false;

                do {
                    System.out.println("===== MENU PRINCIPAL =====");
                    System.out.println("Seleccione la entidad:");
                    System.out.println("1. Autor");
                    System.out.println("2. Categoria");
                    System.out.println("3. Editorial");
                    System.out.println("4. HistorialModificacion");
                    System.out.println("5. Libro");
                    System.out.println("6. LibroAutor");
                    System.out.println("7. LibroCategoria");
                    System.out.println("8. Multa");
                    System.out.println("9. Prestamo");
                    System.out.println("10. TipoUsuario");
                    System.out.println("11. Usuario");
                    System.out.println("12. Salir");
                    System.out.print("Opción: ");
                    int entidad = sc.nextInt();
                    sc.nextLine();

                    if (entidad == 12) {
                        salir = true;
                        System.out.println("Saliendo...");
                        continue;
                    }


                    if (entidad == 4) {
                        System.out.println("Seleccione la acción:");
                        System.out.println("1. Listar");
                        System.out.println("2. Eliminar");
                        System.out.print("Opción: ");
                    } else if (entidad == 6 || entidad == 7) {
                        System.out.println("Seleccione la acción:");
                        System.out.println("1. Listar");
                        System.out.println("2. Insertar");
                        System.out.println("3. Eliminar");
                        System.out.print("Opción: ");
                    }else {
                        System.out.println("Seleccione la acción:");
                        System.out.println("1. Listar");
                        System.out.println("2. Insertar");
                        System.out.println("3. Actualizar");
                        System.out.println("4. Eliminar");
                        System.out.print("Opción: ");
                    }


                    int accion = sc.nextInt();
                    sc.nextLine();

                    switch (entidad) {
                        case 1:
                            AutorDao autorDao = new AutorDao();
                            switch (accion) {
                                case 1:
                                    autorDao.listarAutores().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos autores desea insertar: "); int cant = sc.nextInt(); sc.nextLine();
                                    List<Autor> listaAutores = new ArrayList<>();
                                    for (int i = 0; i < cant; i++) {
                                        System.out.print("Nombre: "); String nombre = sc.nextLine();
                                        System.out.print("Apellido: "); String apellido = sc.nextLine();
                                        System.out.print("Nacionalidad: "); String nacionalidad = sc.nextLine();
                                        System.out.print("Fecha nacimiento (YYYY-MM-DD): "); LocalDate fechaNac = LocalDate.parse(sc.nextLine());
                                        listaAutores.add(new Autor(nombre, apellido, nacionalidad, fechaNac));
                                    }
                                    System.out.println(autorDao.insertarAutores(listaAutores));
                                    break;
                                case 3:
                                    autorDao.listarAutores().forEach(System.out::println);
                                    System.out.print("ID del autor a actualizar: "); int idAutorU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Nombre: "); String nombreU = sc.nextLine();
                                    System.out.print("Apellido: "); String apellidoU = sc.nextLine();
                                    System.out.print("Nacionalidad: "); String nacionalidadU = sc.nextLine();
                                    System.out.print("Fecha nacimiento (YYYY-MM-DD): "); LocalDate fechaNacU = LocalDate.parse(sc.nextLine());
                                    System.out.println(autorDao.actualizarAutor(new Autor(nombreU, apellidoU, nacionalidadU, fechaNacU), idAutorU));
                                    break;
                                case 4:
                                    autorDao.listarAutores().forEach(System.out::println);
                                    System.out.print("ID del autor a eliminar: "); int idAutorE = sc.nextInt(); sc.nextLine();
                                    System.out.println(autorDao.eliminarAutor(idAutorE));
                                    break;
                            }
                            break;

                        case 2:
                            CategoriaDao categoriaDao = new CategoriaDao();
                            switch (accion) {
                                case 1:
                                    categoriaDao.listarCategorias().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántas categorias desea insertar: "); int cantC = sc.nextInt(); sc.nextLine();
                                    List<Categoria> listaCategorias = new ArrayList<>();
                                    for (int i = 0; i < cantC; i++) {
                                        System.out.print("Nombre: "); String nombreCat = sc.nextLine();
                                        System.out.print("Descripción: "); String desc = sc.nextLine();
                                        listaCategorias.add(new Categoria(nombreCat, desc));
                                    }
                                    System.out.println(categoriaDao.insertarCategorias(listaCategorias));
                                    break;
                                case 3:
                                    categoriaDao.listarCategorias().forEach(System.out::println);
                                    System.out.print("ID de la categoria a actualizar: "); int idCatU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Nombre: "); String nombreCatU = sc.nextLine();
                                    System.out.print("Descripción: "); String descU = sc.nextLine();
                                    System.out.println(categoriaDao.actualizarCategoria(new Categoria(nombreCatU, descU), idCatU));
                                    break;
                                case 4:
                                    categoriaDao.listarCategorias().forEach(System.out::println);
                                    System.out.print("ID de la categoria a eliminar: "); int idCatE = sc.nextInt(); sc.nextLine();
                                    System.out.println(categoriaDao.eliminarCategoria(idCatE));
                                    break;
                            }
                            break;

                        case 3:
                            EditorialDao editorialDao = new EditorialDao();
                            switch (accion) {
                                case 1:
                                    editorialDao.listarEditoriales().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántas editoriales desea insertar: "); int cantEd = sc.nextInt(); sc.nextLine();
                                    List<Editorial> listaEditoriales = new ArrayList<>();
                                    for (int i = 0; i < cantEd; i++) {
                                        System.out.print("Nombre: "); String nombreEd = sc.nextLine();
                                        System.out.print("País: "); String pais = sc.nextLine();
                                        System.out.print("Sitio web: "); String web = sc.nextLine();
                                        listaEditoriales.add(new Editorial(nombreEd, pais, web));
                                    }
                                    System.out.println(editorialDao.insertarEditoriales(listaEditoriales));
                                    break;
                                case 3:
                                    editorialDao.listarEditoriales().forEach(System.out::println);
                                    System.out.print("ID de la editorial a actualizar: "); int idEdU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Nombre: "); String nombreEdU = sc.nextLine();
                                    System.out.print("País: "); String paisU = sc.nextLine();
                                    System.out.print("Sitio web: "); String webU = sc.nextLine();
                                    System.out.println(editorialDao.actualizarEditorial(new Editorial(nombreEdU, paisU, webU), idEdU));
                                    break;
                                case 4:
                                    editorialDao.listarEditoriales().forEach(System.out::println);
                                    System.out.print("ID de la editorial a eliminar: "); int idEdE = sc.nextInt(); sc.nextLine();
                                    System.out.println(editorialDao.eliminarEditorial(idEdE));
                                    break;
                            }
                            break;

                        case 4:
                            HistorialModificacionDao historialDao = new HistorialModificacionDao();
                            switch (accion) {
                                case 1:
                                    historialDao.listarHistoriales().forEach(System.out::println);
                                    break;
                                case 2:
                                    historialDao.listarHistoriales().forEach(System.out::println);
                                    System.out.print("ID a eliminar: "); int idHistE = sc.nextInt(); sc.nextLine();
                                    System.out.println(historialDao.eliminarHistorial(idHistE));
                                    break;
                            }
                            break;

                        case 5:
                            LibroDao libroDao = new LibroDao();
                            switch (accion) {
                                case 1:
                                    libroDao.listarLibros().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos libros desea insertar: "); int cantL = sc.nextInt(); sc.nextLine();
                                    List<Libro> listaLibros = new ArrayList<>();
                                    for (int i = 0; i < cantL; i++) {
                                        System.out.print("Título: "); String titulo = sc.nextLine();
                                        System.out.print("ISBN: "); String isbn = sc.nextLine();
                                        System.out.print("Año publicacion (YYYY-MM-DD): "); LocalDate anioPub = LocalDate.parse(sc.nextLine());
                                        System.out.print("Número de páginas: "); int numPag = sc.nextInt(); sc.nextLine();
                                        System.out.print("Disponible (true/false): "); boolean disp = sc.nextBoolean(); sc.nextLine();
                                        System.out.print("ID Editorial: "); int idEd = sc.nextInt(); sc.nextLine();
                                        listaLibros.add(new Libro(titulo, isbn, anioPub, numPag, disp, idEd));
                                    }
                                    System.out.println(libroDao.insertarLibros(listaLibros));
                                    break;
                                case 3:
                                    libroDao.listarLibros().forEach(System.out::println);
                                    System.out.print("ID libro a actualizar: "); int idLibU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Título: "); String tituloU = sc.nextLine();
                                    System.out.print("ISBN: "); String isbnU = sc.nextLine();
                                    System.out.print("Año publicacion (YYYY-MM-DD): "); LocalDate anioPubU = LocalDate.parse(sc.nextLine());
                                    System.out.print("Número de páginas: "); int numPagU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Disponible (true/false): "); boolean dispU = sc.nextBoolean(); sc.nextLine();
                                    System.out.print("ID Editorial: "); int idEdU = sc.nextInt(); sc.nextLine();
                                    System.out.println(libroDao.actualizarLibro(new Libro(tituloU, isbnU, anioPubU, numPagU, dispU, idEdU), idLibU));
                                    break;
                                case 4:
                                    libroDao.listarLibros().forEach(System.out::println);
                                    System.out.print("ID libro a eliminar: "); int idLibE = sc.nextInt(); sc.nextLine();
                                    System.out.println(libroDao.eliminarLibro(idLibE));
                                    break;
                            }
                            break;

                        case 6:
                            LibroAutorDao libroAutorDao = new LibroAutorDao();
                            switch (accion) {
                                case 1:
                                    libroAutorDao.listarLibroAutores().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos registros desea insertar: "); int cantLA = sc.nextInt(); sc.nextLine();
                                    List<LibroAutor> listaLibAut = new ArrayList<>();
                                    for (int i = 0; i < cantLA; i++) {
                                        System.out.print("ID Autor: "); int idAut = sc.nextInt(); sc.nextLine();
                                        System.out.print("ID Libro: "); int idLib = sc.nextInt(); sc.nextLine();
                                        listaLibAut.add(new LibroAutor(idAut, idLib));
                                    }
                                    System.out.println(libroAutorDao.insertarLibroAutores(listaLibAut));
                                    break;
                                case 3:
                                    libroAutorDao.listarLibroAutores().forEach(System.out::println);
                                    System.out.print("ID Autor a eliminar: "); int idAutE = sc.nextInt(); sc.nextLine();
                                    System.out.print("ID Libro a eliminar: "); int idLibE2 = sc.nextInt(); sc.nextLine();
                                    System.out.println(libroAutorDao.eliminarLibroAutor(idAutE, idLibE2));
                                    break;
                            }
                            break;

                        case 7:
                            LibroCategoriaDao libroCatDao = new LibroCategoriaDao();
                            switch (accion) {
                                case 1:
                                    libroCatDao.listarLibroCategorias().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos registros desea insertar: "); int cantLC = sc.nextInt(); sc.nextLine();
                                    List<LibroCategoria> listaLibCat = new ArrayList<>();
                                    for (int i = 0; i < cantLC; i++) {
                                        System.out.print("ID Categoria: "); int idCat = sc.nextInt(); sc.nextLine();
                                        System.out.print("ID Libro: "); int idLib2 = sc.nextInt(); sc.nextLine();
                                        listaLibCat.add(new LibroCategoria(idCat, idLib2));
                                    }
                                    System.out.println(libroCatDao.insertarLibroCategorias(listaLibCat));
                                    break;
                                case 3:
                                    libroCatDao.listarLibroCategorias().forEach(System.out::println);
                                    System.out.print("ID Categoria a eliminar: "); int idCatE2 = sc.nextInt(); sc.nextLine();
                                    System.out.print("ID Libro a eliminar: "); int idLibE3 = sc.nextInt(); sc.nextLine();
                                    System.out.println(libroCatDao.eliminarLibroCategoria(idCatE2, idLibE3));
                                    break;
                            }
                            break;

                        case 8:
                            MultaDao multaDao = new MultaDao();
                            switch (accion) {
                                case 1:
                                    multaDao.listarMultas().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántas multas desea insertar: "); int cantM = sc.nextInt(); sc.nextLine();
                                    List<Multa> listaMultas = new ArrayList<>();
                                    for (int i = 0; i < cantM; i++) {
                                        System.out.print("Monto: "); double monto = sc.nextDouble(); sc.nextLine();
                                        System.out.print("Fecha Pago (YYYY-MM-DD): "); LocalDate fechaPago = LocalDate.parse(sc.nextLine());
                                        System.out.print("Estado (true/false): "); boolean estado = sc.nextBoolean(); sc.nextLine();
                                        System.out.print("ID Prestamo: "); int idPrestamo = sc.nextInt(); sc.nextLine();
                                        listaMultas.add(new Multa(monto, fechaPago, estado, idPrestamo));
                                    }
                                    System.out.println(multaDao.insertarMultas(listaMultas));
                                    break;
                                case 3:
                                    multaDao.listarMultas().forEach(System.out::println);
                                    System.out.print("ID Multa a actualizar: "); int idMultaU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Monto: "); double montoU = sc.nextDouble(); sc.nextLine();
                                    System.out.print("Fecha Pago (YYYY-MM-DD): "); LocalDate fechaPagoU = LocalDate.parse(sc.nextLine());
                                    System.out.print("Estado (true/false): "); boolean estadoU = sc.nextBoolean(); sc.nextLine();
                                    System.out.print("ID Prestamo: "); int idPrestamoU = sc.nextInt(); sc.nextLine();
                                    System.out.println(multaDao.actualizarMulta(new Multa(montoU, fechaPagoU, estadoU, idPrestamoU), idMultaU));
                                    break;
                                case 4:
                                    multaDao.listarMultas().forEach(System.out::println);
                                    System.out.print("ID Multa a eliminar: "); int idMultaE = sc.nextInt(); sc.nextLine();
                                    System.out.println(multaDao.eliminarMulta(idMultaE));
                                    break;
                            }
                            break;

                        case 9:
                            PrestamoDao prestamoDao = new PrestamoDao();
                            switch (accion) {
                                case 1:
                                    prestamoDao.listarPrestamos().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos prestamos desea insertar: "); int cantP = sc.nextInt(); sc.nextLine();
                                    List<Prestamo> listaPrestamos = new ArrayList<>();
                                    for (int i = 0; i < cantP; i++) {
                                        System.out.print("Fecha prestamo (YYYY-MM-DD): "); LocalDate fechaPrest = LocalDate.parse(sc.nextLine());
                                        System.out.print("Fecha devolucion esperada (YYYY-MM-DD): "); LocalDate fechaDevEsp = LocalDate.parse(sc.nextLine());
                                        System.out.print("ID Libro: "); int idLibroP = sc.nextInt(); sc.nextLine();
                                        System.out.print("ID Usuario: "); int idUsuarioP = sc.nextInt(); sc.nextLine();
                                        listaPrestamos.add(new Prestamo(fechaPrest, fechaDevEsp, idLibroP, idUsuarioP));
                                    }
                                    System.out.println(prestamoDao.insertarPrestamos(listaPrestamos));
                                    break;
                                case 3:
                                    prestamoDao.listarPrestamos().forEach(System.out::println);
                                    System.out.print("ID Prestamo a actualizar: "); int idPrestU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Fecha prestamo (YYYY-MM-DD): "); LocalDate fechaPrestU = LocalDate.parse(sc.nextLine());
                                    System.out.print("Fecha devolucion esperada (YYYY-MM-DD): "); LocalDate fechaDevEspU = LocalDate.parse(sc.nextLine());
                                    System.out.print("Fecha devolucion real (YYYY-MM-DD) o vacío: "); String fechaDevRealStr = sc.nextLine();
                                    LocalDate fechaDevRealU = fechaDevRealStr.isEmpty() ? null : LocalDate.parse(fechaDevRealStr);
                                    System.out.print("Estado (true/false): "); boolean estadoU2 = sc.nextBoolean(); sc.nextLine();
                                    System.out.print("ID Libro: "); int idLibroU = sc.nextInt(); sc.nextLine();
                                    System.out.print("ID Usuario: "); int idUsuarioU = sc.nextInt(); sc.nextLine();
                                    System.out.println(prestamoDao.actualizarPrestamo(new Prestamo(fechaPrestU, fechaDevEspU, idLibroU, idUsuarioU), idPrestU));
                                    break;
                                case 4:
                                    prestamoDao.listarPrestamos().forEach(System.out::println);
                                    System.out.print("ID Prestamo a eliminar: "); int idPrestE = sc.nextInt(); sc.nextLine();
                                    System.out.println(prestamoDao.eliminarPrestamo(idPrestE));
                                    break;
                            }
                            break;

                        case 10:
                            TipoUsuarioDao tipoDao = new TipoUsuarioDao();
                            switch (accion) {
                                case 1:
                                    tipoDao.listarTiposUsuario().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos tipos desea insertar: "); int cantT = sc.nextInt(); sc.nextLine();
                                    List<TipoUsuario> listaTipos = new ArrayList<>();
                                    for (int i = 0; i < cantT; i++) {
                                        System.out.print("Nombre: "); String nombreTipo = sc.nextLine();
                                        listaTipos.add(new TipoUsuario(nombreTipo));
                                    }
                                    System.out.println(tipoDao.insertarTiposUsuario(listaTipos));
                                    break;
                                case 3:
                                    tipoDao.listarTiposUsuario().forEach(System.out::println);
                                    System.out.print("ID TipoUsuario a actualizar: "); int idTipoU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Nombre: "); String nombreTipoU = sc.nextLine();
                                    System.out.println(tipoDao.actualizarTipoUsuario(new TipoUsuario(nombreTipoU), idTipoU));
                                    break;
                                case 4:
                                    tipoDao.listarTiposUsuario().forEach(System.out::println);
                                    System.out.print("ID TipoUsuario a eliminar: "); int idTipoE = sc.nextInt(); sc.nextLine();
                                    System.out.println(tipoDao.eliminarTipoUsuario(idTipoE));
                                    break;
                            }
                            break;

                        case 11:
                            UsuarioDao usuarioDao = new UsuarioDao();
                            switch (accion) {
                                case 1:
                                    usuarioDao.listarUsuarios().forEach(System.out::println);
                                    break;
                                case 2:
                                    System.out.print("Cuántos usuarios desea insertar: "); int cantU = sc.nextInt(); sc.nextLine();
                                    List<Usuario> listaUsuarios = new ArrayList<>();
                                    for (int i = 0; i < cantU; i++) {
                                        System.out.print("Documento: "); String doc = sc.nextLine();
                                        System.out.print("Nombre: "); String nom = sc.nextLine();
                                        System.out.print("Apellido: "); String ape = sc.nextLine();
                                        System.out.print("Email: "); String email = sc.nextLine();
                                        System.out.print("Teléfono: "); String tel = sc.nextLine();
                                        System.out.print("ID TipoUsuario: "); int idTipo = sc.nextInt(); sc.nextLine();
                                        listaUsuarios.add(new Usuario(doc, nom, ape, email, tel, idTipo));
                                    }
                                    System.out.println(usuarioDao.insertarUsuarios(listaUsuarios));
                                    break;
                                case 3:
                                    usuarioDao.listarUsuarios().forEach(System.out::println);
                                    System.out.print("ID Usuario a actualizar: "); int idUserU = sc.nextInt(); sc.nextLine();
                                    System.out.print("Documento: "); String docU = sc.nextLine();
                                    System.out.print("Nombre: "); String nomU = sc.nextLine();
                                    System.out.print("Apellido: "); String apeU = sc.nextLine();
                                    System.out.print("Email: "); String emailU = sc.nextLine();
                                    System.out.print("Teléfono: "); String telU = sc.nextLine();
                                    System.out.print("ID TipoUsuario: "); int idTipoU2 = sc.nextInt(); sc.nextLine();
                                    System.out.println(usuarioDao.actualizarUsuario(new Usuario(docU, nomU, apeU, emailU, telU, idTipoU2), idUserU));
                                    break;
                                case 4:
                                    usuarioDao.listarUsuarios().forEach(System.out::println);
                                    System.out.print("ID Usuario a eliminar: "); int idUserE = sc.nextInt(); sc.nextLine();
                                    System.out.println(usuarioDao.eliminarUsuario(idUserE));
                                    break;
                            }
                            break;
                    }
                } while (!salir);
            }
        }

