package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionDb {
    private static final String URL = "jdbc:mysql://localhost:3306/dbbiblioteca";
    private static final String USER = "root";
    private static final String PASSWORD = "SpringEduar123";

    public static Connection establecerConexion() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

}

