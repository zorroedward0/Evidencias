package modelo;
import java.time.LocalDate;


public class Autor {
    private final Integer idAutor;
    private String apellido;
    private String nombre;
    private String nacionalidad;
    private final LocalDate fechaNacimiento;

    public Autor(Integer idAutor,String nombre,String apellido,String nacionalidad, LocalDate fechaNacimieto){
        this.idAutor = idAutor;
        this.nombre = nombre;
        this.apellido = apellido;
        this.nacionalidad = nacionalidad;
        this.fechaNacimiento = fechaNacimieto;
    }

    public Autor(String nombre,String apellido,String nacionalidad, LocalDate fechaNacimieto){
        this(null,nombre,apellido,nacionalidad,fechaNacimieto);
    }

    public Integer getIdAutor() {
        return idAutor;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    @Override
    public String toString() {
        return "Autor{" +
                "idAutor=" + idAutor +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", nacionalidad='" + nacionalidad + '\'' +
                ", fechaNacimiento=" + fechaNacimiento +
                '}';
    }
}
