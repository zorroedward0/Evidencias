package modelo;

public class Usuario {
    private final Integer idUsuario;
    private String documento;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private boolean estado;
    private final Integer idTipoUsuario;

    public Usuario(Integer idUsuario,String documento,String nombre,String apellido,String email,String telefono,boolean estado,Integer idTipoUsuario) {
        this.idUsuario = idUsuario;
        this.documento = documento;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.telefono = telefono;
        this.estado = estado;
        this.idTipoUsuario = idTipoUsuario;
    }

    public Usuario(String documento,String nombre,String apellido,String email,String telefono,Integer idTipoUsuario){
        this(null,documento,nombre,apellido,email,telefono,true,idTipoUsuario);
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Integer getIdTipoUsuario() {
        return idTipoUsuario;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "idUsuario=" + idUsuario +
                ", documento='" + documento + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", email='" + email + '\'' +
                ", telefono='" + telefono + '\'' +
                ", estado=" + estado +
                ", idTipoUsuario=" + idTipoUsuario +
                '}';
    }
}
