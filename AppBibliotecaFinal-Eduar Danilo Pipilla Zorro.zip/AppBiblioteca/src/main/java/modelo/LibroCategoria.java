package modelo;

import java.util.Objects;

public class LibroCategoria {
    private final Integer idLibro;
    private final Integer idCategoria;

    public LibroCategoria(Integer idCategoria,Integer idLibro){
        this.idCategoria = idCategoria;
        this.idLibro = idLibro;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public Integer getIdLibro() {
        return idLibro;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LibroCategoria that = (LibroCategoria) o;
        return Objects.equals(idCategoria, that.idCategoria) && Objects.equals(idLibro, that.idLibro);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idCategoria, idLibro);
    }

    @Override
    public String toString() {
        return "LibroCategoria{" +
                "idCategoria=" + idCategoria +
                ", idLibro=" + idLibro +
                '}';
    }
}
