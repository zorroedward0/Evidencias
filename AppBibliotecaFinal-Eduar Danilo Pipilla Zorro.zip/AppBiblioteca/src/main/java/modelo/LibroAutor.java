package modelo;

import java.util.Objects;

public class LibroAutor {
    private final Integer idAutor;
    private final Integer idLibro;

    public LibroAutor(Integer idAutor,Integer idLibro){
        this.idAutor = idAutor;
        this.idLibro = idLibro;
    }

    public Integer getIdAutor() {
        return idAutor;
    }

    public Integer getIdLibro() {
        return idLibro;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LibroAutor that = (LibroAutor) o;
        return Objects.equals(idAutor, that.idAutor) && Objects.equals(idLibro, that.idLibro);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idAutor, idLibro);
    }

    @Override
    public String toString() {
        return "LibroAutor{" +
                "idAutor=" + idAutor +
                ", idLibro=" + idLibro +
                '}';
    }
}

