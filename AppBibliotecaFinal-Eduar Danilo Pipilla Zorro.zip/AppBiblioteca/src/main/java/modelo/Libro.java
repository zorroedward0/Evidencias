package modelo;
import java.time.LocalDate;


public class Libro {
    private final Integer idLibro;
    private String titulo;
    private String isbn;
    private LocalDate anioPublicacion;
    private int numPag;
    private boolean disponible;
    private Integer idEditorial;

    public Libro(Integer idLibro,String titulo,String isbn,LocalDate anioPublicacion,int numPag,boolean disponible,Integer idEditorial) {
        this.idLibro = idLibro;
        this.titulo = titulo;
        this.isbn = isbn;
        this.anioPublicacion = anioPublicacion;
        this.numPag = numPag;
        this.disponible = disponible;
        this.idEditorial = idEditorial;
    }

    public Libro(String titulo,String isbn,LocalDate anioPublicacion,int numPag,boolean disponible,Integer idEditorial) {
        this(null,titulo,isbn,anioPublicacion,numPag,disponible,idEditorial);
    }

    public Integer getIdLibro() {
        return idLibro;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public LocalDate getAnioPublicacion() {
        return anioPublicacion;
    }

    public void setAnioPublicacion(LocalDate anioPublicacion) {
        this.anioPublicacion = anioPublicacion;
    }

    public int getNumPag() {
        return numPag;
    }

    public void setNumPag(int numPag) {
        this.numPag = numPag;
    }

    public Integer getIdEditorial() {
        return idEditorial;
    }

    public void setIdEditorial(Integer idEditorial) {
        this.idEditorial = idEditorial;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }
    @Override
    public String toString() {
        return "Libro{" +
                "idLibro=" + idLibro +
                ", titulo='" + titulo + '\'' +
                ", isbn='" + isbn + '\'' +
                ", anioPublicacion=" + anioPublicacion +
                ", numPag=" + numPag +
                ", disponible=" + disponible +
                ", idEditorial=" + idEditorial +
                '}';
    }
}
