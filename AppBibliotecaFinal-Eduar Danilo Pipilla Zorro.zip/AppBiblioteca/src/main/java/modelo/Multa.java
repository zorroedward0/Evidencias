package modelo;

import java.time.LocalDate;

public class Multa {
    private final Integer idMulta;
    private Double monto;
    private final LocalDate fechaGeneracion;
    private LocalDate fechaPago;
    private boolean estado;
    private final Integer idPrestamo;

    public Multa(Integer idMulta, Double monto, LocalDate fechaGeneracion, LocalDate fechaPago, boolean estado, Integer idPrestamo) {
        this.idMulta = idMulta;
        this.monto = monto;
        this.fechaGeneracion = fechaGeneracion;
        this.fechaPago = fechaPago;
        this.estado = estado;
        this.idPrestamo = idPrestamo;
    }
    public Multa( Double monto, LocalDate fechaPago, boolean estado, Integer idPrestamo) {
        this(null,monto,LocalDate.now(),fechaPago,estado,idPrestamo);
    }

    public Integer getIdMulta() {
        return idMulta;
    }

    public Double getMonto() {
        return monto;
    }

    public void setMonto(Double monto) {
        this.monto = monto;
    }

    public LocalDate getFechaGeneracion() {
        return fechaGeneracion;
    }

    public LocalDate getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(LocalDate fechaPago) {
        this.fechaPago = fechaPago;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public Integer getIdPrestamo() {
        return idPrestamo;
    }

    @Override
    public String toString() {
        return "Multa{" +
                "idMulta=" + idMulta +
                ", monto=" + monto +
                ", fechaGeneracion=" + fechaGeneracion +
                ", fechaPago=" + fechaPago +
                ", estado=" + estado +
                ", idPrestamo=" + idPrestamo +
                '}';
    }

}
