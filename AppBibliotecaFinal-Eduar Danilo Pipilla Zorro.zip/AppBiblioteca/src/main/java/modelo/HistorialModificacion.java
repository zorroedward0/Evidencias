package modelo;

public class HistorialModificacion {
    private final Integer idHistorialModificacion;
    private final String registro;
    public HistorialModificacion(Integer idHistorialModificacion,String registro){
        this.idHistorialModificacion = idHistorialModificacion;
        this.registro = registro;
    }public HistorialModificacion(String registro){
        this(null,registro);
    }

    public Integer getIdHistorialModificacion() {
        return idHistorialModificacion;
    }

    public String getRegistro() {
        return registro;
    }
    @Override
    public String toString() {
        return "HistorialModificacion{" +
                "idHistorialModificacion=" + idHistorialModificacion +
                ", registro='" + registro + '\'' +
                '}';
    }
}
