package dao;

import config.ConexionDb;
import modelo.Prestamo;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PrestamoDao {

    public List<Prestamo> listarPrestamos() {
        List<Prestamo> prestamos = new ArrayList<>();
        String sql = "SELECT idPrestamo, fechaPrestamo, fechaDevolucionEsperada, fechaDevolucionReal, estado, idLibro, idUsuario FROM prestamo";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                prestamos.add(new Prestamo(
                        rs.getObject("idPrestamo", Integer.class),
                        rs.getObject("fechaPrestamo", LocalDate.class),
                        rs.getObject("fechaDevolucionEsperada", LocalDate.class),
                        rs.getObject("fechaDevolucionReal", LocalDate.class),
                        rs.getBoolean("estado"),
                        rs.getObject("idLibro", Integer.class),
                        rs.getObject("idUsuario", Integer.class)));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar prestamos ", e);
        }
        return prestamos;
    }

    public String insertarPrestamos(List<Prestamo> prestamos) {
        if (prestamos == null || prestamos.isEmpty()) return "No se ha encontrado prestamos para insertar.";
        String sql = "INSERT INTO prestamo (fechaPrestamo, fechaDevolucionEsperada, fechaDevolucionReal, estado, idLibro, idUsuario) values (?,?,?,?,?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (Prestamo prestamo : prestamos) {
                ps.setObject(1, prestamo.getFechaPrestamo());
                ps.setObject(2, prestamo.getFechaDevolucionEsperada());
                ps.setObject(3, Date.valueOf(LocalDate.now()));
                ps.setBoolean(4, true);
                ps.setObject(5, prestamo.getIdLibro());
                ps.setObject(6, prestamo.getIdUsuario());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " prestamos.";
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al insertar prestamos ", e);
            }
        }
        return mensaje;
    }

    public String actualizarPrestamo(Prestamo prestamo, Integer idPrestamoI) {

        if (prestamo == null || idPrestamoI == null) return "No has ingresado informacion suficiente para actualizar un prestamo.";
        String sql = " UPDATE prestamo SET fechaDevolucionEsperada = ?, fechaDevolucionReal = ?, estado = ? WHERE idPrestamo = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setObject(1, prestamo.getFechaDevolucionEsperada());
            ps.setObject(2, prestamo.getFechaDevolucionReal());
            ps.setBoolean(3, prestamo.isEstado());
            ps.setInt(4, idPrestamoI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado el prestamo correctamente.";
            } else mensaje = "No se ha podido actualizar el prestamo.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar el prestamo ", e);
        }
        return mensaje;
    }
    public String eliminarPrestamo(Integer idPrestamoI) {

        if (idPrestamoI == null) return "No has ingresado el id del prestamo para eliminar su informacion.";
        String sql = " DELETE FROM prestamo WHERE idPrestamo = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idPrestamoI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el prestamo con el id " + idPrestamoI + " correctamente.";
            } else mensaje = "No se ha podido eliminar el prestamo.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el prestamo ", e);
        }
        return mensaje;
    }
}