package dao;

import config.ConexionDb;
import modelo.HistorialModificacion;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HistorialModificacionDao {

    public List<HistorialModificacion> listarHistoriales() {
        List<HistorialModificacion> historiales = new ArrayList<>();
        String sql = "SELECT idHistorialModificacion, registro FROM historialmodificacion";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                historiales.add(new HistorialModificacion(
                        rs.getObject("idHistorialModificacion", Integer.class),
                        rs.getString("registro")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar historiales ", e);
        }
        return historiales;
    }

    public String eliminarHistorial(Integer idHistorialI) {

        if (idHistorialI == null) return "No has ingresado el id del historial para eliminar su informacion.";
        String sql = " DELETE FROM historialmodificacion WHERE idHistorialModificacion = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idHistorialI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el historial con el id " + idHistorialI + " correctamente.";
            } else mensaje = "No se ha podido eliminar el historial.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el historial ", e);
        }
        return mensaje;
    }
}

