package dao;

import config.ConexionDb;
import modelo.LibroAutor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroAutorDao {

    public List<LibroAutor> listarLibroAutores() {
        List<LibroAutor> libroAutores = new ArrayList<>();
        String sql = "SELECT idAutor, idLibro FROM libroautor";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                libroAutores.add(new LibroAutor(
                        rs.getObject("idAutor", Integer.class),
                        rs.getObject("idLibro", Integer.class)));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar libroAutores ", e);
        }
        return libroAutores;
    }

    public String insertarLibroAutores(List<LibroAutor> libroAutores) {
        if (libroAutores == null || libroAutores.isEmpty()) return "No se ha encontrado libroAutores para insertar.";
        String sql = "INSERT INTO libroautor (idAutor, idLibro) values (?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (LibroAutor libroAutor : libroAutores) {
                ps.setObject(1, libroAutor.getIdAutor());
                ps.setObject(2, libroAutor.getIdLibro());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " libroAutores.";
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al insertar libroAutores ", e);
            }
        }
        return mensaje;
    }

    public String eliminarLibroAutor(Integer idAutorI, Integer idLibroI) {

        if (idAutorI == null || idLibroI == null)
            return "No has ingresado el idAutor o idLibro para eliminar su informacion.";
        String sql = " DELETE FROM libroautor WHERE idAutor = ? AND idLibro = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setObject(1, idAutorI);
            ps.setObject(2, idLibroI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el libroAutor correctamente.";
            } else mensaje = "No se ha podido eliminar el libroAutor.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el libroAutor ", e);
        }
        return mensaje;
    }
}