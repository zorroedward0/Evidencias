package dao;

import config.ConexionDb;
import modelo.LibroCategoria;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LibroCategoriaDao {

    public List<LibroCategoria> listarLibroCategorias() {
        List<LibroCategoria> libroCategorias = new ArrayList<>();
        String sql = "SELECT idCategoria, idLibro FROM librocategoria";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                libroCategorias.add(new LibroCategoria(
                        rs.getObject("idCategoria", Integer.class),
                        rs.getObject("idLibro", Integer.class)));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar libroCategorias ", e);
        }
        return libroCategorias;
    }

    public String insertarLibroCategorias(List<LibroCategoria> libroCategorias) {
        if (libroCategorias == null || libroCategorias.isEmpty()) return "No se ha encontrado libroCategorias para insertar.";
        String sql = "INSERT INTO librocategoria (idCategoria, idLibro) values (?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (LibroCategoria libroCategoria : libroCategorias) {
                ps.setObject(1, libroCategoria.getIdCategoria());
                ps.setObject(2, libroCategoria.getIdLibro());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " libroCategorias.";
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al insertar libroCategorias ", e);
            }
        }
        return mensaje;
    }

    public String eliminarLibroCategoria(Integer idCategoriaI, Integer idLibroI) {

        if (idCategoriaI == null || idLibroI == null)
            return "No has ingresado el idCategoria o idLibro para eliminar su informacion.";
        String sql = " DELETE FROM librocategoria WHERE idCategoria = ? AND idLibro = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setObject(1, idCategoriaI);
            ps.setObject(2, idLibroI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el libroCategoria correctamente.";
            } else mensaje = "No se ha podido eliminar el libroCategoria.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el libroCategoria ", e);
        }
        return mensaje;
    }
}