package dao;

import config.ConexionDb;
import modelo.Editorial;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EditorialDao {
    public List<Editorial> listarEditoriales() {
        List<Editorial> editoriales = new ArrayList<>();
        String sql = "SELECT ideditorial, nombre, pais, sitioWeb FROM editorial";
        try (Connection con = ConexionDb.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                editoriales.add(new Editorial(
                        rs.getObject("ideditorial", Integer.class),
                        rs.getString("nombre"),
                        rs.getString("pais"),
                        rs.getString("sitioWeb")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar editoriales ", e);
        }
        return editoriales;
    }

    public String insertarEditoriales(List<Editorial> editoriales) {
        if (editoriales == null || editoriales.isEmpty())
            return "No se han encontrado editoriales para insertar.";

        String sql = "INSERT INTO editorial (nombre, pais, sitioWeb) VALUES (?, ?, ?)";
        String mensaje;
        try (Connection con = ConexionDb.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            for (Editorial editorial : editoriales) {
                ps.setString(1, editorial.getNombre());
                ps.setString(2, editorial.getPais());
                ps.setString(3, editorial.getSitioWeb());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();
            int total = 0;
            for (int r : resultados) {
                if (r >= 0) total++;
            }
            mensaje = "Se han insertado " + total + " editoriales.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar editoriales ", e);
        }
        return mensaje;
    }

    public String actualizarEditorial(Editorial editorial, Integer idEditorialI) {
        if (editorial == null || idEditorialI == null)
            return "No has ingresado información suficiente para actualizar una editorial.";

        String sql = "UPDATE editorial SET nombre = ?, pais = ?, sitioWeb = ? WHERE ideditorial = ?";
        String mensaje;
        try (Connection con = ConexionDb.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, editorial.getNombre());
            ps.setString(2, editorial.getPais());
            ps.setString(3, editorial.getSitioWeb());
            ps.setInt(4, idEditorialI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado la editorial " + editorial.getNombre() + " correctamente.";
            } else {
                mensaje = "No se ha podido actualizar la editorial.";
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar la editorial ", e);
        }
        return mensaje;
    }

    public String eliminarEditorial(Integer idEditorialI) {
        if (idEditorialI == null)
            return "No has ingresado el id de la editorial para eliminar su información.";

        String sql = "DELETE FROM editorial WHERE ideditorial = ?";
        String mensaje;
        try (Connection con = ConexionDb.establecerConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idEditorialI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado la editorial con el id " + idEditorialI + " correctamente.";
            } else {
                mensaje = "No se ha podido eliminar la editorial.";
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar la editorial ", e);
        }
        return mensaje;
    }
}

