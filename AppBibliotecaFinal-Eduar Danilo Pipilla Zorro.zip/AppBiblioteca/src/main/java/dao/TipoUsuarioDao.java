package dao;

import config.ConexionDb;
import modelo.TipoUsuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoUsuarioDao {

    public List<TipoUsuario> listarTiposUsuario() {
        List<TipoUsuario> tiposUsuario = new ArrayList<>();
        String sql = "SELECT idTipoUsuario, nombre FROM tipousuario";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                tiposUsuario.add(new TipoUsuario(
                        rs.getObject("idTipoUsuario", Integer.class),
                        rs.getString("nombre")));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar tiposUsuario ", e);
        }
        return tiposUsuario;
    }

    public String insertarTiposUsuario(List<TipoUsuario> tiposUsuario) {
        if (tiposUsuario == null || tiposUsuario.isEmpty()) return "No se ha encontrado tiposUsuario para insertar.";
        String sql = "INSERT INTO tipousuario (nombre) values (?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (TipoUsuario tipoUsuario : tiposUsuario) {
                ps.setString(1, tipoUsuario.getNombre());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " tiposUsuario.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar tiposUsuario ", e);
        }
        return mensaje;
    }

    public String actualizarTipoUsuario(TipoUsuario tipoUsuario, Integer idTipoUsuarioI) {

        if (tipoUsuario == null || idTipoUsuarioI == null) return "No has ingresado informacion suficiente para actualizar un tipoUsuario.";
        String sql = " UPDATE tipousuario SET nombre = ? WHERE idTipoUsuario = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, tipoUsuario.getNombre());
            ps.setInt(2, idTipoUsuarioI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado el tipoUsuario correctamente.";
            } else mensaje = "No se ha podido actualizar el tipoUsuario.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar el tipoUsuario ", e);
        }
        return mensaje;
    }
    public String eliminarTipoUsuario(Integer idTipoUsuarioI) {

        if (idTipoUsuarioI == null) return "No has ingresado el id del tipoUsuario para eliminar su informacion.";
        String sql = " DELETE FROM tipousuario WHERE idTipoUsuario = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idTipoUsuarioI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el tipoUsuario con el id " + idTipoUsuarioI + " correctamente.";
            } else mensaje = "No se ha podido eliminar el tipoUsuario.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el tipoUsuario ", e);
        }
        return mensaje;
    }
}