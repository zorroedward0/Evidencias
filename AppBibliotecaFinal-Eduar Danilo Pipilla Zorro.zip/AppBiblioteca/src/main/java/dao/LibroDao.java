package dao;

import config.ConexionDb;
import modelo.Libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class LibroDao {

    public List<Libro> listarLibros() {
        List<Libro> libros = new ArrayList<>();
        String sql = "SELECT idLibro, titulo, isbn, añoPublicacion, numPag, disponible, idEditorial FROM libro";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                libros.add(new Libro(
                        rs.getObject("idLibro", Integer.class),
                        rs.getString("titulo"),
                        rs.getString("isbn"),
                        rs.getObject("anioPublicacion", LocalDate.class),
                        rs.getInt("numPag"),
                        rs.getBoolean("disponible"),
                        rs.getObject("idEditorial", Integer.class)));
            }
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al listar libros ", e);
            }
        }
        return libros;
    }

    public String insertarLibros(List<Libro> libros) {
        if (libros == null || libros.isEmpty()) return "No se ha encontrado libros para insertar.";
        String sql = "INSERT INTO libro (titulo, isbn, añoPublicacion, numPag, disponible, idEditorial) values (?,?,?,?,?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (Libro libro : libros) {
                ps.setString(1, libro.getTitulo());
                ps.setString(2, libro.getIsbn());
                ps.setObject(3, libro.getAnioPublicacion());
                ps.setInt(4, libro.getNumPag());
                ps.setBoolean(5, libro.isDisponible());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " libros.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar libros ", e);
        }
        return mensaje;
    }

    public String actualizarLibro(Libro libro, Integer idLibroI) {

        if (libro == null || idLibroI == null) return "No has ingresado informacion suficiente para actualizar un libro.";
        String sql = " UPDATE libro SET titulo = ?, isbn = ?, añoPublicacion = ?, numPag = ?, disponible = ? WHERE idLibro = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getIsbn());
            ps.setObject(3, libro.getAnioPublicacion());
            ps.setInt(4, libro.getNumPag());
            ps.setBoolean(5, libro.isDisponible());
            ps.setInt(6, idLibroI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado el libro " + libro.getTitulo() + " correctamente.";
            } else mensaje = "No se ha podido actualizar el libro.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar el libro ", e);
        }
        return mensaje;
    }
    public String eliminarLibro(Integer idLibroI) {

        if (idLibroI == null) return "No has ingresado el id del libro para eliminar su informacion.";
        String sql = " DELETE FROM libro WHERE idLibro = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idLibroI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el libro con el id " + idLibroI + " correctamente.";
            } else mensaje = "No se ha podido eliminar el libro.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el libro ", e);
        }
        return mensaje;
    }
}