package dao;

import config.ConexionDb;
import modelo.Multa;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MultaDao {

    public List<Multa> listarMultas() {
        List<Multa> multas = new ArrayList<>();
        String sql = "SELECT idMulta, monto, fechaGeneracion, fechaPago, estado, idPrestamo FROM multa";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                multas.add(new Multa(
                        rs.getObject("idMulta", Integer.class),
                        rs.getObject("monto", Double.class),
                        rs.getObject("fechaGeneracion", LocalDate.class),
                        rs.getObject("fechaPago", LocalDate.class),
                        rs.getBoolean("estado"),
                        rs.getObject("idPrestamo", Integer.class)));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar multas ", e);
        }
        return multas;
    }

    public String insertarMultas(List<Multa> multas) {
        if (multas == null || multas.isEmpty()) return "No se ha encontrado multas para insertar.";
        String sql = "INSERT INTO multa (monto,fechaGeneracion, fechaPago, estado, idPrestamo) values (?,?,?,?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (Multa multa : multas) {
                ps.setObject(1, multa.getMonto());
                ps.setObject(2, multa.getFechaGeneracion());
                ps.setDate(3, Date.valueOf(LocalDate.now()));
                ps.setBoolean(4, true);
                ps.setObject(5, multa.getIdPrestamo());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " multas.";
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                throw new RuntimeException("Error: El registro padre no existe (FK inexistente).");
            } else {
                throw new RuntimeException("Error al insertar multas ", e);
            }
        }
        return mensaje;
    }

    public String actualizarMulta(Multa multa, Integer idMultaI) {

        if (multa == null || idMultaI == null) return "No has ingresado informacion suficiente para actualizar una multa.";
        String sql = " UPDATE multa SET monto = ?, fechaPago = ?, estado = ? WHERE idMulta = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setObject(1, multa.getMonto());
            ps.setObject(2, multa.getFechaPago());
            ps.setBoolean(3, multa.isEstado());
            ps.setInt(4, idMultaI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado la multa correctamente.";
            } else mensaje = "No se ha podido actualizar la multa.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar la multa ", e);
        }
        return mensaje;
    }
    public String eliminarMulta(Integer idMultaI) {

        if (idMultaI == null) return "No has ingresado el id de la multa para eliminar su informacion.";
        String sql = " DELETE FROM multa WHERE idMulta = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idMultaI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado la multa con el id " + idMultaI + " correctamente.";
            } else mensaje = "No se ha podido eliminar la multa.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar la multa ", e);
        }
        return mensaje;
    }
}