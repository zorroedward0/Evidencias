package dao;

import config.ConexionDb;
import modelo.Autor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AutorDao {

    public List<Autor> listarAutores() {
        List<Autor> autores = new ArrayList<>();
        String sql = "SELECT idautor,nombre,apellido,nacionalidad,fechaNacimiento FROM autor";

        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                autores.add(new Autor(
                        rs.getObject("idautor", Integer.class),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("nacionalidad"),
                        rs.getObject("fechaNacimiento", LocalDate.class)));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar autores ", e);
        }
        return autores;
    }

    public String insertarAutores(List<Autor> autores) {
        if (autores == null || autores.isEmpty()) return "No se ha encontrado autores para insertar.";
        String sql = "INSERT INTO autor (nombre,apellido,nacionalidad,fechaNacimiento) values (?,?,?,?)";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {
            for (Autor autor : autores) {
                ps.setString(1, autor.getNombre());
                ps.setString(2, autor.getApellido());
                ps.setString(3, autor.getNacionalidad());
                ps.setObject(4, autor.getFechaNacimiento());
                ps.addBatch();
            }
            int[] resultados = ps.executeBatch();

            int total = 0;

            for (int r : resultados) {
                if (r >= 0) {
                    total++;
                }
            }
            mensaje = "Se han insertado " + total + " autores.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al insertar autores ", e);
        }
        return mensaje;
    }

    public String actualizarAutor(Autor autor, Integer idAutorI) {

        if (autor == null || idAutorI == null) return "No has ingresado informacion suficiente para actualizar un autor.";
        String sql = " UPDATE autor SET nombre = ?, apellido = ?, nacionalidad = ?, fechaNacimiento = ? WHERE idautor = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setString(1, autor.getNombre());
                ps.setString(2, autor.getApellido());
                ps.setString(3, autor.getNacionalidad());
                ps.setObject(4, autor.getFechaNacimiento());
                ps.setInt(5, idAutorI);

            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha actualizado el autor " + autor.getNombre() + " correctamente.";
            }else mensaje = "No se ha podido actualizar el autor.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar actualizar el  autor ", e);
        }
        return mensaje;
    }
    public String eliminarAutor(Integer idAutorI) {

        if (idAutorI == null) return "No has ingresado el id del autor para eliminar su informacion.";
        String sql = " DELETE FROM autor WHERE idautor = ?";
        String mensaje;
        try (
                Connection con = ConexionDb.establecerConexion();
                PreparedStatement ps = con.prepareStatement(sql)) {

                ps.setInt(1, idAutorI);


            int filas = ps.executeUpdate();
            if (filas > 0) {
                mensaje = "Se ha eliminado el autor con el id " +idAutorI+ " correctamente.";
            }else mensaje = "No se ha podido eliminar el autor.";
        } catch (SQLException e) {
            throw new RuntimeException("Error al intentar eliminar el  autor ", e);
        }
        return mensaje;
    }
}
